9 Ball League Practice v5.8.9
versionCode 75

Background-only update:
- Uses the exact user-provided pool-hall image as pool_hall_bg.jpg.
- No UI, scoring, navigation, layout, or business-logic changes from V5.8.8.
