# 9 Ball Practice Scorekeeper — V5

Android package: `com.nineball.scorekeeper`

Version: `5.0` (`versionCode 50`)

This build replaces the league-management workflow with a practice-first 9-ball scorekeeper.

## Core scoring

- Single tap balls 1–8: +1 point to the current player.
- Single tap 9-ball: +2 points to the current player.
- Double tap any ball: mark it dead, 0 points.
- Ball buttons visually show pocketed vs dead balls.
- Turn Over switches shooters. An inning increments after both players have completed a turn.
- Defensive Shot and Timeout counters track the current player.
- Undo restores the complete previous scoring state.
- Reaching the player's target automatically completes the practice match.
- 9-ball completion advances to a new rack.
- Practice history is stored locally on the phone.
- Tracks 9-on-the-snap and break-and-run stats when detected.

## Important Google Play update note

This project intentionally keeps the existing package name `com.nineball.scorekeeper` and increases the version code above 41 so it can be uploaded as an update to the existing Play Console app.

For Play Store updates, sign the new AAB with the SAME upload key used for the first Play Console upload. Do not generate a new upload key for V5.
