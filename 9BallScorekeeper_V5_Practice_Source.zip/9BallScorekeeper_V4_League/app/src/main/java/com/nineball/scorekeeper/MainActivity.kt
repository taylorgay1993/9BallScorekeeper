package com.nineball.scorekeeper

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

private const val BALL_AVAILABLE = 0
private const val BALL_POCKETED = 1
private const val BALL_DEAD = 2

data class PracticePlayer(
    var name: String,
    var skill: Int,
    var target: Int,
    var score: Int = 0,
    var defensiveShots: Int = 0,
    var timeoutsLeft: Int = if (skill <= 3) 2 else 1
)

data class MatchSnapshot(
    val scoreA: Int,
    val scoreB: Int,
    val defenseA: Int,
    val defenseB: Int,
    val timeoutsA: Int,
    val timeoutsB: Int,
    val currentPlayer: Int,
    val innings: Int,
    val rack: Int,
    val breaker: Int,
    val rackTurnovers: Int,
    val ballStates: IntArray,
    val nineOnSnapA: Int,
    val nineOnSnapB: Int,
    val breakRunsA: Int,
    val breakRunsB: Int
)

class BallView(
    context: Context,
    val ballNumber: Int,
    private val onPocket: (Int) -> Unit,
    private val onDead: (Int) -> Unit
) : View(context) {
    var state: Int = BALL_AVAILABLE
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (state == BALL_AVAILABLE) onPocket(ballNumber)
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (state == BALL_AVAILABLE) onDead(ballNumber)
            return true
        }
    })

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Ball $ballNumber. Single tap to score, double tap for dead ball."
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = detector.onTouchEvent(event) || super.onTouchEvent(event)

    private fun ballColor(n: Int): Int = when (n) {
        1, 9 -> Color.rgb(244, 190, 35)
        2 -> Color.rgb(35, 94, 168)
        3 -> Color.rgb(190, 35, 48)
        4 -> Color.rgb(112, 71, 145)
        5 -> Color.rgb(232, 113, 52)
        6 -> Color.rgb(60, 137, 64)
        7 -> Color.rgb(130, 32, 39)
        8 -> Color.rgb(24, 24, 24)
        else -> Color.DKGRAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * .42f
        val c = ballColor(ballNumber)

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)

        if (ballNumber <= 8) {
            paint.color = c
            canvas.drawCircle(cx, cy, r, paint)
        } else {
            paint.color = c
            val stripe = RectF(cx - r, cy - r * .47f, cx + r, cy + r * .47f)
            canvas.drawRoundRect(stripe, r * .25f, r * .25f, paint)
        }

        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .39f, paint)
        paint.color = Color.rgb(25, 25, 25)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * .62f
        paint.isFakeBoldText = true
        val fm = paint.fontMetrics
        canvas.drawText(ballNumber.toString(), cx, cy - (fm.ascent + fm.descent) / 2, paint)
        paint.isFakeBoldText = false

        if (state == BALL_POCKETED) {
            paint.color = Color.argb(165, 9, 80, 74)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .42f, cy, cx - r * .08f, cy + r * .34f, paint)
            canvas.drawLine(cx - r * .08f, cy + r * .34f, cx + r * .48f, cy - r * .35f, paint)
            paint.style = Paint.Style.FILL
        } else if (state == BALL_DEAD) {
            paint.color = Color.argb(180, 70, 70, 70)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .45f, cy - r * .45f, cx + r * .45f, cy + r * .45f, paint)
            canvas.drawLine(cx + r * .45f, cy - r * .45f, cx - r * .45f, cy + r * .45f, paint)
            paint.style = Paint.Style.FILL
        }
    }
}

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("practice_scorekeeper_v5", Context.MODE_PRIVATE) }

    private val navy = Color.rgb(13, 41, 64)
    private val blue = Color.rgb(22, 111, 169)
    private val teal = Color.rgb(9, 121, 113)
    private val gold = Color.rgb(231, 174, 51)
    private val card = Color.rgb(244, 247, 249)
    private val ink = Color.rgb(25, 35, 45)
    private val muted = Color.rgb(92, 105, 116)

    private var a = PracticePlayer("Player 1", 4, 31)
    private var b = PracticePlayer("Player 2", 4, 31)
    private var currentPlayer = 0
    private var innings = 0
    private var rack = 1
    private var breaker = 0
    private var rackTurnovers = 0
    private var nineOnSnapA = 0
    private var nineOnSnapB = 0
    private var breakRunsA = 0
    private var breakRunsB = 0
    private val ballStates = IntArray(10)
    private val undoStack = ArrayDeque<MatchSnapshot>()

    private lateinit var scoreAText: TextView
    private lateinit var scoreBText: TextView
    private lateinit var inningsText: TextView
    private lateinit var shooterText: TextView
    private lateinit var detailText: TextView
    private lateinit var defenseButton: Button
    private lateinit var timeoutButton: Button
    private val ballViews = mutableMapOf<Int, BallView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float = 16f, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(dp(6), dp(7), dp(6), dp(7))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        setBackgroundColor(if (primary) blue else navy)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { action() }
    }

    private fun page(title: String): LinearLayout {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(236, 241, 245)); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        val titleBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(navy)
        }
        titleBar.addView(text(title, 24f, Color.WHITE, true))
        root.addView(titleBar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        scroll.addView(root)
        setContentView(scroll)
        return root
    }

    private fun showHome() {
        val root = page("9 Ball Practice Scorekeeper")
        root.addView(text("Practice matches with ball-by-ball scoring", 17f, muted))
        root.addView(text("Single tap a ball = score it. Double tap = dead ball.", 16f, ink, true))
        root.addView(button("START PRACTICE MATCH", true) { showSetup() }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(18) })
        root.addView(button("PRACTICE HISTORY") { showHistory() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) })
        root.addView(text("Designed for practice. No teams, standings, schedules, or league-night management.", 14f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
    }

    private fun labeledField(root: LinearLayout, label: String, default: String, numeric: Boolean = false): EditText {
        root.addView(text(label, 14f, muted, true))
        return EditText(this).apply {
            setText(default)
            textSize = 18f
            setTextColor(ink)
            setBackgroundColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            root.addView(this, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(10) })
        }
    }

    private fun showSetup() {
        val root = page("New Practice Match")
        val p1 = labeledField(root, "Player 1", prefs.getString("last_p1", "Player 1") ?: "Player 1")
        val p1Skill = labeledField(root, "Player 1 skill level", prefs.getInt("last_sl1", 4).toString(), true)
        val p1Target = labeledField(root, "Player 1 target ball points", prefs.getInt("last_target1", 31).toString(), true)
        val p2 = labeledField(root, "Player 2", prefs.getString("last_p2", "Player 2") ?: "Player 2")
        val p2Skill = labeledField(root, "Player 2 skill level", prefs.getInt("last_sl2", 4).toString(), true)
        val p2Target = labeledField(root, "Player 2 target ball points", prefs.getInt("last_target2", 31).toString(), true)

        root.addView(text("First breaker", 14f, muted, true))
        val firstBreaker = Spinner(this)
        firstBreaker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Player 1", "Player 2"))
        root.addView(firstBreaker, LinearLayout.LayoutParams(-1, dp(58)))

        root.addView(button("START SCORING", true) {
            val n1 = p1.text.toString().trim().ifBlank { "Player 1" }
            val n2 = p2.text.toString().trim().ifBlank { "Player 2" }
            val sl1 = (p1Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9)
            val sl2 = (p2Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9)
            val t1 = (p1Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1)
            val t2 = (p2Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1)
            prefs.edit().putString("last_p1", n1).putString("last_p2", n2)
                .putInt("last_sl1", sl1).putInt("last_sl2", sl2)
                .putInt("last_target1", t1).putInt("last_target2", t2).apply()
            startMatch(n1, sl1, t1, n2, sl2, t2, firstBreaker.selectedItemPosition)
        }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(16) })
        root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) })
    }

    private fun startMatch(n1: String, sl1: Int, t1: Int, n2: String, sl2: Int, t2: Int, firstBreaker: Int) {
        a = PracticePlayer(n1, sl1, t1)
        b = PracticePlayer(n2, sl2, t2)
        currentPlayer = firstBreaker
        breaker = firstBreaker
        innings = 0
        rack = 1
        rackTurnovers = 0
        nineOnSnapA = 0; nineOnSnapB = 0; breakRunsA = 0; breakRunsB = 0
        ballStates.fill(BALL_AVAILABLE)
        undoStack.clear()
        showScoreScreen()
    }

    private fun showScoreScreen() {
        val root = page("Practice Match")

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE) }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(8), dp(6), dp(8)) }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); gravity = Gravity.END }
        scoreAText = text("", 17f, ink, true)
        scoreBText = text("", 17f, ink, true).apply { gravity = Gravity.END }
        inningsText = text("", 17f, blue, true).apply { gravity = Gravity.CENTER }
        left.addView(scoreAText)
        center.addView(text("INNINGS", 11f, muted, true).apply { gravity = Gravity.CENTER })
        center.addView(inningsText)
        right.addView(scoreBText)
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(center, LinearLayout.LayoutParams(dp(92), -2))
        top.addView(right, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        shooterText = text("", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setBackgroundColor(teal); setPadding(dp(8), dp(14), dp(8), dp(14)) }
        root.addView(shooterText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        detailText = text("", 14f, muted).apply { gravity = Gravity.CENTER; setBackgroundColor(Color.WHITE) }
        root.addView(detailText, LinearLayout.LayoutParams(-1, -2))

        root.addView(text("Tap = pocketed    •    Double tap = dead", 14f, muted, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        ballViews.clear()
        val ballArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(6), dp(2), dp(6)); setBackgroundColor(Color.WHITE) }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (n in 1..9) {
            val bv = BallView(this, n, ::pocketBall, ::deadBall)
            ballViews[n] = bv
            val params = LinearLayout.LayoutParams(0, dp(78), 1f).apply { marginStart = dp(1); marginEnd = dp(1) }
            if (n <= 5) row1.addView(bv, params) else row2.addView(bv, params)
        }
        ballArea.addView(row1, LinearLayout.LayoutParams(-1, -2))
        ballArea.addView(row2, LinearLayout.LayoutParams(-1, -2))
        root.addView(ballArea)

        val turnButton = button("TURN OVER", true) { turnOver() }
        root.addView(turnButton, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(8) })

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        defenseButton = button("DEFENSIVE SHOT") { markDefensiveShot() }
        timeoutButton = button("TIMEOUT") { useTimeout() }
        actionRow.addView(defenseButton, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(timeoutButton, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(4) })
        root.addView(actionRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val lowerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lowerRow.addView(button("UNDO") { undo() }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(4) })
        lowerRow.addView(button("RACK / STATS") { showRackStats() }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(4) })
        root.addView(lowerRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(button("END PRACTICE SESSION") { confirmEndSession() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })

        refreshScoreScreen()
    }

    private fun player(index: Int): PracticePlayer = if (index == 0) a else b

    private fun saveSnapshot() {
        undoStack.addLast(MatchSnapshot(
            a.score, b.score, a.defensiveShots, b.defensiveShots, a.timeoutsLeft, b.timeoutsLeft,
            currentPlayer, innings, rack, breaker, rackTurnovers, ballStates.copyOf(),
            nineOnSnapA, nineOnSnapB, breakRunsA, breakRunsB
        ))
        while (undoStack.size > 80) undoStack.removeFirst()
    }

    private fun undo() {
        val s = if (undoStack.isEmpty()) null else undoStack.removeLast()
        if (s == null) {
            Toast.makeText(this, "Nothing to undo.", Toast.LENGTH_SHORT).show(); return
        }
        a.score = s.scoreA; b.score = s.scoreB
        a.defensiveShots = s.defenseA; b.defensiveShots = s.defenseB
        a.timeoutsLeft = s.timeoutsA; b.timeoutsLeft = s.timeoutsB
        currentPlayer = s.currentPlayer; innings = s.innings; rack = s.rack; breaker = s.breaker; rackTurnovers = s.rackTurnovers
        for (i in ballStates.indices) ballStates[i] = s.ballStates[i]
        nineOnSnapA = s.nineOnSnapA; nineOnSnapB = s.nineOnSnapB; breakRunsA = s.breakRunsA; breakRunsB = s.breakRunsB
        refreshScoreScreen()
    }

    private fun pocketBall(n: Int) {
        if (ballStates[n] != BALL_AVAILABLE) return
        saveSnapshot()
        val p = player(currentPlayer)
        val points = if (n == 9) 2 else 1
        p.score += points
        ballStates[n] = BALL_POCKETED
        refreshScoreScreen()

        if (p.score >= p.target) {
            finishMatch(p)
            return
        }

        if (n == 9) {
            if (rackTurnovers == 0 && currentPlayer == breaker) {
                if (currentPlayer == 0) breakRunsA++ else breakRunsB++
                if ((1..8).all { ballStates[it] == BALL_AVAILABLE }) {
                    if (currentPlayer == 0) nineOnSnapA++ else nineOnSnapB++
                }
            }
            Toast.makeText(this, "Rack $rack complete. ${p.name} scored 2 for the 9-ball.", Toast.LENGTH_SHORT).show()
            startNextRack(currentPlayer)
        }
    }

    private fun deadBall(n: Int) {
        if (ballStates[n] != BALL_AVAILABLE) return
        saveSnapshot()
        ballStates[n] = BALL_DEAD
        refreshScoreScreen()
        Toast.makeText(this, "Ball $n marked dead — 0 points.", Toast.LENGTH_SHORT).show()
        if (n == 9) startNextRack(currentPlayer)
    }

    private fun turnOver() {
        saveSnapshot()
        rackTurnovers++
        if (currentPlayer == 1) innings++
        currentPlayer = 1 - currentPlayer
        refreshScoreScreen()
    }

    private fun markDefensiveShot() {
        saveSnapshot()
        player(currentPlayer).defensiveShots++
        refreshScoreScreen()
        Toast.makeText(this, "Defensive shot added for ${player(currentPlayer).name}.", Toast.LENGTH_SHORT).show()
    }

    private fun useTimeout() {
        val p = player(currentPlayer)
        if (p.timeoutsLeft <= 0) {
            Toast.makeText(this, "${p.name} has no timeouts left.", Toast.LENGTH_SHORT).show(); return
        }
        saveSnapshot()
        p.timeoutsLeft--
        refreshScoreScreen()
    }

    private fun startNextRack(nextBreaker: Int) {
        rack++
        breaker = nextBreaker
        currentPlayer = nextBreaker
        rackTurnovers = 0
        ballStates.fill(BALL_AVAILABLE)
        refreshScoreScreen()
    }

    private fun refreshScoreScreen() {
        if (!::scoreAText.isInitialized) return
        scoreAText.text = "${a.name}\n${a.score}/${a.target} pts\nSL ${a.skill}"
        scoreBText.text = "${b.name}\n${b.score}/${b.target} pts\nSL ${b.skill}"
        inningsText.text = innings.toString()
        val shooter = player(currentPlayer)
        shooterText.text = "${shooter.name}'s turn"
        detailText.text = "Rack $rack  •  Breaker: ${player(breaker).name}\nRemaining: ${maxOf(0, a.target - a.score)} / ${maxOf(0, b.target - b.score)} ball points"
        defenseButton.text = "DEFENSIVE SHOTS\n${shooter.defensiveShots}"
        timeoutButton.text = "TIMEOUTS LEFT\n${shooter.timeoutsLeft}"
        ballViews.forEach { (n, v) -> v.state = ballStates[n] }
    }

    private fun showRackStats() {
        val dead = (1..9).filter { ballStates[it] == BALL_DEAD }.joinToString(", ").ifBlank { "None" }
        val pocketed = (1..9).filter { ballStates[it] == BALL_POCKETED }.joinToString(", ").ifBlank { "None" }
        AlertDialog.Builder(this)
            .setTitle("Rack $rack / Match Stats")
            .setMessage(
                "Pocketed this rack: $pocketed\nDead this rack: $dead\n\n" +
                    "${a.name}: ${a.score}/${a.target}, ${a.defensiveShots} safeties, $nineOnSnapA 9-on-snap, $breakRunsA break-and-run\n" +
                    "${b.name}: ${b.score}/${b.target}, ${b.defensiveShots} safeties, $nineOnSnapB 9-on-snap, $breakRunsB break-and-run\n\n" +
                    "Innings: $innings"
            )
            .setPositiveButton("CLOSE", null)
            .setNeutralButton("NEW RACK") { _, _ ->
                saveSnapshot(); startNextRack(1 - breaker)
            }
            .show()
    }

    private fun confirmEndSession() {
        AlertDialog.Builder(this).setTitle("End practice session?")
            .setMessage("The current scores and stats will be saved to practice history.")
            .setNegativeButton("KEEP SCORING", null)
            .setPositiveButton("END SESSION") { _, _ -> saveHistory(null); showHome() }
            .show()
    }

    private fun finishMatch(winner: PracticePlayer) {
        saveHistory(winner.name)
        AlertDialog.Builder(this)
            .setTitle("PRACTICE MATCH COMPLETE")
            .setMessage("${winner.name} reached the target.\n\n${a.name}: ${a.score}/${a.target}\n${b.name}: ${b.score}/${b.target}\nInnings: $innings\nRacks: $rack")
            .setCancelable(false)
            .setPositiveButton("DONE") { _, _ -> showHome() }
            .show()
    }

    private fun saveHistory(winner: String?) {
        val arr = JSONArray(prefs.getString("history", "[]"))
        arr.put(JSONObject().apply {
            put("date", SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(Date()))
            put("p1", a.name); put("p2", b.name)
            put("score1", a.score); put("score2", b.score)
            put("target1", a.target); put("target2", b.target)
            put("innings", innings); put("racks", rack)
            put("def1", a.defensiveShots); put("def2", b.defensiveShots)
            put("snap1", nineOnSnapA); put("snap2", nineOnSnapB)
            put("br1", breakRunsA); put("br2", breakRunsB)
            put("winner", winner ?: "Session ended")
        })
        while (arr.length() > 100) {
            val trimmed = JSONArray()
            for (i in 1 until arr.length()) trimmed.put(arr.get(i))
            prefs.edit().putString("history", trimmed.toString()).apply()
            return
        }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    private fun showHistory() {
        val root = page("Practice History")
        val arr = JSONArray(prefs.getString("history", "[]"))
        if (arr.length() == 0) {
            root.addView(text("No practice sessions saved yet.", 17f, muted))
        } else {
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i)
                val entry = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)) }
                entry.addView(text("${o.optString("p1")}  ${o.optInt("score1")}/${o.optInt("target1")}   •   ${o.optString("p2")}  ${o.optInt("score2")}/${o.optInt("target2")}", 16f, ink, true))
                entry.addView(text("${o.optString("date")}  •  ${o.optInt("innings")} innings  •  ${o.optInt("racks")} racks", 13f, muted))
                entry.addView(text("Defensive shots ${o.optInt("def1")}/${o.optInt("def2")}  •  9-on-snap ${o.optInt("snap1")}/${o.optInt("snap2")}  •  Break-runs ${o.optInt("br1")}/${o.optInt("br2")}", 13f, muted))
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        root.addView(button("CLEAR HISTORY") {
            AlertDialog.Builder(this).setTitle("Clear practice history?").setNegativeButton("CANCEL", null)
                .setPositiveButton("CLEAR") { _, _ -> prefs.edit().remove("history").apply(); showHistory() }.show()
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
    }
}
