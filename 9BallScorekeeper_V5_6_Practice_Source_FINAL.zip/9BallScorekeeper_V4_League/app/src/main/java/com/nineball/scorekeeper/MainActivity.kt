package com.nineball.scorekeeper

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Path
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.min

private const val BALL_AVAILABLE = 0
private const val BALL_POCKETED = 1
private const val BALL_DEAD = 2

data class PracticePlayer(
    var name: String,
    var skill: Int,
    var target: Int,
    var score: Int = 0,
    var defensiveShots: Int = 0,
    var timeoutsLeft: Int = if (skill <= 3) 2 else 1
)

data class ApaMatchResult(
    val winnerName: String,
    val loserName: String,
    val winnerPoints: Int,
    val loserPoints: Int,
    val loserSkill: Int,
    val loserBallPoints: Int
)

data class MatchSnapshot(
    val scoreA: Int,
    val scoreB: Int,
    val defenseA: Int,
    val defenseB: Int,
    val timeoutsA: Int,
    val timeoutsB: Int,
    val currentPlayer: Int,
    val innings: Int,
    val rack: Int,
    val breaker: Int,
    val rackTurnovers: Int,
    val ballStates: IntArray,
    val ballOwners: IntArray,
    val ballLocked: BooleanArray,
    val nineOnSnapA: Int,
    val nineOnSnapB: Int,
    val breakRunsA: Int,
    val breakRunsB: Int,
    val rackPointsA: List<Int>,
    val rackPointsB: List<Int>
)

class BallView(
    context: Context,
    val ballNumber: Int,
    private val onTap: (Int) -> Unit
) : View(context) {
    var state: Int = BALL_AVAILABLE
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Ball $ballNumber. Tap to change status."
        setOnClickListener { onTap(ballNumber) }
    }

    private fun ballColor(n: Int): Int = when (n) {
        1 -> Color.rgb(244, 190, 35)
        9 -> Color.rgb(20, 20, 20)
        2 -> Color.rgb(35, 94, 168)
        3 -> Color.rgb(190, 35, 48)
        4 -> Color.rgb(112, 71, 145)
        5 -> Color.rgb(232, 113, 52)
        6 -> Color.rgb(60, 137, 64)
        7 -> Color.rgb(130, 32, 39)
        8 -> Color.rgb(24, 24, 24)
        else -> Color.DKGRAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * .42f
        val c = ballColor(ballNumber)

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)

        if (ballNumber <= 8) {
            paint.color = c
            canvas.drawCircle(cx, cy, r, paint)
        } else {
            // Custom black-and-yellow 9-ball requested for the practice interface.
            paint.color = Color.rgb(20, 20, 20)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.rgb(244, 190, 35)
            val stripe = RectF(cx - r, cy - r * .47f, cx + r, cy + r * .47f)
            canvas.drawRoundRect(stripe, r * .25f, r * .25f, paint)
        }

        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .39f, paint)
        paint.color = Color.rgb(25, 25, 25)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * .62f
        paint.isFakeBoldText = true
        val fm = paint.fontMetrics
        canvas.drawText(ballNumber.toString(), cx, cy - (fm.ascent + fm.descent) / 2, paint)
        paint.isFakeBoldText = false

        if (state == BALL_POCKETED) {
            paint.color = Color.argb(165, 9, 80, 74)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .42f, cy, cx - r * .08f, cy + r * .34f, paint)
            canvas.drawLine(cx - r * .08f, cy + r * .34f, cx + r * .48f, cy - r * .35f, paint)
            paint.style = Paint.Style.FILL
        } else if (state == BALL_DEAD) {
            paint.color = Color.argb(180, 70, 70, 70)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .45f, cy - r * .45f, cx + r * .45f, cy + r * .45f, paint)
            canvas.drawLine(cx + r * .45f, cy - r * .45f, cx - r * .45f, cy + r * .45f, paint)
            paint.style = Paint.Style.FILL
        }
    }
}

class RackBallIconView(context: Context, private val ballNumber: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun ballColor(n: Int): Int = when (n) {
        1 -> Color.rgb(244, 190, 35)
        9 -> Color.rgb(20, 20, 20)
        2 -> Color.rgb(35, 94, 168)
        3 -> Color.rgb(190, 35, 48)
        4 -> Color.rgb(112, 71, 145)
        5 -> Color.rgb(232, 113, 52)
        6 -> Color.rgb(60, 137, 64)
        7 -> Color.rgb(130, 32, 39)
        8 -> Color.rgb(24, 24, 24)
        else -> Color.DKGRAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * .42f
        val c = ballColor(ballNumber)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)
        if (ballNumber <= 8) {
            paint.color = c
            canvas.drawCircle(cx, cy, r, paint)
        } else {
            // Custom black-and-yellow 9-ball requested for the practice interface.
            paint.color = Color.rgb(20, 20, 20)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.rgb(244, 190, 35)
            val stripe = RectF(cx - r, cy - r * .47f, cx + r, cy + r * .47f)
            canvas.drawRoundRect(stripe, r * .25f, r * .25f, paint)
        }
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .39f, paint)
        paint.color = Color.rgb(25, 25, 25)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * .62f
        paint.isFakeBoldText = true
        val fm = paint.fontMetrics
        canvas.drawText(ballNumber.toString(), cx, cy - (fm.ascent + fm.descent) / 2, paint)
        paint.isFakeBoldText = false
    }
}


class RackPerformanceView(
    context: Context,
    private val playerA: String,
    private val playerB: String,
    private val aPoints: List<Int>,
    private val bPoints: List<Int>
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Color.rgb(210, 218, 225)
    private val ink = Color.rgb(40, 50, 60)
    private val aColor = Color.rgb(22, 111, 169)
    private val bColor = Color.rgb(9, 121, 113)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = 72f
        val right = width - 24f
        val top = 42f
        val bottom = height - 66f
        val rackCount = maxOf(aPoints.size, bPoints.size).coerceAtLeast(1)

        fun cumulative(values: List<Int>): List<Int> {
            var running = 0
            return values.map { running += it; running }
        }
        val cumulativeA = cumulative(aPoints)
        val cumulativeB = cumulative(bPoints)
        val highestScore = maxOf(cumulativeA.maxOrNull() ?: 0, cumulativeB.maxOrNull() ?: 0, 10)
        val xMax = ((highestScore + 9) / 10) * 10

        paint.textSize = 23f
        paint.color = ink
        paint.isFakeBoldText = true
        canvas.drawText("Score progression by rack", left, 25f, paint)
        paint.isFakeBoldText = false

        // Horizontal axis: score in 10-point increments.
        paint.textSize = 15f
        for (score in 0..xMax step 10) {
            val x = left + (right - left) * score / xMax.toFloat()
            paint.color = grid
            paint.strokeWidth = 1f
            canvas.drawLine(x, top, x, bottom, paint)
            paint.color = ink
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(score.toString(), x, bottom + 22f, paint)
        }

        // Vertical axis: rack number.
        fun yForRack(index: Int): Float = if (rackCount == 1) (top + bottom) / 2f else bottom - (bottom - top) * index / (rackCount - 1f)
        for (i in 0 until rackCount) {
            val y = yForRack(i)
            paint.color = grid
            paint.strokeWidth = 1f
            canvas.drawLine(left, y, right, y, paint)
            paint.color = ink
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("R${i + 1}", left - 10f, y + 5f, paint)
        }

        fun xForScore(score: Int): Float = left + (right - left) * score.coerceIn(0, xMax) / xMax.toFloat()
        fun drawSeries(values: List<Int>, color: Int) {
            if (values.isEmpty()) return
            paint.color = color
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            val path = Path()
            values.forEachIndexed { i, score ->
                val x = xForScore(score); val y = yForRack(i)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.FILL
            values.forEachIndexed { i, score -> canvas.drawCircle(xForScore(score), yForRack(i), 7f, paint) }
        }
        drawSeries(cumulativeA, aColor)
        drawSeries(cumulativeB, bColor)

        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 16f
        paint.color = ink
        canvas.drawText("Score (ball points)", (left + right) / 2f, height - 20f, paint)

        canvas.save()
        canvas.rotate(-90f, 18f, (top + bottom) / 2f)
        canvas.drawText("Rack number", 18f, (top + bottom) / 2f, paint)
        canvas.restore()

        paint.textAlign = Paint.Align.LEFT
        paint.textSize = 15f
        paint.color = aColor
        canvas.drawText(playerA, left, height - 2f, paint)
        paint.color = bColor
        canvas.drawText(playerB, left + 150f, height - 2f, paint)
    }
}

data class RackRecord(
    var rackNumber: Int,
    var breaker: Int,
    var ballStates: IntArray,
    var ballOwners: IntArray,
    var innings: Int,
    var defensiveA: Int,
    var defensiveB: Int,
    var timeoutsA: Int,
    var timeoutsB: Int,
    var nineOnSnapPlayer: Int = -1,
    var breakRunPlayer: Int = -1
)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("practice_scorekeeper_v5", Context.MODE_PRIVATE) }

    private val navy = Color.rgb(8, 93, 163)
    private val blue = Color.rgb(15, 108, 184)
    private val lightBlue = Color.rgb(74, 152, 205)
    private val teal = Color.rgb(9, 121, 113)
    private val gold = Color.rgb(231, 174, 51)
    private val card = Color.rgb(244, 247, 249)
    private val ink = Color.rgb(25, 35, 45)
    private val muted = Color.rgb(92, 105, 116)
    private val actionGray = Color.rgb(99, 99, 103)

    private var a = PracticePlayer("Player 1", 4, 31)
    private var b = PracticePlayer("Player 2", 4, 31)
    private var currentPlayer = 0
    private var innings = 0
    private var rack = 1
    private var breaker = 0
    private var rackTurnovers = 0
    private var rackInnings = 0
    private var rackDefenseA = 0
    private var rackDefenseB = 0
    private var rackTimeoutA = 0
    private var rackTimeoutB = 0
    private var nineOnSnapA = 0
    private var nineOnSnapB = 0
    private var breakRunsA = 0
    private var breakRunsB = 0
    private val rackPointsA = mutableListOf(0)
    private val rackPointsB = mutableListOf(0)
    private val rackRecords = mutableListOf<RackRecord>()
    private val ballStates = IntArray(10)
    private val ballOwners = IntArray(10) { -1 }
    private val ballLocked = BooleanArray(10)
    private val undoStack = ArrayDeque<MatchSnapshot>()
    private var activeMatchId: String? = null
    private var winnerDialogOpen = false

    private lateinit var scoreAText: TextView
    private lateinit var scoreBText: TextView
    private lateinit var inningsText: TextView
    private lateinit var shooterText: TextView
    private lateinit var detailText: TextView
    private lateinit var defenseButton: Button
    private lateinit var timeoutButton: Button
    private lateinit var ballsARow: GridLayout
    private lateinit var ballsBRow: GridLayout
    private lateinit var deadBallsRow: LinearLayout
    private lateinit var playerPanelA: LinearLayout
    private lateinit var playerPanelB: LinearLayout
    private val ballViews = mutableMapOf<Int, BallView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float = 16f, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(dp(6), dp(7), dp(6), dp(7))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        setBackgroundColor(if (primary) blue else actionGray)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { action() }
    }

    private fun page(title: String): LinearLayout {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(236, 241, 245)); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(24)) }
        val titleBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); setBackgroundColor(navy) }
        titleBar.addView(text(title, 24f, Color.WHITE, true))
        root.addView(titleBar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        scroll.addView(root)
        setContentView(scroll)
        return root
    }

    private fun normalizeName(name: String): String = name.trim().replace(Regex("\\s+"), " ").lowercase(Locale.US)

    private fun headToHead(n1: String, n2: String): Triple<Int, Int, Int> {
        val k1 = normalizeName(n1); val k2 = normalizeName(n2)
        var w1 = 0; var w2 = 0; var total = 0
        val arr = JSONArray(prefs.getString("history", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val p1 = normalizeName(o.optString("p1")); val p2 = normalizeName(o.optString("p2"))
            if (!((p1 == k1 && p2 == k2) || (p1 == k2 && p2 == k1))) continue
            val winner = normalizeName(o.optString("winner"))
            if (winner == k1) w1++ else if (winner == k2) w2++
            if (winner == k1 || winner == k2) total++
        }
        return Triple(w1, w2, total)
    }

    private fun activeMatches(): JSONArray = try { JSONArray(prefs.getString("active_matches_v58", "[]")) } catch (_: Exception) { JSONArray() }

    private fun showHome() {
        val root = page("9 Ball Practice Scorekeeper")
        root.addView(text("Practice matches with ball-by-ball scoring", 17f, muted))
        root.addView(button("START NEW PRACTICE MATCH", true) { showSetup() }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(18) })
        val activeCount = activeMatches().length()
        root.addView(button("ACTIVE MATCHES${if (activeCount > 0) " ($activeCount)" else ""}") { showActiveMatches() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) })
        root.addView(button("PRACTICE HISTORY") { showHistory() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) })
        root.addView(text("Multiple unfinished matches can be saved and resumed later.", 14f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
    }

    private fun labeledField(root: LinearLayout, label: String, default: String, numeric: Boolean = false): EditText {
        root.addView(text(label, 14f, muted, true))
        return EditText(this).apply {
            setText(default); textSize = 18f; setTextColor(ink); setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12))
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            root.addView(this, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(10) })
        }
    }

    private fun showSetup() {
        val root = page("New Practice Match")
        val p1 = labeledField(root, "Player 1", prefs.getString("last_p1", "Player 1") ?: "Player 1")
        val p1Skill = labeledField(root, "Player 1 skill level", prefs.getInt("last_sl1", 4).toString(), true)
        val p1Target = labeledField(root, "Player 1 target ball points", prefs.getInt("last_target1", 31).toString(), true)
        val p2 = labeledField(root, "Player 2", prefs.getString("last_p2", "Player 2") ?: "Player 2")
        val p2Skill = labeledField(root, "Player 2 skill level", prefs.getInt("last_sl2", 4).toString(), true)
        val p2Target = labeledField(root, "Player 2 target ball points", prefs.getInt("last_target2", 31).toString(), true)
        val h2h = text("", 15f, blue, true).apply { gravity = Gravity.CENTER; setBackgroundColor(Color.WHITE) }
        root.addView(h2h, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        fun updateH2H() {
            val n1 = p1.text.toString().trim(); val n2 = p2.text.toString().trim()
            if (n1.isBlank() || n2.isBlank() || normalizeName(n1) == normalizeName(n2)) { h2h.text = ""; return }
            val (w1, w2, total) = headToHead(n1, n2)
            h2h.text = if (total == 0) "No previous matches between these players" else "All-time: $n1 $w1  –  $w2 $n2  •  $total matches"
        }
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateH2H() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        p1.addTextChangedListener(watcher); p2.addTextChangedListener(watcher); updateH2H()

        root.addView(text("First breaker", 14f, muted, true))
        val firstBreaker = Spinner(this)
        firstBreaker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Player 1", "Player 2"))
        root.addView(firstBreaker, LinearLayout.LayoutParams(-1, dp(58)))
        root.addView(button("START SCORING", true) {
            val n1 = p1.text.toString().trim().ifBlank { "Player 1" }; val n2 = p2.text.toString().trim().ifBlank { "Player 2" }
            val sl1 = (p1Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9); val sl2 = (p2Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9)
            val t1 = (p1Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1); val t2 = (p2Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1)
            prefs.edit().putString("last_p1", n1).putString("last_p2", n2).putInt("last_sl1", sl1).putInt("last_sl2", sl2).putInt("last_target1", t1).putInt("last_target2", t2).apply()
            startMatch(n1, sl1, t1, n2, sl2, t2, firstBreaker.selectedItemPosition)
        }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(16) })
        root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) })
    }

    private fun startMatch(n1: String, sl1: Int, t1: Int, n2: String, sl2: Int, t2: Int, firstBreaker: Int) {
        a = PracticePlayer(n1, sl1, t1); b = PracticePlayer(n2, sl2, t2)
        currentPlayer = firstBreaker; breaker = firstBreaker; innings = 0; rack = 1; rackTurnovers = 0; rackInnings = 0
        rackDefenseA = 0; rackDefenseB = 0; rackTimeoutA = 0; rackTimeoutB = 0
        nineOnSnapA = 0; nineOnSnapB = 0; breakRunsA = 0; breakRunsB = 0
        rackPointsA.clear(); rackPointsA.add(0); rackPointsB.clear(); rackPointsB.add(0); rackRecords.clear()
        ballStates.fill(BALL_AVAILABLE); ballOwners.fill(-1); ballLocked.fill(false); undoStack.clear()
        activeMatchId = UUID.randomUUID().toString(); saveActiveMatch(); showScoreScreen()
    }

    private fun player(index: Int): PracticePlayer = if (index == 0) a else b
    private fun maxTimeouts(p: PracticePlayer): Int = if (p.skill <= 3) 2 else 1

    private fun showScoreScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(242, 244, 246)); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(20)) }
        scroll.addView(root); setContentView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(navy); setPadding(dp(8), dp(12), dp(8), dp(10)) }
        playerPanelA = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        playerPanelB = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        scoreAText = text("", 19f, Color.WHITE, true)
        scoreBText = text("", 19f, Color.WHITE, true).apply { gravity = Gravity.END }
        playerPanelA.addView(scoreAText); playerPanelB.addView(scoreBText)
        top.addView(playerPanelA, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(playerPanelB, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top)

        var touchY = 0f
        top.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { touchY = event.rawY; true }
                MotionEvent.ACTION_UP -> { if (event.rawY - touchY > dp(55)) { showRackHistory(); true } else false }
                else -> true
            }
        }

        val statStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(lightBlue); setPadding(dp(6), dp(2), dp(6), dp(2)) }
        inningsText = text("", 15f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        statStrip.addView(text("↓ Swipe down for Rack History", 13f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        statStrip.addView(inningsText, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(statStrip)

        val rackBallPanel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.rgb(218, 223, 226)); setPadding(dp(6), dp(4), dp(6), dp(6)) }
        val rackA = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; val rackB = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ballsARow = GridLayout(this).apply { columnCount = 5; rowCount = 2 }; ballsBRow = GridLayout(this).apply { columnCount = 5; rowCount = 2 }
        rackA.addView(ballsARow, LinearLayout.LayoutParams(-1, dp(72))); rackB.addView(ballsBRow, LinearLayout.LayoutParams(-1, dp(72)))
        rackBallPanel.addView(rackA, LinearLayout.LayoutParams(0, -2, 1f)); rackBallPanel.addView(rackB, LinearLayout.LayoutParams(0, -2, 1f)); root.addView(rackBallPanel)

        val shooterCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(18), dp(12), dp(18), dp(10)) }
        shooterText = text("", 24f, ink, true); detailText = text("", 14f, muted)
        shooterCard.addView(shooterText); shooterCard.addView(detailText); root.addView(shooterCard)

        val deadPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(2), dp(12), dp(6)) }
        deadPanel.addView(text("Dead balls", 11f, muted, true)); deadBallsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.START }
        deadPanel.addView(deadBallsRow, LinearLayout.LayoutParams(-1, dp(38))); root.addView(deadPanel)

        ballViews.clear()
        val ballArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(6), dp(16), dp(6)); setBackgroundColor(Color.WHITE) }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }; val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (n in 1..9) {
            val bv = BallView(this, n, ::cycleBallState); ballViews[n] = bv
            val params = LinearLayout.LayoutParams(0, dp(74), 1f).apply { marginStart = dp(1); marginEnd = dp(1) }
            if (n <= 5) row1.addView(bv, params) else row2.addView(bv, params)
        }
        ballArea.addView(row1); ballArea.addView(row2); root.addView(ballArea)

        root.addView(button("TURN OVER", true) { turnOver() }, LinearLayout.LayoutParams(-1, dp(62)).apply { marginStart = dp(18); marginEnd = dp(18); topMargin = dp(8) })
        defenseButton = button("") { markDefensiveShot() }; timeoutButton = button("") { useTimeout() }
        root.addView(defenseButton, LinearLayout.LayoutParams(-1, dp(62)).apply { marginStart = dp(18); marginEnd = dp(18); topMargin = dp(8) })
        root.addView(timeoutButton, LinearLayout.LayoutParams(-1, dp(62)).apply { marginStart = dp(18); marginEnd = dp(18); topMargin = dp(8) })
        root.addView(button("GO BACK / UNDO") { undo() }, LinearLayout.LayoutParams(-1, dp(62)).apply { marginStart = dp(18); marginEnd = dp(18); topMargin = dp(8) })
        val lower = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(18), dp(8), dp(18), 0) }
        lower.addView(button("RACK / STATS") { showRackStats() }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(4) })
        lower.addView(button("SAVE & EXIT") { saveActiveMatch(); showHome() }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(4) })
        root.addView(lower)
        root.addView(button("END PRACTICE SESSION") { confirmEndSession() }, LinearLayout.LayoutParams(-1, dp(54)).apply { marginStart = dp(18); marginEnd = dp(18); topMargin = dp(8) })
        refreshScoreScreen()
    }

    private fun saveSnapshot() {
        undoStack.addLast(MatchSnapshot(a.score, b.score, a.defensiveShots, b.defensiveShots, a.timeoutsLeft, b.timeoutsLeft, currentPlayer, innings, rack, breaker, rackTurnovers, ballStates.copyOf(), ballOwners.copyOf(), ballLocked.copyOf(), nineOnSnapA, nineOnSnapB, breakRunsA, breakRunsB, rackPointsA.toList(), rackPointsB.toList()))
        while (undoStack.size > 80) undoStack.removeFirst()
    }

    private fun undo() {
        val s = if (undoStack.isEmpty()) null else undoStack.removeLast()
        if (s == null) { Toast.makeText(this, "Nothing to undo.", Toast.LENGTH_SHORT).show(); return }
        a.score = s.scoreA; b.score = s.scoreB; a.defensiveShots = s.defenseA; b.defensiveShots = s.defenseB; a.timeoutsLeft = s.timeoutsA; b.timeoutsLeft = s.timeoutsB
        currentPlayer = s.currentPlayer; innings = s.innings; rack = s.rack; breaker = s.breaker; rackTurnovers = s.rackTurnovers
        for (i in ballStates.indices) { ballStates[i] = s.ballStates[i]; ballOwners[i] = s.ballOwners[i]; ballLocked[i] = s.ballLocked[i] }
        nineOnSnapA = s.nineOnSnapA; nineOnSnapB = s.nineOnSnapB; breakRunsA = s.breakRunsA; breakRunsB = s.breakRunsB
        rackPointsA.clear(); rackPointsA.addAll(s.rackPointsA); rackPointsB.clear(); rackPointsB.addAll(s.rackPointsB)
        winnerDialogOpen = false; saveActiveMatch(); refreshScoreScreen()
    }

    private fun cycleBallState(n: Int) {
        if (ballLocked[n]) return
        val reached = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
        if (reached >= 0 && ballStates[n] == BALL_AVAILABLE) { showWinnerDialog(reached); return }
        saveSnapshot()
        val wasAvailable = ballStates[n] == BALL_AVAILABLE
        when (ballStates[n]) {
            BALL_AVAILABLE -> {
                val pts = if (n == 9) 2 else 1; player(currentPlayer).score += pts
                if (currentPlayer == 0) rackPointsA[rack - 1] += pts else rackPointsB[rack - 1] += pts
                ballStates[n] = BALL_POCKETED; ballOwners[n] = currentPlayer
            }
            BALL_POCKETED -> {
                val owner = ballOwners[n]; val pts = if (n == 9) 2 else 1
                if (owner == 0 || owner == 1) { player(owner).score = (player(owner).score - pts).coerceAtLeast(0); if (owner == 0) rackPointsA[rack - 1] = (rackPointsA[rack - 1] - pts).coerceAtLeast(0) else rackPointsB[rack - 1] = (rackPointsB[rack - 1] - pts).coerceAtLeast(0) }
                ballStates[n] = BALL_DEAD; ballOwners[n] = -1
            }
            BALL_DEAD -> { ballStates[n] = BALL_AVAILABLE; ballOwners[n] = -1 }
        }
        saveActiveMatch(); refreshScoreScreen()

        // V5.6: tapping the 9 to pocket it immediately starts the rack-end flow.
        if (n == 9 && wasAvailable && ballStates[9] == BALL_POCKETED) {
            handleNineBallTapped(currentPlayer)
            return
        }

        val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
        if (winner >= 0) showWinnerDialog(winner)
    }

    private fun showWinnerDialog(index: Int, snap: Boolean = false, run: Boolean = false) {
        if (winnerDialogOpen) return
        winnerDialogOpen = true; val p = player(index)
        AlertDialog.Builder(this).setTitle("${p.name} wins the match!")
            .setMessage("${p.name} reached ${p.score}/${p.target} ball points.\n\nIf the last ball was entered by mistake, choose Edit Score and correct it before confirming the result.")
            .setCancelable(false)
            .setNegativeButton("EDIT SCORE") { _, _ -> winnerDialogOpen = false; refreshScoreScreen() }
            .setPositiveButton("CONFIRM WIN") { _, _ ->
                if (snap) { if (index == 0) nineOnSnapA++ else nineOnSnapB++ }
                if (run) { if (index == 0) breakRunsA++ else breakRunsB++ }
                winnerDialogOpen = false; finalizeWinner(index)
            }
            .show()
    }

    private fun turnOver() {
        if (a.score >= a.target || b.score >= b.target) { showWinnerDialog(if (a.score >= a.target) 0 else 1); return }
        saveSnapshot(); val shooter = currentPlayer; val ninePocketed = ballStates[9] == BALL_POCKETED; val nineDead = ballStates[9] == BALL_DEAD
        for (n in 1..9) if (ballStates[n] != BALL_AVAILABLE) ballLocked[n] = true
        if (ninePocketed || nineDead) { handleRackEnd(shooter, ninePocketed); return }
        rackTurnovers++
        if (currentPlayer == 1) { innings++; rackInnings++ }
        currentPlayer = 1 - currentPlayer; saveActiveMatch(); refreshScoreScreen()
    }

    private fun handleNineBallTapped(shooter: Int) {
        val earlyNine = (1..8).any { ballStates[it] == BALL_AVAILABLE }
        val possibleSnap = shooter == breaker && rackTurnovers == 0

        fun continueAfterClassification(snap: Boolean) {
            val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
            if (winner >= 0) {
                // Match-win flow takes priority over starting another rack. The special-rack stat
                // is recorded only if the user confirms the win, so Edit Score cannot double-count it.
                showWinnerDialog(winner, snap = snap)
                return
            }
            promptNextRack(shooter, snap)
        }

        if (earlyNine) {
            val options = if (possibleSnap) arrayOf("9-on-the-Snap", "9 Ball Made Early", "Cancel / Edit") else arrayOf("9 Ball Made Early", "Cancel / Edit")
            AlertDialog.Builder(this)
                .setTitle("9 Ball Pocketed")
                .setMessage(if (possibleSnap) "How should this 9 ball be recorded?" else "The 9 ball was made before the rack was complete. How should it be recorded?")
                .setItems(options) { dialog, which ->
                    if (possibleSnap) {
                        when (which) {
                            0 -> continueAfterClassification(true)
                            1 -> continueAfterClassification(false)
                            else -> { dialog.dismiss(); saveActiveMatch(); refreshScoreScreen() }
                        }
                    } else {
                        when (which) {
                            0 -> continueAfterClassification(false)
                            else -> { dialog.dismiss(); saveActiveMatch(); refreshScoreScreen() }
                        }
                    }
                }
                .show()
        } else {
            val runDetected = shooter == breaker && rackTurnovers == 0 && (1..8).all { ballStates[it] != BALL_AVAILABLE }
            if (runDetected) {
                AlertDialog.Builder(this).setTitle("Break & Run detected")
                    .setMessage("It looks like ${player(shooter).name} broke and ran the rack. Count this as a Break & Run?")
                    .setNegativeButton("NO") { _, _ -> promptNextRack(shooter, false) }
                    .setPositiveButton("YES") { _, _ ->
                        val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
                        if (winner >= 0) showWinnerDialog(winner, run = true) else promptNextRack(shooter, false, true)
                    }.show()
            } else {
                val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
                if (winner >= 0) showWinnerDialog(winner) else promptNextRack(shooter, false)
            }
        }
    }

    private fun promptNextRack(shooter: Int, snap: Boolean, run: Boolean = false) {
        AlertDialog.Builder(this)
            .setTitle("Go to next rack?")
            .setMessage("The 9 ball has been pocketed. Start the next rack now?")
            .setNegativeButton("GO BACK") { _, _ -> saveActiveMatch(); refreshScoreScreen() }
            .setPositiveButton("YES") { _, _ ->
                if (snap) { if (shooter == 0) nineOnSnapA++ else nineOnSnapB++ }
                if (run) { if (shooter == 0) breakRunsA++ else breakRunsB++ }
                for (n in 1..9) if (ballStates[n] != BALL_AVAILABLE) ballLocked[n] = true
                commitCurrentRack(if (snap) shooter else -1, if (run) shooter else -1)
                startNextRack(shooter)
            }
            .show()
    }

    private fun handleRackEnd(shooter: Int, ninePocketed: Boolean) {
        if (ninePocketed) { handleNineBallTapped(shooter); return }
        // A dead 9 still ends the rack, but is not a 9-on-the-Snap or Break & Run.
        AlertDialog.Builder(this)
            .setTitle("Go to next rack?")
            .setMessage("The 9 ball is dead. Start the next rack now?")
            .setNegativeButton("GO BACK") { _, _ -> saveActiveMatch(); refreshScoreScreen() }
            .setPositiveButton("YES") { _, _ -> commitCurrentRack(); startNextRack(shooter) }
            .show()
    }

    private fun markDefensiveShot() {
        saveSnapshot(); player(currentPlayer).defensiveShots++; if (currentPlayer == 0) rackDefenseA++ else rackDefenseB++; saveActiveMatch(); refreshScoreScreen()
    }

    private fun useTimeout() {
        val p = player(currentPlayer); if (p.timeoutsLeft <= 0) { Toast.makeText(this, "${p.name} has no timeouts left.", Toast.LENGTH_SHORT).show(); return }
        saveSnapshot(); p.timeoutsLeft--; if (currentPlayer == 0) rackTimeoutA++ else rackTimeoutB++; saveActiveMatch(); refreshScoreScreen()
    }

    private fun currentRackRecord(): RackRecord = RackRecord(rack, breaker, ballStates.copyOf(), ballOwners.copyOf(), rackInnings, rackDefenseA, rackDefenseB, rackTimeoutA, rackTimeoutB)

    private fun commitCurrentRack(snapPlayer: Int = -1, breakRunPlayer: Int = -1) {
        val rec = currentRackRecord(); rec.nineOnSnapPlayer = snapPlayer; rec.breakRunPlayer = breakRunPlayer; rackRecords.add(rec)
    }

    private fun startNextRack(nextBreaker: Int) {
        rack++; rackPointsA.add(0); rackPointsB.add(0); breaker = nextBreaker; currentPlayer = nextBreaker; rackTurnovers = 0; rackInnings = 0
        rackDefenseA = 0; rackDefenseB = 0; rackTimeoutA = 0; rackTimeoutB = 0
        ballStates.fill(BALL_AVAILABLE); ballOwners.fill(-1); ballLocked.fill(false); saveActiveMatch(); refreshScoreScreen()
    }

    private fun refreshScoreScreen() {
        if (!::scoreAText.isInitialized) return
        scoreAText.text = "${a.name}\n${a.score}/${a.target} Ball Points\nSL ${a.skill}"
        scoreBText.text = "${b.name}\n${b.score}/${b.target} Ball Points\nSL ${b.skill}"
        inningsText.text = "Rack $rack  •  $innings innings"
        val shooter = player(currentPlayer); shooterText.text = shooter.name; detailText.text = "Skill Level ${shooter.skill}  •  Breaker: ${player(breaker).name}"
        defenseButton.text = "${shooter.defensiveShots} Defensive Shots"; timeoutButton.text = "${shooter.timeoutsLeft} time-out${if (shooter.timeoutsLeft == 1) "" else "s"} left"
        playerPanelA.setBackgroundColor(if (currentPlayer == 0) Color.rgb(10, 112, 190) else navy); playerPanelB.setBackgroundColor(if (currentPlayer == 1) Color.rgb(10, 112, 190) else navy)
        ballViews.forEach { (n, v) -> v.state = ballStates[n]; v.visibility = if (ballLocked[n]) View.GONE else View.VISIBLE; v.isEnabled = !ballLocked[n] }
        refreshRackBallDisplays()
    }

    private fun refreshRackBallDisplays() {
        if (!::ballsARow.isInitialized) return
        ballsARow.removeAllViews(); ballsBRow.removeAllViews(); deadBallsRow.removeAllViews()
        for (n in 1..9) {
            if (ballStates[n] == BALL_POCKETED && ballOwners[n] == 0) ballsARow.addView(RackBallIconView(this, n), GridLayout.LayoutParams().apply { width = dp(32); height = dp(32) })
            if (ballStates[n] == BALL_POCKETED && ballOwners[n] == 1) ballsBRow.addView(RackBallIconView(this, n), GridLayout.LayoutParams().apply { width = dp(32); height = dp(32) })
            if (ballStates[n] == BALL_DEAD) deadBallsRow.addView(RackBallIconView(this, n), LinearLayout.LayoutParams(dp(32), dp(32)))
        }
        if (ballsARow.childCount == 0) ballsARow.addView(text("—", 14f, muted)); if (ballsBRow.childCount == 0) ballsBRow.addView(text("—", 14f, muted)); if (deadBallsRow.childCount == 0) deadBallsRow.addView(text("None", 13f, muted))
    }

    private fun showRackStats() {
        AlertDialog.Builder(this).setTitle("Rack $rack / Match Stats")
            .setMessage("${a.name}: ${a.score}/${a.target}\nDefensive shots: ${a.defensiveShots}\n9-on-the-Snap: $nineOnSnapA\nBreak & Runs: $breakRunsA\n\n${b.name}: ${b.score}/${b.target}\nDefensive shots: ${b.defensiveShots}\n9-on-the-Snap: $nineOnSnapB\nBreak & Runs: $breakRunsB\n\nInnings: $innings")
            .setPositiveButton("CLOSE", null).setNeutralButton("RACK HISTORY") { _, _ -> showRackHistory() }.show()
    }

    private fun showRackHistory() {
        saveActiveMatch(); val root = page("Rack History / Edit")
        root.addView(text("Tap any rack to edit who made each ball, dead balls, innings, timeouts and defensive shots.", 14f, muted, true))
        val records = rackRecords.toMutableList(); records.add(currentRackRecord())
        for (idx in records.indices.reversed()) {
            val r = records[idx]; val isCurrent = idx == records.lastIndex
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(if (isCurrent) Color.rgb(225, 241, 253) else Color.WHITE); setPadding(dp(10), dp(8), dp(10), dp(8)); isClickable = true }
            row.addView(text("Rack ${r.rackNumber}${if (isCurrent) "  •  LIVE" else ""}", 16f, if (isCurrent) blue else ink, true))
            val aBalls = (1..9).filter { r.ballStates[it] == BALL_POCKETED && r.ballOwners[it] == 0 }; val bBalls = (1..9).filter { r.ballStates[it] == BALL_POCKETED && r.ballOwners[it] == 1 }; val dead = (1..9).filter { r.ballStates[it] == BALL_DEAD }
            row.addView(text("${a.name}: ${aBalls.joinToString(", ").ifBlank { "—" }}\n${b.name}: ${bBalls.joinToString(", ").ifBlank { "—" }}${if (dead.isNotEmpty()) "\nDead: ${dead.joinToString(", ")}" else ""}", 14f, ink))
            row.setOnClickListener { showEditRack(idx, isCurrent) }
            root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        root.addView(button("BACK TO MATCH", true) { showScoreScreen() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(8) })
    }

    private fun showEditRack(index: Int, isCurrent: Boolean) {
        val source = if (isCurrent) currentRackRecord() else rackRecords[index]
        val editStates = source.ballStates.copyOf(); val editOwners = source.ballOwners.copyOf()
        val root = page("Edit Rack ${source.rackNumber}")
        root.addView(text("Tap a ball to cycle: ${a.name} → ${b.name} → Dead → Available", 14f, muted, true))
        val grid = GridLayout(this).apply { columnCount = 3; setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val statusLabels = mutableMapOf<Int, TextView>()
        fun status(n: Int): String = when { editStates[n] == BALL_POCKETED && editOwners[n] == 0 -> a.name; editStates[n] == BALL_POCKETED && editOwners[n] == 1 -> b.name; editStates[n] == BALL_DEAD -> "Dead"; else -> "Available" }
        for (n in 1..9) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(5), dp(3), dp(5)); setBackgroundColor(Color.WHITE) }
            val icon = RackBallIconView(this, n); val label = text(status(n), 12f, muted, true).apply { gravity = Gravity.CENTER }; statusLabels[n] = label
            cell.addView(icon, LinearLayout.LayoutParams(dp(58), dp(58))); cell.addView(label)
            cell.setOnClickListener {
                when { editStates[n] == BALL_AVAILABLE -> { editStates[n] = BALL_POCKETED; editOwners[n] = 0 }; editStates[n] == BALL_POCKETED && editOwners[n] == 0 -> editOwners[n] = 1; editStates[n] == BALL_POCKETED -> { editStates[n] = BALL_DEAD; editOwners[n] = -1 }; else -> { editStates[n] = BALL_AVAILABLE; editOwners[n] = -1 } }
                label.text = status(n)
            }
            grid.addView(cell, GridLayout.LayoutParams().apply { width = 0; height = dp(104); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
        }
        root.addView(grid)
        fun numberEditor(label: String, initial: Int): Pair<LinearLayout, TextView> {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(4), dp(8), dp(4)) }
            row.addView(text(label, 15f, ink, true), LinearLayout.LayoutParams(0, -2, 1f)); val value = text(initial.toString(), 17f, ink, true).apply { gravity = Gravity.CENTER }
            val minus = button("−") {}; val plus = button("+") {}
            minus.setOnClickListener { value.text = ((value.text.toString().toIntOrNull() ?: 0) - 1).coerceAtLeast(0).toString() }; plus.setOnClickListener { value.text = ((value.text.toString().toIntOrNull() ?: 0) + 1).toString() }
            row.addView(minus, LinearLayout.LayoutParams(dp(54), dp(48))); row.addView(value, LinearLayout.LayoutParams(dp(60), dp(48))); row.addView(plus, LinearLayout.LayoutParams(dp(54), dp(48))); return row to value
        }
        val (innRow, innVal) = numberEditor("Innings", source.innings); val (defARow, defAVal) = numberEditor("${a.name} defensive shots", source.defensiveA); val (defBRow, defBVal) = numberEditor("${b.name} defensive shots", source.defensiveB); val (toARow, toAVal) = numberEditor("${a.name} timeouts used", source.timeoutsA); val (toBRow, toBVal) = numberEditor("${b.name} timeouts used", source.timeoutsB)
        listOf(innRow, defARow, defBRow, toARow, toBRow).forEach { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }) }
        root.addView(button("SAVE RACK CHANGES", true) {
            source.ballStates = editStates; source.ballOwners = editOwners; source.innings = innVal.text.toString().toIntOrNull() ?: source.innings; source.defensiveA = defAVal.text.toString().toIntOrNull() ?: source.defensiveA; source.defensiveB = defBVal.text.toString().toIntOrNull() ?: source.defensiveB; source.timeoutsA = toAVal.text.toString().toIntOrNull() ?: source.timeoutsA; source.timeoutsB = toBVal.text.toString().toIntOrNull() ?: source.timeoutsB
            if (isCurrent) { for (i in 0..9) { ballStates[i] = source.ballStates[i]; ballOwners[i] = source.ballOwners[i] }; rackInnings = source.innings; rackDefenseA = source.defensiveA; rackDefenseB = source.defensiveB; rackTimeoutA = source.timeoutsA; rackTimeoutB = source.timeoutsB } else rackRecords[index] = source
            recalculateFromRackData(); saveActiveMatch(); showRackHistory()
        }, LinearLayout.LayoutParams(-1, dp(60)).apply { topMargin = dp(12) })
        root.addView(button("CANCEL") { showRackHistory() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(7) })
    }

    private fun pointsFor(r: RackRecord, owner: Int): Int = (1..9).sumOf { n -> if (r.ballStates[n] == BALL_POCKETED && r.ballOwners[n] == owner) if (n == 9) 2 else 1 else 0 }

    private fun recalculateFromRackData() {
        val all = rackRecords.toMutableList(); all.add(currentRackRecord())
        a.score = all.sumOf { pointsFor(it, 0) }; b.score = all.sumOf { pointsFor(it, 1) }
        a.defensiveShots = all.sumOf { it.defensiveA }; b.defensiveShots = all.sumOf { it.defensiveB }
        val usedA = all.sumOf { it.timeoutsA }; val usedB = all.sumOf { it.timeoutsB }; a.timeoutsLeft = (maxTimeouts(a) - usedA).coerceAtLeast(0); b.timeoutsLeft = (maxTimeouts(b) - usedB).coerceAtLeast(0)
        innings = all.sumOf { it.innings }; nineOnSnapA = rackRecords.count { it.nineOnSnapPlayer == 0 }; nineOnSnapB = rackRecords.count { it.nineOnSnapPlayer == 1 }; breakRunsA = rackRecords.count { it.breakRunPlayer == 0 }; breakRunsB = rackRecords.count { it.breakRunPlayer == 1 }
        rackPointsA.clear(); rackPointsB.clear(); all.forEach { rackPointsA.add(pointsFor(it, 0)); rackPointsB.add(pointsFor(it, 1)) }
        if (a.score < a.target && b.score < b.target) winnerDialogOpen = false
    }

    private fun rackToJson(r: RackRecord): JSONObject = JSONObject().apply {
        put("rack", r.rackNumber); put("breaker", r.breaker); put("states", JSONArray(r.ballStates.toList())); put("owners", JSONArray(r.ballOwners.toList())); put("innings", r.innings); put("defA", r.defensiveA); put("defB", r.defensiveB); put("toA", r.timeoutsA); put("toB", r.timeoutsB); put("snap", r.nineOnSnapPlayer); put("br", r.breakRunPlayer)
    }

    private fun jsonArrayToIntArray(arr: JSONArray?, size: Int, default: Int = 0): IntArray = IntArray(size) { i -> arr?.optInt(i, default) ?: default }

    private fun jsonToRack(o: JSONObject): RackRecord = RackRecord(o.optInt("rack", 1), o.optInt("breaker", 0), jsonArrayToIntArray(o.optJSONArray("states"), 10), jsonArrayToIntArray(o.optJSONArray("owners"), 10, -1), o.optInt("innings"), o.optInt("defA"), o.optInt("defB"), o.optInt("toA"), o.optInt("toB"), o.optInt("snap", -1), o.optInt("br", -1))

    private fun activeMatchJson(): JSONObject = JSONObject().apply {
        put("id", activeMatchId ?: UUID.randomUUID().toString()); put("updated", System.currentTimeMillis()); put("p1", a.name); put("p2", b.name); put("skill1", a.skill); put("skill2", b.skill); put("target1", a.target); put("target2", b.target); put("current", currentPlayer); put("rack", rack); put("breaker", breaker); put("turnovers", rackTurnovers); put("rackInnings", rackInnings); put("rackDefA", rackDefenseA); put("rackDefB", rackDefenseB); put("rackToA", rackTimeoutA); put("rackToB", rackTimeoutB); put("states", JSONArray(ballStates.toList())); put("owners", JSONArray(ballOwners.toList())); put("locked", JSONArray(ballLocked.map { if (it) 1 else 0 })); put("records", JSONArray().apply { rackRecords.forEach { put(rackToJson(it)) } })
    }

    private fun saveActiveMatch() {
        val id = activeMatchId ?: return; val arr = activeMatches(); val next = JSONArray(); var replaced = false
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; if (o.optString("id") == id) { next.put(activeMatchJson()); replaced = true } else next.put(o) }
        if (!replaced) next.put(activeMatchJson()); prefs.edit().putString("active_matches_v58", next.toString()).apply()
    }

    private fun removeActiveMatch(id: String?) {
        if (id == null) return; val arr = activeMatches(); val next = JSONArray(); for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; if (o.optString("id") != id) next.put(o) }; prefs.edit().putString("active_matches_v58", next.toString()).apply()
    }

    private fun loadActiveMatch(o: JSONObject) {
        activeMatchId = o.optString("id"); a = PracticePlayer(o.optString("p1", "Player 1"), o.optInt("skill1", 4), o.optInt("target1", 31)); b = PracticePlayer(o.optString("p2", "Player 2"), o.optInt("skill2", 4), o.optInt("target2", 31))
        currentPlayer = o.optInt("current"); rack = o.optInt("rack", 1); breaker = o.optInt("breaker"); rackTurnovers = o.optInt("turnovers"); rackInnings = o.optInt("rackInnings"); rackDefenseA = o.optInt("rackDefA"); rackDefenseB = o.optInt("rackDefB"); rackTimeoutA = o.optInt("rackToA"); rackTimeoutB = o.optInt("rackToB")
        val st = jsonArrayToIntArray(o.optJSONArray("states"), 10); val ow = jsonArrayToIntArray(o.optJSONArray("owners"), 10, -1); val lk = jsonArrayToIntArray(o.optJSONArray("locked"), 10)
        for (i in 0..9) { ballStates[i] = st[i]; ballOwners[i] = ow[i]; ballLocked[i] = lk[i] == 1 }
        rackRecords.clear(); val rec = o.optJSONArray("records"); if (rec != null) for (i in 0 until rec.length()) rackRecords.add(jsonToRack(rec.getJSONObject(i)))
        recalculateFromRackData(); undoStack.clear(); winnerDialogOpen = false; showScoreScreen()
    }

    private fun showActiveMatches() {
        val root = page("Active Matches"); val arr = activeMatches()
        if (arr.length() == 0) root.addView(text("No unfinished matches saved.", 17f, muted)) else {
            root.addView(text("Tap a match to resume it. Long-press to discard it.", 14f, muted, true))
            val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.sortedByDescending { it.optLong("updated") }
            items.forEach { o ->
                val entry = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)); isClickable = true; isLongClickable = true }
                val tmpA = o.optString("p1"); val tmpB = o.optString("p2"); entry.addView(text("$tmpA vs $tmpB", 17f, ink, true)); entry.addView(text("Rack ${o.optInt("rack", 1)}  •  Tap to continue", 14f, muted))
                entry.setOnClickListener { loadActiveMatch(o) }; entry.setOnLongClickListener { AlertDialog.Builder(this).setTitle("Discard unfinished match?").setMessage("$tmpA vs $tmpB").setNegativeButton("CANCEL", null).setPositiveButton("DISCARD") { _, _ -> removeActiveMatch(o.optString("id")); showActiveMatches() }.show(); true }
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        root.addView(button("NEW MATCH", true) { showSetup() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) }); root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
    }

    private fun standardApaTarget(skill: Int): Int = when (skill.coerceIn(1, 9)) { 1 -> 14; 2 -> 19; 3 -> 25; 4 -> 31; 5 -> 38; 6 -> 46; 7 -> 55; 8 -> 65; else -> 75 }

    private fun calculateApaMatchResult(winnerName: String): ApaMatchResult? {
        if (a.target != standardApaTarget(a.skill) || b.target != standardApaTarget(b.skill)) return null
        val winnerIsA = winnerName == a.name; val loser = if (winnerIsA) b else a; val loserBall = loser.score
        val maxBySkill = arrayOf(intArrayOf(2,3,4,6,7,8,10,11,13), intArrayOf(3,5,7,8,10,12,14,16,18), intArrayOf(4,6,9,11,14,16,19,21,24), intArrayOf(5,8,11,14,18,21,24,27,30), intArrayOf(6,10,14,18,22,26,29,33,37), intArrayOf(8,12,17,22,27,31,36,40,45), intArrayOf(10,15,21,26,32,37,43,49,54), intArrayOf(13,19,26,32,39,45,52,58,64), intArrayOf(17,24,31,38,46,53,60,67,74))
        val thresholds = maxBySkill[loser.skill - 1]; var loserPts = 0; for (i in thresholds.indices) if (loserBall <= thresholds[i]) { loserPts = i; break } else loserPts = 8
        val winnerPts = 20 - loserPts; return ApaMatchResult(if (winnerIsA) a.name else b.name, loser.name, winnerPts, loserPts, loser.skill, loserBall)
    }

    private fun confirmEndSession() {
        AlertDialog.Builder(this).setTitle("End practice session?").setMessage("You can keep this match in Active Matches or end it and save the current result to history.")
            .setNegativeButton("KEEP ACTIVE") { _, _ -> saveActiveMatch(); showHome() }.setPositiveButton("END & SAVE") { _, _ -> saveHistory(null); removeActiveMatch(activeMatchId); showHome() }.show()
    }

    private fun finalizeWinner(index: Int) {
        val winner = player(index); saveHistory(winner.name); removeActiveMatch(activeMatchId); showMatchComplete(winner)
    }

    private fun showMatchComplete(winner: PracticePlayer) {
        val apa = calculateApaMatchResult(winner.name); val h2h = headToHead(a.name, b.name)
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        summary.addView(text("${winner.name} wins!\n\n${a.name}: ${a.score}/${a.target}\nBreak & Runs: $breakRunsA  •  9-on-the-Snap: $nineOnSnapA\n\n${b.name}: ${b.score}/${b.target}\nBreak & Runs: $breakRunsB  •  9-on-the-Snap: $nineOnSnapB\n\nAll-time head-to-head: ${a.name} ${h2h.first} – ${h2h.second} ${b.name}", 15f, ink))
        summary.addView(RackPerformanceView(this, a.name, b.name, rackPointsA.toList(), rackPointsB.toList()), LinearLayout.LayoutParams(-1, dp(250)))
        if (apa != null) summary.addView(text("APA Score of Match: ${apa.winnerName} ${apa.winnerPoints} - ${apa.loserPoints} ${apa.loserName}", 14f, blue, true))
        AlertDialog.Builder(this).setTitle("PRACTICE MATCH COMPLETE").setView(summary).setCancelable(false).setPositiveButton("DONE") { _, _ -> showHome() }.show()
    }

    private fun saveHistory(winner: String?) {
        val arr = JSONArray(prefs.getString("history", "[]")); val recs = JSONArray().apply { rackRecords.forEach { put(rackToJson(it)) }; put(rackToJson(currentRackRecord())) }
        arr.put(JSONObject().apply {
            put("date", SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(Date())); put("p1", a.name); put("p2", b.name); put("score1", a.score); put("score2", b.score); put("target1", a.target); put("target2", b.target); put("skill1", a.skill); put("skill2", b.skill); put("innings", innings); put("racks", rack); put("def1", a.defensiveShots); put("def2", b.defensiveShots); put("timeoutsUsed1", maxTimeouts(a) - a.timeoutsLeft); put("timeoutsUsed2", maxTimeouts(b) - b.timeoutsLeft); put("snap1", nineOnSnapA); put("snap2", nineOnSnapB); put("br1", breakRunsA); put("br2", breakRunsB); put("rackPoints1", JSONArray(rackPointsA)); put("rackPoints2", JSONArray(rackPointsB)); put("rackRecords", recs); put("winner", winner ?: "Session ended")
            val apa = winner?.let { calculateApaMatchResult(it) }; if (apa != null) { put("apaWinner", apa.winnerName); put("apaLoser", apa.loserName); put("apaWinnerPoints", apa.winnerPoints); put("apaLoserPoints", apa.loserPoints); put("apaLoserSkill", apa.loserSkill); put("apaLoserBallPoints", apa.loserBallPoints) }
        })
        while (arr.length() > 100) { val trimmed = JSONArray(); for (i in 1 until arr.length()) trimmed.put(arr.get(i)); prefs.edit().putString("history", trimmed.toString()).apply(); return }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    private fun jsonIntList(o: JSONObject, key: String): List<Int> { val arr = o.optJSONArray(key) ?: return emptyList(); return (0 until arr.length()).map { arr.optInt(it, 0) } }

    private fun showHistoryMatch(o: JSONObject) {
        val p1 = o.optString("p1", "Player 1"); val p2 = o.optString("p2", "Player 2"); val rack1 = jsonIntList(o, "rackPoints1"); val rack2 = jsonIntList(o, "rackPoints2"); val root = page("Match Graph & Stats")
        root.addView(text("$p1 vs $p2", 21f, ink, true)); root.addView(text(o.optString("date"), 14f, muted)); val h = headToHead(p1, p2); root.addView(text("All-time head-to-head: $p1 ${h.first} – ${h.second} $p2  •  ${h.third} matches", 14f, blue, true))
        if (rack1.isNotEmpty() || rack2.isNotEmpty()) root.addView(RackPerformanceView(this, p1, p2, rack1, rack2), LinearLayout.LayoutParams(-1, dp(280)).apply { topMargin = dp(10); bottomMargin = dp(10) }) else root.addView(text("Rack-by-rack graph data was not saved for this older match.", 14f, muted))
        val stats = "${p1}: ${o.optInt("score1")}/${o.optInt("target1")} • SL ${o.optInt("skill1")} • Defensive ${o.optInt("def1")} • Timeouts ${o.optInt("timeoutsUsed1")} • 9-on-Snap ${o.optInt("snap1")} • Break & Runs ${o.optInt("br1")}\n\n${p2}: ${o.optInt("score2")}/${o.optInt("target2")} • SL ${o.optInt("skill2")} • Defensive ${o.optInt("def2")} • Timeouts ${o.optInt("timeoutsUsed2")} • 9-on-Snap ${o.optInt("snap2")} • Break & Runs ${o.optInt("br2")}"
        root.addView(text(stats, 14f, ink).apply { setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12)) })
        if (o.has("apaWinnerPoints")) root.addView(text("APA Score of Match: ${o.optString("apaWinner")} ${o.optInt("apaWinnerPoints")} - ${o.optInt("apaLoserPoints")} ${o.optString("apaLoser")}", 14f, blue, true))
        root.addView(button("BACK TO MATCH HISTORY", true) { showHistory() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(8) })
    }

    private fun showHistory() {
        val root = page("Practice History"); val arr = JSONArray(prefs.getString("history", "[]"))
        if (arr.length() == 0) root.addView(text("No practice sessions saved yet.", 17f, muted)) else {
            root.addView(text("Tap a match for Graph & Stats. Long-press a match to delete it.", 14f, muted, true))
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i); val entry = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)); isClickable = true; isLongClickable = true }
                entry.addView(text("${o.optString("p1")} ${o.optInt("score1")}/${o.optInt("target1")}   •   ${o.optString("p2")} ${o.optInt("score2")}/${o.optInt("target2")}", 16f, ink, true)); entry.addView(text("${o.optString("date")}  •  ${o.optInt("innings")} innings  •  ${o.optInt("racks")} racks", 13f, muted)); entry.addView(text("9-on-Snap ${o.optInt("snap1")}/${o.optInt("snap2")}  •  Break & Runs ${o.optInt("br1")}/${o.optInt("br2")}", 13f, muted))
                entry.setOnClickListener { showHistoryMatch(o) }; entry.setOnLongClickListener { AlertDialog.Builder(this).setTitle("Delete this match?").setMessage("${o.optString("p1")} vs ${o.optString("p2")}").setNegativeButton("CANCEL", null).setPositiveButton("DELETE") { _, _ -> val next = JSONArray(); for (j in 0 until arr.length()) if (j != i) next.put(arr.get(j)); prefs.edit().putString("history", next.toString()).apply(); showHistory() }.show(); true }
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        root.addView(button("CLEAR HISTORY") { AlertDialog.Builder(this).setTitle("Clear practice history?").setNegativeButton("CANCEL", null).setPositiveButton("CLEAR") { _, _ -> prefs.edit().remove("history").apply(); showHistory() }.show() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) }); root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
    }
}
