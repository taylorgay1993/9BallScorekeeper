# 9 Ball League Practice — V5.5

Independent 9-ball practice scorekeeper. Not affiliated with APA or any league organization.

## V5.5 changes
- Multiple simultaneously saved Active Matches with resume and long-press discard.
- Automatic save after scoring/actions so unfinished matches can be continued later.
- Winner detection as soon as a player reaches the target, with Edit Score or Confirm Win.
- Automatic Break & Run / 9-on-the-Snap detection with Yes/No confirmation.
- Per-player Break & Run and 9-on-the-Snap totals in match stats/history.
- Redesigned match screen focused on the two individual players; no team names, team scores, or match number.
- Lifetime head-to-head win totals for recurring player matchups.
- Swipe down from the top of the scoring screen to open Rack History / Edit.
- Rack-by-rack display showing who made each ball and dead balls.
- Rack editor for ball ownership/dead balls, innings, defensive shots, and timeouts.
- Rack edits recalculate match totals, graphs, winner state, and saved active-match state.
- Existing V5.4 history, graphs, APA-style match result calculation, custom launcher icon, and black/yellow 9-ball retained.

## Android package / version
- package: `com.nineball.scorekeeper`
- versionCode: `58`
- versionName: `5.5`
- minSdk: 26
- targetSdk: 36

Build the Android App Bundle with the same upload key previously used for this Google Play app.

## V5.6 changes
- 9-ball event flow improved: tapping the 9 immediately starts rack-end handling.
- Early 9s are classified as 9-on-the-Snap or 9 Ball Made Early when appropriate; other balls pocketed on the break no longer prevent snap recognition.
- Next-rack confirmation appears immediately after 9-ball handling, with Go Back for corrections.
- Match Complete player stat blocks have clearer spacing.
- End-of-match and historical graphs now plot cumulative score left-to-right, with score on the horizontal axis in 10-point increments and rack number on the vertical axis.
- Version 5.6 / versionCode 59.
