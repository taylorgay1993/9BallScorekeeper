# 9 Ball Practice Scorekeeper — V5.3

Android package: `com.nineball.scorekeeper`

Version: `5.3` (`versionCode 56`)

This build replaces the league-management workflow with a practice-first 9-ball scorekeeper.

## Core scoring

- Single tap balls 1–8: +1 point to the current player.
- Single tap 9-ball: +2 points to the current player.
- Double tap any ball: mark it dead, 0 points.
- Ball buttons visually show pocketed vs dead balls.
- Turn Over switches shooters. An inning increments after both players have completed a turn.
- Defensive Shot and Timeout counters track the current player.
- Undo restores the complete previous scoring state.
- Reaching the player's target automatically completes the practice match.
- 9-ball completion advances to a new rack.
- Practice history is stored locally on the phone.
- Tracks 9-on-the-snap and break-and-run stats when detected.

## Important Google Play update note

This project intentionally keeps the existing package name `com.nineball.scorekeeper` and increases the version code above 41 so it can be uploaded as an update to the existing Play Console app.

For Play Store updates, sign the new AAB with the SAME upload key used for the first Play Console upload. Do not generate a new upload key for V5.

## V5.1 addition — APA Score of Match

- When a practice match completes, the app calculates the APA 9-ball Score of Match using the losing player's skill level and final ball-point total.
- The result is displayed immediately on the match-complete dialog (for example, `Paige 16 - 4 Taylor`).
- The APA match score is saved in Practice History.
- Skill levels are saved with each history entry.
- The built-in chart follows the standard 20-0 through 12-8 APA 9-ball match-point table supplied for the feature.

## Version 5.2 / versionCode 54
- Pocketed balls are displayed under the player who made them for the current rack.
- Dead balls are displayed separately for the current rack.
- Ball buttons now cycle with taps: Available -> Pocketed -> Dead -> Available.
- Balls remain editable during the active turn, then become locked/hidden from the selectable area when TURN OVER is pressed.
- Match-winning points are not finalized until TURN OVER, allowing last-second scoring corrections.


## V5.3
- Pocketed-ball display under each player now wraps to two rows: balls 1-5 on the first row and 6-9 on the second, preventing clipping on phones.

## V5.3 additions
- Pocketed-ball display wraps cleanly to two rows: 1-5, then 6-9.
- Practice History supports selecting a single match, highlighting it, and deleting only that match after confirmation.
- Match-complete screen includes a per-rack performance line graph for both players plus average points per rack, best rack, and racks won.
- Setup fields automatically scroll above the numeric keyboard when focused.
- The active shooter’s player panel is highlighted and switches automatically on TURN OVER.

## V5.4
- Fixed launcher icon so Android uses the custom 9 Ball Scorekeeper / League Practice artwork instead of a generic Android placeholder.
- Added both standard and round launcher icon references.
- Version code 57, version name 5.4.
