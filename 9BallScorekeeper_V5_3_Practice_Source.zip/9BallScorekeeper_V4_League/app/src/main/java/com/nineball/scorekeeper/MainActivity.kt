package com.nineball.scorekeeper

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Path
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

private const val BALL_AVAILABLE = 0
private const val BALL_POCKETED = 1
private const val BALL_DEAD = 2

data class PracticePlayer(
    var name: String,
    var skill: Int,
    var target: Int,
    var score: Int = 0,
    var defensiveShots: Int = 0,
    var timeoutsLeft: Int = if (skill <= 3) 2 else 1
)

data class ApaMatchResult(
    val winnerName: String,
    val loserName: String,
    val winnerPoints: Int,
    val loserPoints: Int,
    val loserSkill: Int,
    val loserBallPoints: Int
)

data class MatchSnapshot(
    val scoreA: Int,
    val scoreB: Int,
    val defenseA: Int,
    val defenseB: Int,
    val timeoutsA: Int,
    val timeoutsB: Int,
    val currentPlayer: Int,
    val innings: Int,
    val rack: Int,
    val breaker: Int,
    val rackTurnovers: Int,
    val ballStates: IntArray,
    val ballOwners: IntArray,
    val ballLocked: BooleanArray,
    val nineOnSnapA: Int,
    val nineOnSnapB: Int,
    val breakRunsA: Int,
    val breakRunsB: Int,
    val rackPointsA: List<Int>,
    val rackPointsB: List<Int>
)

class BallView(
    context: Context,
    val ballNumber: Int,
    private val onTap: (Int) -> Unit
) : View(context) {
    var state: Int = BALL_AVAILABLE
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Ball $ballNumber. Tap to change status."
        setOnClickListener { onTap(ballNumber) }
    }

    private fun ballColor(n: Int): Int = when (n) {
        1, 9 -> Color.rgb(244, 190, 35)
        2 -> Color.rgb(35, 94, 168)
        3 -> Color.rgb(190, 35, 48)
        4 -> Color.rgb(112, 71, 145)
        5 -> Color.rgb(232, 113, 52)
        6 -> Color.rgb(60, 137, 64)
        7 -> Color.rgb(130, 32, 39)
        8 -> Color.rgb(24, 24, 24)
        else -> Color.DKGRAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * .42f
        val c = ballColor(ballNumber)

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)

        if (ballNumber <= 8) {
            paint.color = c
            canvas.drawCircle(cx, cy, r, paint)
        } else {
            paint.color = c
            val stripe = RectF(cx - r, cy - r * .47f, cx + r, cy + r * .47f)
            canvas.drawRoundRect(stripe, r * .25f, r * .25f, paint)
        }

        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .39f, paint)
        paint.color = Color.rgb(25, 25, 25)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * .62f
        paint.isFakeBoldText = true
        val fm = paint.fontMetrics
        canvas.drawText(ballNumber.toString(), cx, cy - (fm.ascent + fm.descent) / 2, paint)
        paint.isFakeBoldText = false

        if (state == BALL_POCKETED) {
            paint.color = Color.argb(165, 9, 80, 74)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .42f, cy, cx - r * .08f, cy + r * .34f, paint)
            canvas.drawLine(cx - r * .08f, cy + r * .34f, cx + r * .48f, cy - r * .35f, paint)
            paint.style = Paint.Style.FILL
        } else if (state == BALL_DEAD) {
            paint.color = Color.argb(180, 70, 70, 70)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .45f, cy - r * .45f, cx + r * .45f, cy + r * .45f, paint)
            canvas.drawLine(cx + r * .45f, cy - r * .45f, cx - r * .45f, cy + r * .45f, paint)
            paint.style = Paint.Style.FILL
        }
    }
}

class RackBallIconView(context: Context, private val ballNumber: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun ballColor(n: Int): Int = when (n) {
        1, 9 -> Color.rgb(244, 190, 35)
        2 -> Color.rgb(35, 94, 168)
        3 -> Color.rgb(190, 35, 48)
        4 -> Color.rgb(112, 71, 145)
        5 -> Color.rgb(232, 113, 52)
        6 -> Color.rgb(60, 137, 64)
        7 -> Color.rgb(130, 32, 39)
        8 -> Color.rgb(24, 24, 24)
        else -> Color.DKGRAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * .42f
        val c = ballColor(ballNumber)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)
        if (ballNumber <= 8) {
            paint.color = c
            canvas.drawCircle(cx, cy, r, paint)
        } else {
            paint.color = c
            val stripe = RectF(cx - r, cy - r * .47f, cx + r, cy + r * .47f)
            canvas.drawRoundRect(stripe, r * .25f, r * .25f, paint)
        }
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .39f, paint)
        paint.color = Color.rgb(25, 25, 25)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * .62f
        paint.isFakeBoldText = true
        val fm = paint.fontMetrics
        canvas.drawText(ballNumber.toString(), cx, cy - (fm.ascent + fm.descent) / 2, paint)
        paint.isFakeBoldText = false
    }
}


class RackPerformanceView(
    context: Context,
    private val playerA: String,
    private val playerB: String,
    private val aPoints: List<Int>,
    private val bPoints: List<Int>
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Color.rgb(210, 218, 225)
    private val ink = Color.rgb(40, 50, 60)
    private val aColor = Color.rgb(22, 111, 169)
    private val bColor = Color.rgb(9, 121, 113)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = 52f
        val right = width - 20f
        val top = 28f
        val bottom = height - 48f
        val count = maxOf(aPoints.size, bPoints.size).coerceAtLeast(1)
        val maxVal = maxOf(10, (aPoints + bPoints).maxOrNull() ?: 0)

        paint.textSize = 24f
        paint.color = ink
        paint.isFakeBoldText = true
        canvas.drawText("Points per rack", left, 22f, paint)
        paint.isFakeBoldText = false
        paint.textSize = 18f

        for (i in 0..5) {
            val y = bottom - (bottom - top) * i / 5f
            paint.color = grid
            paint.strokeWidth = 1f
            canvas.drawLine(left, y, right, y, paint)
            paint.color = ink
            val value = (maxVal * i / 5f).toInt()
            canvas.drawText(value.toString(), 8f, y + 6f, paint)
        }

        fun xFor(i: Int): Float = if (count == 1) (left + right) / 2f else left + (right - left) * i / (count - 1f)
        fun yFor(v: Int): Float = bottom - (bottom - top) * v / maxVal.toFloat()
        fun drawSeries(values: List<Int>, color: Int) {
            if (values.isEmpty()) return
            paint.color = color
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            val path = Path()
            values.forEachIndexed { i, v ->
                val x = xFor(i); val y = yFor(v)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.FILL
            values.forEachIndexed { i, v -> canvas.drawCircle(xFor(i), yFor(v), 7f, paint) }
        }
        drawSeries(aPoints, aColor)
        drawSeries(bPoints, bColor)

        paint.textSize = 16f
        paint.color = ink
        (0 until count).forEach { i -> canvas.drawText("R${i+1}", xFor(i)-10f, height-22f, paint) }
        paint.color = aColor; canvas.drawText(playerA, left, height-3f, paint)
        paint.color = bColor; canvas.drawText(playerB, left + 150f, height-3f, paint)
    }
}

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("practice_scorekeeper_v5", Context.MODE_PRIVATE) }

    private val navy = Color.rgb(13, 41, 64)
    private val blue = Color.rgb(22, 111, 169)
    private val teal = Color.rgb(9, 121, 113)
    private val gold = Color.rgb(231, 174, 51)
    private val card = Color.rgb(244, 247, 249)
    private val ink = Color.rgb(25, 35, 45)
    private val muted = Color.rgb(92, 105, 116)

    private var a = PracticePlayer("Player 1", 4, 31)
    private var b = PracticePlayer("Player 2", 4, 31)
    private var currentPlayer = 0
    private var innings = 0
    private var rack = 1
    private var breaker = 0
    private var rackTurnovers = 0
    private var nineOnSnapA = 0
    private var nineOnSnapB = 0
    private var breakRunsA = 0
    private var breakRunsB = 0
    private val rackPointsA = mutableListOf(0)
    private val rackPointsB = mutableListOf(0)
    private val ballStates = IntArray(10)
    private val ballOwners = IntArray(10) { -1 }
    private val ballLocked = BooleanArray(10)
    private val undoStack = ArrayDeque<MatchSnapshot>()

    private lateinit var scoreAText: TextView
    private lateinit var scoreBText: TextView
    private lateinit var inningsText: TextView
    private lateinit var shooterText: TextView
    private lateinit var detailText: TextView
    private lateinit var defenseButton: Button
    private lateinit var timeoutButton: Button
    private lateinit var ballsARow: GridLayout
    private lateinit var ballsBRow: GridLayout
    private lateinit var deadBallsRow: LinearLayout
    private lateinit var playerPanelA: LinearLayout
    private lateinit var playerPanelB: LinearLayout
    private val ballViews = mutableMapOf<Int, BallView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float = 16f, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(dp(6), dp(7), dp(6), dp(7))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        setBackgroundColor(if (primary) blue else navy)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { action() }
    }

    private fun page(title: String): LinearLayout {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(236, 241, 245)); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        val titleBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(navy)
        }
        titleBar.addView(text(title, 24f, Color.WHITE, true))
        root.addView(titleBar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        scroll.addView(root)
        setContentView(scroll)
        return root
    }

    private fun showHome() {
        val root = page("9 Ball Practice Scorekeeper")
        root.addView(text("Practice matches with ball-by-ball scoring", 17f, muted))
        root.addView(text("Tap a ball to score it. Tap again to mark it dead.", 16f, ink, true))
        root.addView(button("START PRACTICE MATCH", true) { showSetup() }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(18) })
        root.addView(button("PRACTICE HISTORY") { showHistory() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) })
        root.addView(text("Designed for practice. No teams, standings, schedules, or league-night management.", 14f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
    }

    private fun labeledField(root: LinearLayout, label: String, default: String, numeric: Boolean = false): EditText {
        root.addView(text(label, 14f, muted, true))
        return EditText(this).apply {
            setText(default)
            textSize = 18f
            setTextColor(ink)
            setBackgroundColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            root.addView(this, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(10) })
        }
    }

    private fun showSetup() {
        val root = page("New Practice Match")
        val p1 = labeledField(root, "Player 1", prefs.getString("last_p1", "Player 1") ?: "Player 1")
        val p1Skill = labeledField(root, "Player 1 skill level", prefs.getInt("last_sl1", 4).toString(), true)
        val p1Target = labeledField(root, "Player 1 target ball points", prefs.getInt("last_target1", 31).toString(), true)
        val p2 = labeledField(root, "Player 2", prefs.getString("last_p2", "Player 2") ?: "Player 2")
        val p2Skill = labeledField(root, "Player 2 skill level", prefs.getInt("last_sl2", 4).toString(), true)
        val p2Target = labeledField(root, "Player 2 target ball points", prefs.getInt("last_target2", 31).toString(), true)
        listOf(p1, p1Skill, p1Target, p2, p2Skill, p2Target).forEach { field ->
            field.setOnFocusChangeListener { v, hasFocus ->
                if (hasFocus) v.postDelayed({ (root.parent as? ScrollView)?.smoothScrollTo(0, (v.bottom - dp(40)).coerceAtLeast(0)) }, 250)
            }
        }

        root.addView(text("First breaker", 14f, muted, true))
        val firstBreaker = Spinner(this)
        firstBreaker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Player 1", "Player 2"))
        root.addView(firstBreaker, LinearLayout.LayoutParams(-1, dp(58)))

        root.addView(button("START SCORING", true) {
            val n1 = p1.text.toString().trim().ifBlank { "Player 1" }
            val n2 = p2.text.toString().trim().ifBlank { "Player 2" }
            val sl1 = (p1Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9)
            val sl2 = (p2Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9)
            val t1 = (p1Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1)
            val t2 = (p2Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1)
            prefs.edit().putString("last_p1", n1).putString("last_p2", n2)
                .putInt("last_sl1", sl1).putInt("last_sl2", sl2)
                .putInt("last_target1", t1).putInt("last_target2", t2).apply()
            startMatch(n1, sl1, t1, n2, sl2, t2, firstBreaker.selectedItemPosition)
        }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(16) })
        root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) })
    }

    private fun startMatch(n1: String, sl1: Int, t1: Int, n2: String, sl2: Int, t2: Int, firstBreaker: Int) {
        a = PracticePlayer(n1, sl1, t1)
        b = PracticePlayer(n2, sl2, t2)
        currentPlayer = firstBreaker
        breaker = firstBreaker
        innings = 0
        rack = 1
        rackTurnovers = 0
        nineOnSnapA = 0; nineOnSnapB = 0; breakRunsA = 0; breakRunsB = 0
        rackPointsA.clear(); rackPointsA.add(0)
        rackPointsB.clear(); rackPointsB.add(0)
        ballStates.fill(BALL_AVAILABLE)
        ballOwners.fill(-1)
        ballLocked.fill(false)
        undoStack.clear()
        showScoreScreen()
    }

    private fun showScoreScreen() {
        val root = page("Practice Match")

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE) }
        playerPanelA = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)) }
        val left = playerPanelA
        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(8), dp(6), dp(8)) }
        playerPanelB = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); gravity = Gravity.END }
        val right = playerPanelB
        scoreAText = text("", 17f, ink, true)
        scoreBText = text("", 17f, ink, true).apply { gravity = Gravity.END }
        inningsText = text("", 17f, blue, true).apply { gravity = Gravity.CENTER }
        left.addView(scoreAText)
        center.addView(text("INNINGS", 11f, muted, true).apply { gravity = Gravity.CENTER })
        center.addView(inningsText)
        right.addView(scoreBText)
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(center, LinearLayout.LayoutParams(dp(92), -2))
        top.addView(right, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val rackBallPanel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); setPadding(dp(6), dp(4), dp(6), dp(6)) }
        val rackA = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rackB = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rackA.addView(text("Balls this rack", 11f, muted, true))
        rackB.addView(text("Balls this rack", 11f, muted, true).apply { gravity = Gravity.END })
        ballsARow = GridLayout(this).apply { columnCount = 5; rowCount = 2; alignmentMode = GridLayout.ALIGN_BOUNDS; gravity = Gravity.START }
        ballsBRow = GridLayout(this).apply { columnCount = 5; rowCount = 2; alignmentMode = GridLayout.ALIGN_BOUNDS; gravity = Gravity.END }
        rackA.addView(ballsARow, LinearLayout.LayoutParams(-1, dp(72)))
        rackB.addView(ballsBRow, LinearLayout.LayoutParams(-1, dp(72)))
        rackBallPanel.addView(rackA, LinearLayout.LayoutParams(0, -2, 1f))
        rackBallPanel.addView(rackB, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(rackBallPanel, LinearLayout.LayoutParams(-1, -2))

        val deadPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(6), dp(2), dp(6), dp(6)) }
        deadPanel.addView(text("Dead balls", 11f, muted, true).apply { gravity = Gravity.CENTER })
        deadBallsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        deadPanel.addView(deadBallsRow, LinearLayout.LayoutParams(-1, dp(40)))
        root.addView(deadPanel, LinearLayout.LayoutParams(-1, -2))

        shooterText = text("", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setBackgroundColor(teal); setPadding(dp(8), dp(14), dp(8), dp(14)) }
        root.addView(shooterText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        detailText = text("", 14f, muted).apply { gravity = Gravity.CENTER; setBackgroundColor(Color.WHITE) }
        root.addView(detailText, LinearLayout.LayoutParams(-1, -2))

        root.addView(text("Tap once = pocketed  •  Tap again = dead  •  Tap again = available", 14f, muted, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        ballViews.clear()
        val ballArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(6), dp(2), dp(6)); setBackgroundColor(Color.WHITE) }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (n in 1..9) {
            val bv = BallView(this, n, ::cycleBallState)
            ballViews[n] = bv
            val params = LinearLayout.LayoutParams(0, dp(78), 1f).apply { marginStart = dp(1); marginEnd = dp(1) }
            if (n <= 5) row1.addView(bv, params) else row2.addView(bv, params)
        }
        ballArea.addView(row1, LinearLayout.LayoutParams(-1, -2))
        ballArea.addView(row2, LinearLayout.LayoutParams(-1, -2))
        root.addView(ballArea)

        val turnButton = button("TURN OVER", true) { turnOver() }
        root.addView(turnButton, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(8) })

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        defenseButton = button("DEFENSIVE SHOT") { markDefensiveShot() }
        timeoutButton = button("TIMEOUT") { useTimeout() }
        actionRow.addView(defenseButton, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(timeoutButton, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(4) })
        root.addView(actionRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val lowerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lowerRow.addView(button("UNDO") { undo() }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(4) })
        lowerRow.addView(button("RACK / STATS") { showRackStats() }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(4) })
        root.addView(lowerRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(button("END PRACTICE SESSION") { confirmEndSession() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })

        refreshScoreScreen()
    }

    private fun player(index: Int): PracticePlayer = if (index == 0) a else b

    private fun saveSnapshot() {
        undoStack.addLast(MatchSnapshot(
            a.score, b.score, a.defensiveShots, b.defensiveShots, a.timeoutsLeft, b.timeoutsLeft,
            currentPlayer, innings, rack, breaker, rackTurnovers, ballStates.copyOf(),
            ballOwners.copyOf(), ballLocked.copyOf(),
            nineOnSnapA, nineOnSnapB, breakRunsA, breakRunsB, rackPointsA.toList(), rackPointsB.toList()
        ))
        while (undoStack.size > 80) undoStack.removeFirst()
    }

    private fun undo() {
        val s = if (undoStack.isEmpty()) null else undoStack.removeLast()
        if (s == null) {
            Toast.makeText(this, "Nothing to undo.", Toast.LENGTH_SHORT).show(); return
        }
        a.score = s.scoreA; b.score = s.scoreB
        a.defensiveShots = s.defenseA; b.defensiveShots = s.defenseB
        a.timeoutsLeft = s.timeoutsA; b.timeoutsLeft = s.timeoutsB
        currentPlayer = s.currentPlayer; innings = s.innings; rack = s.rack; breaker = s.breaker; rackTurnovers = s.rackTurnovers
        for (i in ballStates.indices) {
            ballStates[i] = s.ballStates[i]
            ballOwners[i] = s.ballOwners[i]
            ballLocked[i] = s.ballLocked[i]
        }
        nineOnSnapA = s.nineOnSnapA; nineOnSnapB = s.nineOnSnapB; breakRunsA = s.breakRunsA; breakRunsB = s.breakRunsB
        rackPointsA.clear(); rackPointsA.addAll(s.rackPointsA)
        rackPointsB.clear(); rackPointsB.addAll(s.rackPointsB)
        refreshScoreScreen()
    }

    private fun cycleBallState(n: Int) {
        if (ballLocked[n]) return
        saveSnapshot()
        when (ballStates[n]) {
            BALL_AVAILABLE -> {
                val p = player(currentPlayer)
                val pts = if (n == 9) 2 else 1
                p.score += pts
                if (currentPlayer == 0) rackPointsA[rack - 1] += pts else rackPointsB[rack - 1] += pts
                ballStates[n] = BALL_POCKETED
                ballOwners[n] = currentPlayer
                refreshScoreScreen()
                if (p.score >= p.target) {
                    Toast.makeText(this, "${p.name} reached the target. Tap again if this ball needs correcting, or press TURN OVER to confirm.", Toast.LENGTH_LONG).show()
                }
                if (n == 9) {
                    Toast.makeText(this, "9-ball credited to ${p.name}. Tap again if it should be dead, then use TURN OVER to finish the rack.", Toast.LENGTH_LONG).show()
                }
            }
            BALL_POCKETED -> {
                val owner = ballOwners[n]
                if (owner == 0 || owner == 1) {
                    val p = player(owner)
                    val pts = if (n == 9) 2 else 1
                    p.score = (p.score - pts).coerceAtLeast(0)
                    if (owner == 0) rackPointsA[rack - 1] = (rackPointsA[rack - 1] - pts).coerceAtLeast(0) else rackPointsB[rack - 1] = (rackPointsB[rack - 1] - pts).coerceAtLeast(0)
                }
                ballStates[n] = BALL_DEAD
                ballOwners[n] = -1
                refreshScoreScreen()
                Toast.makeText(this, "Ball $n changed to dead — 0 points.", Toast.LENGTH_SHORT).show()
            }
            BALL_DEAD -> {
                ballStates[n] = BALL_AVAILABLE
                ballOwners[n] = -1
                refreshScoreScreen()
                Toast.makeText(this, "Ball $n returned to available.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun turnOver() {
        saveSnapshot()
        val shooter = currentPlayer
        val nineWasPocketed = ballStates[9] == BALL_POCKETED
        val nineWasDead = ballStates[9] == BALL_DEAD
        for (n in 1..9) {
            if (ballStates[n] != BALL_AVAILABLE) ballLocked[n] = true
        }

        val shooterPlayer = player(shooter)
        if (shooterPlayer.score >= shooterPlayer.target) {
            for (n in 1..9) {
                if (ballStates[n] != BALL_AVAILABLE) ballLocked[n] = true
            }
            refreshScoreScreen()
            finishMatch(shooterPlayer)
            return
        }

        if (nineWasPocketed || nineWasDead) {
            if (nineWasPocketed && rackTurnovers == 0 && shooter == breaker) {
                if (shooter == 0) breakRunsA++ else breakRunsB++
                if ((1..8).all { ballStates[it] == BALL_AVAILABLE }) {
                    if (shooter == 0) nineOnSnapA++ else nineOnSnapB++
                }
            }
            startNextRack(shooter)
            return
        }

        rackTurnovers++
        if (currentPlayer == 1) innings++
        currentPlayer = 1 - currentPlayer
        refreshScoreScreen()
    }

    private fun markDefensiveShot() {
        saveSnapshot()
        player(currentPlayer).defensiveShots++
        refreshScoreScreen()
        Toast.makeText(this, "Defensive shot added for ${player(currentPlayer).name}.", Toast.LENGTH_SHORT).show()
    }

    private fun useTimeout() {
        val p = player(currentPlayer)
        if (p.timeoutsLeft <= 0) {
            Toast.makeText(this, "${p.name} has no timeouts left.", Toast.LENGTH_SHORT).show(); return
        }
        saveSnapshot()
        p.timeoutsLeft--
        refreshScoreScreen()
    }

    private fun startNextRack(nextBreaker: Int) {
        rack++
        rackPointsA.add(0); rackPointsB.add(0)
        breaker = nextBreaker
        currentPlayer = nextBreaker
        rackTurnovers = 0
        ballStates.fill(BALL_AVAILABLE)
        ballOwners.fill(-1)
        ballLocked.fill(false)
        refreshScoreScreen()
    }

    private fun refreshScoreScreen() {
        if (!::scoreAText.isInitialized) return
        scoreAText.text = "${a.name}\n${a.score}/${a.target} pts\nSL ${a.skill}"
        scoreBText.text = "${b.name}\n${b.score}/${b.target} pts\nSL ${b.skill}"
        inningsText.text = innings.toString()
        val shooter = player(currentPlayer)
        shooterText.text = "${shooter.name}'s turn"
        detailText.text = "Rack $rack  •  Breaker: ${player(breaker).name}\nRemaining: ${maxOf(0, a.target - a.score)} / ${maxOf(0, b.target - b.score)} ball points"
        defenseButton.text = "DEFENSIVE SHOTS\n${shooter.defensiveShots}"
        timeoutButton.text = "TIMEOUTS LEFT\n${shooter.timeoutsLeft}"
        val activeBg = Color.rgb(255, 244, 204)
        playerPanelA.setBackgroundColor(if (currentPlayer == 0) activeBg else Color.WHITE)
        playerPanelB.setBackgroundColor(if (currentPlayer == 1) activeBg else Color.WHITE)
        ballViews.forEach { (n, v) ->
            v.state = ballStates[n]
            v.visibility = if (ballLocked[n]) View.GONE else View.VISIBLE
            v.isEnabled = !ballLocked[n]
        }
        refreshRackBallDisplays()
    }

    private fun refreshRackBallDisplays() {
        if (!::ballsARow.isInitialized) return
        ballsARow.removeAllViews()
        ballsBRow.removeAllViews()
        deadBallsRow.removeAllViews()

        for (n in 1..9) {
            if (ballStates[n] == BALL_POCKETED && ballOwners[n] == 0) {
                ballsARow.addView(RackBallIconView(this, n), GridLayout.LayoutParams().apply { width = dp(34); height = dp(34) })
            }
            if (ballStates[n] == BALL_POCKETED && ballOwners[n] == 1) {
                ballsBRow.addView(RackBallIconView(this, n), GridLayout.LayoutParams().apply { width = dp(34); height = dp(34) })
            }
            if (ballStates[n] == BALL_DEAD) {
                deadBallsRow.addView(RackBallIconView(this, n), LinearLayout.LayoutParams(dp(34), dp(34)))
            }
        }
        if (ballsARow.childCount == 0) ballsARow.addView(text("—", 14f, muted), GridLayout.LayoutParams().apply { width = dp(34); height = dp(34) })
        if (ballsBRow.childCount == 0) ballsBRow.addView(text("—", 14f, muted).apply { gravity = Gravity.END }, GridLayout.LayoutParams().apply { width = dp(34); height = dp(34) })
        if (deadBallsRow.childCount == 0) deadBallsRow.addView(text("None", 13f, muted))
    }

    private fun showRackStats() {
        val dead = (1..9).filter { ballStates[it] == BALL_DEAD }.joinToString(", ").ifBlank { "None" }
        val pocketed = (1..9).filter { ballStates[it] == BALL_POCKETED }.joinToString(", ").ifBlank { "None" }
        AlertDialog.Builder(this)
            .setTitle("Rack $rack / Match Stats")
            .setMessage(
                "Pocketed this rack: $pocketed\nDead this rack: $dead\n\n" +
                    "${a.name}: ${a.score}/${a.target}, ${a.defensiveShots} safeties, $nineOnSnapA 9-on-snap, $breakRunsA break-and-run\n" +
                    "${b.name}: ${b.score}/${b.target}, ${b.defensiveShots} safeties, $nineOnSnapB 9-on-snap, $breakRunsB break-and-run\n\n" +
                    "Innings: $innings"
            )
            .setPositiveButton("CLOSE", null)
            .setNeutralButton("NEW RACK") { _, _ ->
                saveSnapshot(); startNextRack(1 - breaker)
            }
            .show()
    }

    private fun standardApaTarget(skill: Int): Int = when (skill.coerceIn(1, 9)) {
        1 -> 14
        2 -> 19
        3 -> 25
        4 -> 31
        5 -> 38
        6 -> 46
        7 -> 55
        8 -> 65
        else -> 75
    }

    private fun calculateApaMatchResult(winnerName: String): ApaMatchResult? {
        val winnerIndex = when (winnerName) {
            a.name -> 0
            b.name -> 1
            else -> return null
        }
        val loser = if (winnerIndex == 0) b else a
        val winner = if (winnerIndex == 0) a else b

        // Maximum losing-ball totals for each APA 9-ball match-point split,
        // ordered 20-0, 19-1, 18-2, 17-3, 16-4, 15-5, 14-6, 13-7, 12-8.
        val maxBySkill = arrayOf(
            intArrayOf(2, 3, 4, 6, 7, 8, 10, 11, 13),
            intArrayOf(3, 5, 7, 8, 10, 12, 14, 16, 18),
            intArrayOf(4, 6, 9, 11, 14, 16, 19, 21, 24),
            intArrayOf(5, 8, 11, 14, 18, 21, 24, 27, 30),
            intArrayOf(6, 10, 14, 18, 22, 26, 29, 33, 37),
            intArrayOf(8, 12, 17, 22, 27, 31, 36, 40, 45),
            intArrayOf(10, 15, 21, 26, 32, 37, 43, 49, 54),
            intArrayOf(13, 19, 26, 32, 39, 45, 52, 58, 64),
            intArrayOf(17, 24, 31, 38, 46, 53, 60, 67, 74)
        )
        val maxes = maxBySkill[loser.skill.coerceIn(1, 9) - 1]
        val column = maxes.indexOfFirst { loser.score <= it }.let { if (it == -1) 8 else it }
        val loserMatchPoints = column
        val winnerMatchPoints = 20 - loserMatchPoints
        return ApaMatchResult(
            winnerName = winner.name,
            loserName = loser.name,
            winnerPoints = winnerMatchPoints,
            loserPoints = loserMatchPoints,
            loserSkill = loser.skill,
            loserBallPoints = loser.score
        )
    }

    private fun confirmEndSession() {
        AlertDialog.Builder(this).setTitle("End practice session?")
            .setMessage("The current scores and stats will be saved to practice history.")
            .setNegativeButton("KEEP SCORING", null)
            .setPositiveButton("END SESSION") { _, _ -> saveHistory(null); showHome() }
            .show()
    }

    private fun finishMatch(winner: PracticePlayer) {
        val apa = calculateApaMatchResult(winner.name)
        saveHistory(winner.name)
        val apaText = if (apa != null) {
            "\n\nAPA SCORE OF MATCH\n${apa.winnerName} ${apa.winnerPoints} - ${apa.loserPoints} ${apa.loserName}" +
                "\n(Losing SL ${apa.loserSkill}, ${apa.loserBallPoints} ball points)"
        } else ""
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        summary.addView(text(
            "${winner.name} reached the target.\n\n${a.name}: ${a.score}/${a.target} (SL ${a.skill})\n${b.name}: ${b.score}/${b.target} (SL ${b.skill})\nInnings: $innings\nRacks: $rack" + apaText,
            15f, ink
        ))
        summary.addView(RackPerformanceView(this, a.name, b.name, rackPointsA.toList(), rackPointsB.toList()), LinearLayout.LayoutParams(-1, dp(260)))
        val avgA = if (rackPointsA.isEmpty()) 0.0 else rackPointsA.average()
        val avgB = if (rackPointsB.isEmpty()) 0.0 else rackPointsB.average()
        val racksWonA = rackPointsA.zip(rackPointsB).count { it.first > it.second }
        val racksWonB = rackPointsA.zip(rackPointsB).count { it.second > it.first }
        summary.addView(text(
            "${a.name}: avg %.1f/rack • best ${rackPointsA.maxOrNull() ?: 0} • racks won $racksWonA\n${b.name}: avg %.1f/rack • best ${rackPointsB.maxOrNull() ?: 0} • racks won $racksWonB".format(avgA, avgB),
            13f, muted, true
        ))
        AlertDialog.Builder(this)
            .setTitle("PRACTICE MATCH COMPLETE")
            .setView(summary)
            .setCancelable(false)
            .setPositiveButton("DONE") { _, _ -> showHome() }
            .show()
    }

    private fun saveHistory(winner: String?) {
        val arr = JSONArray(prefs.getString("history", "[]"))
        arr.put(JSONObject().apply {
            put("date", SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(Date()))
            put("p1", a.name); put("p2", b.name)
            put("score1", a.score); put("score2", b.score)
            put("target1", a.target); put("target2", b.target)
            put("skill1", a.skill); put("skill2", b.skill)
            put("innings", innings); put("racks", rack)
            put("def1", a.defensiveShots); put("def2", b.defensiveShots)
            put("snap1", nineOnSnapA); put("snap2", nineOnSnapB)
            put("br1", breakRunsA); put("br2", breakRunsB)
            put("rackPoints1", JSONArray(rackPointsA)); put("rackPoints2", JSONArray(rackPointsB))
            val apa = winner?.let { calculateApaMatchResult(it) }
            if (apa != null) {
                put("apaWinner", apa.winnerName)
                put("apaLoser", apa.loserName)
                put("apaWinnerPoints", apa.winnerPoints)
                put("apaLoserPoints", apa.loserPoints)
                put("apaLoserSkill", apa.loserSkill)
                put("apaLoserBallPoints", apa.loserBallPoints)
            }
            put("winner", winner ?: "Session ended")
        })
        while (arr.length() > 100) {
            val trimmed = JSONArray()
            for (i in 1 until arr.length()) trimmed.put(arr.get(i))
            prefs.edit().putString("history", trimmed.toString()).apply()
            return
        }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    private fun showHistory() {
        val root = page("Practice History")
        val arr = JSONArray(prefs.getString("history", "[]"))
        var selected = -1
        val entries = mutableListOf<LinearLayout>()
        val deleteButton = button("DELETE SELECTED MATCH") {
            if (selected < 0) {
                Toast.makeText(this, "Tap a match first.", Toast.LENGTH_SHORT).show()
                return@button
            }
            val selectedObj = arr.getJSONObject(selected)
            AlertDialog.Builder(this)
                .setTitle("Delete this match?")
                .setMessage("${selectedObj.optString("p1")} vs ${selectedObj.optString("p2")}\n${selectedObj.optString("date")}")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE") { _, _ ->
                    val next = JSONArray()
                    for (j in 0 until arr.length()) if (j != selected) next.put(arr.get(j))
                    prefs.edit().putString("history", next.toString()).apply()
                    showHistory()
                }.show()
        }.apply { visibility = View.GONE }

        if (arr.length() == 0) {
            root.addView(text("No practice sessions saved yet.", 17f, muted))
        } else {
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i)
                val entry = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(Color.WHITE)
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    isClickable = true
                }
                val sl1 = o.optInt("skill1", 0)
                val sl2 = o.optInt("skill2", 0)
                val sl1Text = if (sl1 > 0) " (SL $sl1)" else ""
                val sl2Text = if (sl2 > 0) " (SL $sl2)" else ""
                entry.addView(text("${o.optString("p1")}$sl1Text  ${o.optInt("score1")}/${o.optInt("target1")}   •   ${o.optString("p2")}$sl2Text  ${o.optInt("score2")}/${o.optInt("target2")}", 16f, ink, true))
                if (o.has("apaWinnerPoints")) {
                    entry.addView(text("APA Score of Match: ${o.optString("apaWinner")} ${o.optInt("apaWinnerPoints")} - ${o.optInt("apaLoserPoints")} ${o.optString("apaLoser")}", 15f, blue, true))
                }
                entry.addView(text("${o.optString("date")}  •  ${o.optInt("innings")} innings  •  ${o.optInt("racks")} racks", 13f, muted))
                entry.addView(text("Defensive shots ${o.optInt("def1")}/${o.optInt("def2")}  •  9-on-snap ${o.optInt("snap1")}/${o.optInt("snap2")}  •  Break-runs ${o.optInt("br1")}/${o.optInt("br2")}", 13f, muted))
                entry.setOnClickListener {
                    selected = i
                    entries.forEach { it.setBackgroundColor(Color.WHITE) }
                    entry.setBackgroundColor(Color.rgb(255, 244, 204))
                    deleteButton.visibility = View.VISIBLE
                }
                entries.add(entry)
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        root.addView(deleteButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        root.addView(button("CLEAR HISTORY") {
            AlertDialog.Builder(this).setTitle("Clear practice history?").setNegativeButton("CANCEL", null)
                .setPositiveButton("CLEAR") { _, _ -> prefs.edit().remove("history").apply(); showHistory() }.show()
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
    }

}
