9 Ball League Practice V5.7

Version code: 61
Version name: 5.7

V5.7 visual refresh:
- Original dark/neon home screen with prominent Start Match action.
- Redesigned scoring surface with dark player/rack panels and green End Turn action.
- Keeps V5.6.1 9-ball classification and Rack History/Edit button fixes.
- Match result display uses neutral “Match Points” wording.
- Existing scoring, active matches, history, graphs, stats, rack editor, and local persistence retained.
