9 Ball League Practice V5.7.2
Version code: 64

UI rebuild to match the approved mockups much more closely:
- premium home screen hierarchy and card layout
- compact two-player score cards with pocketed balls under each player
- rebuilt New Practice Match screen with VS cards, breaker + previous-match panels, and match setting tiles
- compact scoring controls and tighter spacing
- safe top/bottom padding to avoid status/navigation bar overlap
- all V5.7.1 scoring, rack history/edit, 9-ball prompts, active matches, history, stats and persistence retained
