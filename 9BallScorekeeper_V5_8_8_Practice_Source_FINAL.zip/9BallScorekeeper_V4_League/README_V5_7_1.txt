9 Ball League Practice V5.7.1
Version code: 62

Visual redesign release:
- Home screen rebuilt with premium dark billiards theme, 9-ball hero, polished cards, and bottom navigation.
- Scoring screen rebuilt with rounded player score cards and pocketed balls directly under each player.
- New Practice Match setup rebuilt with two player cards, head-to-head section, breaker selection, settings summary, and large Start Match control.
- Layouts use wrap-content/minimum heights and multi-line text to prevent the clipping seen in V5.7.
- Existing V5.6.1/V5.7 scoring logic retained, including active matches, rack editing, 9-ball classification, next-rack prompt, stats, history, graphs, undo, defenses, timeouts, and innings.
- Neutral "Match Points" wording retained for IP cleanup.
