9 Ball League Practice v5.8.6
versionCode 72

Crash hotfix:
- Fixes immediate crash after tapping Start Match.
- Root cause: the V5.8.5 scoring-screen redesign stopped assigning the
  `inningsText` TextView, while refreshScoreScreen() still updates it.
- Reconnects `inningsText` to the center Rack / innings label.
- Keeps the approved V5.8.5 visual design and scoring logic unchanged.
