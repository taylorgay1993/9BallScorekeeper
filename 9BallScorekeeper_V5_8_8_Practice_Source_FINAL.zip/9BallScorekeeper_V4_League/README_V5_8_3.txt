9 Ball League Practice v5.8.3
versionCode 69

Visual/background correction:
- Preserves the working V5.8.2 layouts and scoring logic.
- Replaces the prior muddy/gradient-like background with a clean cinematic
  pool-hall image derived from the approved visual direction.
- Background contains no baked-in app cards/buttons/text.
- Warm hanging-light / blue-neon pool-hall ambience is visible behind the UI.
- RACK STATS is now a single-line centered label so it cannot clip vertically.
