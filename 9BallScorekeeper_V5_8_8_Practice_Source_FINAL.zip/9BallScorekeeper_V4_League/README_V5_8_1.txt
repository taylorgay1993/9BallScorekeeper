9 Ball League Practice v5.8.1
versionCode 67

Visual correction build:
- Replaced the flat illustrated V5.8 background with a cinematic dark pool-hall treatment based on the approved visual direction.
- Removed the obvious rectangular-center background effect.
- Increased neon/glass contrast.
- Fixed MATCH HISTORY and MATCH SETTINGS clipping on the Home screen.
- Kept STATISTICS on one line.
- Improved Rack History/Edit control label fit.
- Preserved existing scoring, active matches, history, rack editing, winner detection, and statistics logic.
