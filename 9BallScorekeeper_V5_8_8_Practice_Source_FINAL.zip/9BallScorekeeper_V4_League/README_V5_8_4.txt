9 Ball League Practice v5.8.4
versionCode 70

- Preserves the working V5.8.3 layout and scoring logic.
- RACK STATS uses a centered two-line label with controlled line spacing/padding.
- Keeps the approved cinematic pool-hall background.
- Corrects the background source aspect ratio to reduce horizontal stretching.
