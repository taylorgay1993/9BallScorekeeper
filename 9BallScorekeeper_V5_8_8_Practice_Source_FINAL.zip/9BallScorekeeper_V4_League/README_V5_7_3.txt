9 Ball League Practice v5.7.3 — Cinematic UI build

- versionCode 65 / versionName 5.7.3
- Cinematic pool-hall background applied to Home, New Match, and live scoring.
- Glossy gradient/glass treatment for cards and controls.
- Shiny reflective billiard-ball rendering, especially the 9-ball.
- Existing v5.7.2 scoring, active matches, history, statistics, rack editing and persistence retained.
- Visual target: Neon 9-Ball Practice League UI mockup.
