9 Ball League Practice v5.8.8
versionCode 74

Background-only update:
- Replaces pool_hall_bg.jpg with the newly approved seamless pool-hall image.
- Keeps all V5.8.6 UI layout, scoring logic, controls, navigation, and crash fix unchanged.
- No center split, no two-column compositing, no UI code changes.
