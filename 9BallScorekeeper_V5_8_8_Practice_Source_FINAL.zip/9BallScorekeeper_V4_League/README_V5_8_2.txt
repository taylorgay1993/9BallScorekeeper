9 Ball League Practice v5.8.2
versionCode 68

Layout correction build based on device screenshots:
- STATISTICS forced to one line without clipping.
- MATCH HISTORY and MATCH SETTINGS rebuilt so titles and subtitles fit.
- Home tile rows given fixed safe height.
- RACK HISTORY / EDIT control rebuilt and increased in height.
- Extra bottom safe area added across Home, Setup, Scoring, and secondary pages so Android navigation no longer covers app controls.
- Existing match/scoring/history logic preserved.
