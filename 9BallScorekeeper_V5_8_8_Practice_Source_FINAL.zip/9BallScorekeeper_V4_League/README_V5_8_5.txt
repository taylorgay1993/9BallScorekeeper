9 Ball League Practice v5.8.5
versionCode 71

Approved visual rebuild:
- Uses the newly approved cinematic neon pool-hall visual as the design target.
- Background rebuilt from the approved pool-hall look without baking in UI cards/text.
- Scoring rack-control row restored to three sections:
  Rack History/Edit | Rack/innings | Rack Stats.
- Rack Stats rendered as a centered compact multi-line control to avoid clipping.
- Glass panels use stronger neon outlines and more transparency so the pool hall reads through.
- Existing scoring/business logic preserved.
