9 Ball League Practice V5.8
Version code: 66

Visual rebuild:
- Cinematic pool-hall image background across primary screens
- Stronger neon/glass card styling and glowing controls
- Enhanced glossy/shiny pool-ball rendering
- Blue Player 1 / red Player 2 visual identity
- New Practice Match: visible First Breaker, expanded Match Settings tiles, no clipped controls
- Home Statistics card kept on one line
- Match Complete redesigned to full cinematic results screen
- Rack History / Edit redesigned to match the neon visual system
- Existing match logic, active matches, history, rack editing, 9-ball detection, graphs and scoring preserved
