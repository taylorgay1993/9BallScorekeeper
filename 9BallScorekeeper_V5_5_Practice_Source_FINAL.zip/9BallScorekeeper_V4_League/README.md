# 9 Ball League Practice — V5.5

Independent 9-ball practice scorekeeper. Not affiliated with APA or any league organization.

## V5.5 changes
- Multiple simultaneously saved Active Matches with resume and long-press discard.
- Automatic save after scoring/actions so unfinished matches can be continued later.
- Winner detection as soon as a player reaches the target, with Edit Score or Confirm Win.
- Automatic Break & Run / 9-on-the-Snap detection with Yes/No confirmation.
- Per-player Break & Run and 9-on-the-Snap totals in match stats/history.
- Redesigned match screen focused on the two individual players; no team names, team scores, or match number.
- Lifetime head-to-head win totals for recurring player matchups.
- Swipe down from the top of the scoring screen to open Rack History / Edit.
- Rack-by-rack display showing who made each ball and dead balls.
- Rack editor for ball ownership/dead balls, innings, defensive shots, and timeouts.
- Rack edits recalculate match totals, graphs, winner state, and saved active-match state.
- Existing V5.4 history, graphs, APA-style match result calculation, custom launcher icon, and black/yellow 9-ball retained.

## Android package / version
- package: `com.nineball.scorekeeper`
- versionCode: `58`
- versionName: `5.5`
- minSdk: 26
- targetSdk: 36

Build the Android App Bundle with the same upload key previously used for this Google Play app.
