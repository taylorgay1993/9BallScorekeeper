package com.nineball.scorekeeper

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.min

private const val BALL_AVAILABLE = 0
private const val BALL_POCKETED = 1
private const val BALL_DEAD = 2

data class PracticePlayer(
    var name: String,
    var skill: Int,
    var target: Int,
    var score: Int = 0,
    var defensiveShots: Int = 0,
    var timeoutsLeft: Int = if (skill <= 3) 2 else 1
)

data class ApaMatchResult(
    val winnerName: String,
    val loserName: String,
    val winnerPoints: Int,
    val loserPoints: Int,
    val loserSkill: Int,
    val loserBallPoints: Int
)

data class MatchSnapshot(
    val scoreA: Int,
    val scoreB: Int,
    val defenseA: Int,
    val defenseB: Int,
    val timeoutsA: Int,
    val timeoutsB: Int,
    val currentPlayer: Int,
    val innings: Int,
    val rack: Int,
    val breaker: Int,
    val rackTurnovers: Int,
    val ballStates: IntArray,
    val ballOwners: IntArray,
    val ballLocked: BooleanArray,
    val nineOnSnapA: Int,
    val nineOnSnapB: Int,
    val breakRunsA: Int,
    val breakRunsB: Int,
    val rackPointsA: List<Int>,
    val rackPointsB: List<Int>
)

class PoolHallBackgroundView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        p.shader=LinearGradient(0f,0f,0f,h, intArrayOf(Color.rgb(2,10,18),Color.rgb(3,24,42),Color.rgb(1,12,22)), null, Shader.TileMode.CLAMP); c.drawRect(0f,0f,w,h,p); p.shader=null
        // soft neon pools of light
        listOf(.16f,.50f,.84f).forEach { x ->
            p.shader=RadialGradient(w*x,h*.09f,w*.23f,Color.argb(105,15,116,255),Color.TRANSPARENT,Shader.TileMode.CLAMP); c.drawCircle(w*x,h*.09f,w*.23f,p)
        }
        p.shader=null
        // hanging lamps
        p.strokeWidth=3f; p.color=Color.argb(100,160,190,215)
        listOf(.13f,.50f,.87f).forEach { x -> c.drawLine(w*x,0f,w*x,h*.055f,p); p.color=Color.argb(160,255,187,78); c.drawOval(RectF(w*x-w*.055f,h*.045f,w*x+w*.055f,h*.075f),p); p.color=Color.argb(100,160,190,215) }
        // pool-table felt and rail, deliberately abstract so controls stay readable
        p.shader=LinearGradient(0f,h*.28f,0f,h,Color.argb(125,0,74,126),Color.argb(70,0,30,55),Shader.TileMode.CLAMP); c.drawRect(0f,h*.28f,w,h,p); p.shader=null
        p.color=Color.argb(90,28,151,255); p.style=Paint.Style.STROKE; p.strokeWidth=2f; c.drawRoundRect(RectF(8f,h*.30f,w-8f,h*.98f),26f,26f,p); p.style=Paint.Style.FILL
    }
}

class BallView(
    context: Context,
    val ballNumber: Int,
    private val onTap: (Int) -> Unit
) : View(context) {
    var state: Int = BALL_AVAILABLE
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Ball $ballNumber. Tap to change status."
        setOnClickListener { onTap(ballNumber) }
    }

    private fun ballColor(n: Int): Int = when (n) {
        1 -> Color.rgb(244, 190, 35)
        9 -> Color.rgb(20, 20, 20)
        2 -> Color.rgb(35, 94, 168)
        3 -> Color.rgb(190, 35, 48)
        4 -> Color.rgb(112, 71, 145)
        5 -> Color.rgb(232, 113, 52)
        6 -> Color.rgb(60, 137, 64)
        7 -> Color.rgb(130, 32, 39)
        8 -> Color.rgb(24, 24, 24)
        else -> Color.DKGRAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * .42f
        val c = ballColor(ballNumber)

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)

        if (ballNumber <= 8) {
            paint.color = c
            canvas.drawCircle(cx, cy, r, paint)
        } else {
            // Custom black-and-yellow 9-ball requested for the practice interface.
            paint.color = Color.rgb(20, 20, 20)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.rgb(244, 190, 35)
            val stripe = RectF(cx - r, cy - r * .47f, cx + r, cy + r * .47f)
            canvas.drawRoundRect(stripe, r * .25f, r * .25f, paint)
        }

        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .39f, paint)
        paint.color = Color.rgb(25, 25, 25)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * .62f
        paint.isFakeBoldText = true
        val fm = paint.fontMetrics
        canvas.drawText(ballNumber.toString(), cx, cy - (fm.ascent + fm.descent) / 2, paint)
        paint.isFakeBoldText = false
        paint.shader = RadialGradient(cx-r*.28f, cy-r*.36f, r*.85f, intArrayOf(Color.argb(235,255,255,255), Color.argb(80,255,255,255), Color.TRANSPARENT), floatArrayOf(0f,.32f,1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r*.98f, paint); paint.shader = null
        paint.color = Color.argb(215, 255, 255, 255)
        canvas.drawOval(RectF(cx-r*.50f, cy-r*.68f, cx-r*.03f, cy-r*.28f), paint)
        paint.color = Color.argb(85, 255, 215, 70)
        canvas.drawCircle(cx+r*.28f, cy+r*.30f, r*.20f, paint)

        if (state == BALL_POCKETED) {
            paint.color = Color.argb(165, 9, 80, 74)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .42f, cy, cx - r * .08f, cy + r * .34f, paint)
            canvas.drawLine(cx - r * .08f, cy + r * .34f, cx + r * .48f, cy - r * .35f, paint)
            paint.style = Paint.Style.FILL
        } else if (state == BALL_DEAD) {
            paint.color = Color.argb(180, 70, 70, 70)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * .12f
            canvas.drawLine(cx - r * .45f, cy - r * .45f, cx + r * .45f, cy + r * .45f, paint)
            canvas.drawLine(cx + r * .45f, cy - r * .45f, cx - r * .45f, cy + r * .45f, paint)
            paint.style = Paint.Style.FILL
        }
    }
}

class RackBallIconView(context: Context, private val ballNumber: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun ballColor(n: Int): Int = when (n) {
        1 -> Color.rgb(244, 190, 35)
        9 -> Color.rgb(20, 20, 20)
        2 -> Color.rgb(35, 94, 168)
        3 -> Color.rgb(190, 35, 48)
        4 -> Color.rgb(112, 71, 145)
        5 -> Color.rgb(232, 113, 52)
        6 -> Color.rgb(60, 137, 64)
        7 -> Color.rgb(130, 32, 39)
        8 -> Color.rgb(24, 24, 24)
        else -> Color.DKGRAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * .42f
        val c = ballColor(ballNumber)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)
        if (ballNumber <= 8) {
            paint.color = c
            canvas.drawCircle(cx, cy, r, paint)
        } else {
            // Custom black-and-yellow 9-ball requested for the practice interface.
            paint.color = Color.rgb(20, 20, 20)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.rgb(244, 190, 35)
            val stripe = RectF(cx - r, cy - r * .47f, cx + r, cy + r * .47f)
            canvas.drawRoundRect(stripe, r * .25f, r * .25f, paint)
        }
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r * .39f, paint)
        paint.color = Color.rgb(25, 25, 25)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r * .62f
        paint.isFakeBoldText = true
        val fm = paint.fontMetrics
        canvas.drawText(ballNumber.toString(), cx, cy - (fm.ascent + fm.descent) / 2, paint)
        paint.isFakeBoldText = false
        paint.color = Color.argb(145,255,255,255)
        canvas.drawOval(RectF(cx-r*.48f,cy-r*.62f,cx-r*.02f,cy-r*.22f),paint)
    }
}


class RackPerformanceView(
    context: Context,
    private val playerA: String,
    private val playerB: String,
    private val aPoints: List<Int>,
    private val bPoints: List<Int>
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Color.rgb(210, 218, 225)
    private val ink = Color.rgb(40, 50, 60)
    private val aColor = Color.rgb(22, 111, 169)
    private val bColor = Color.rgb(9, 121, 113)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = 72f
        val right = width - 24f
        val top = 42f
        val bottom = height - 66f
        val rackCount = maxOf(aPoints.size, bPoints.size).coerceAtLeast(1)

        fun cumulative(values: List<Int>): List<Int> {
            var running = 0
            return values.map { running += it; running }
        }
        val cumulativeA = cumulative(aPoints)
        val cumulativeB = cumulative(bPoints)
        val highestScore = maxOf(cumulativeA.maxOrNull() ?: 0, cumulativeB.maxOrNull() ?: 0, 10)
        val xMax = ((highestScore + 9) / 10) * 10

        paint.textSize = 23f
        paint.color = ink
        paint.isFakeBoldText = true
        canvas.drawText("Score progression by rack", left, 25f, paint)
        paint.isFakeBoldText = false

        // Horizontal axis: score in 10-point increments.
        paint.textSize = 15f
        for (score in 0..xMax step 10) {
            val x = left + (right - left) * score / xMax.toFloat()
            paint.color = grid
            paint.strokeWidth = 1f
            canvas.drawLine(x, top, x, bottom, paint)
            paint.color = ink
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(score.toString(), x, bottom + 22f, paint)
        }

        // Vertical axis: rack number.
        fun yForRack(index: Int): Float = if (rackCount == 1) (top + bottom) / 2f else bottom - (bottom - top) * index / (rackCount - 1f)
        for (i in 0 until rackCount) {
            val y = yForRack(i)
            paint.color = grid
            paint.strokeWidth = 1f
            canvas.drawLine(left, y, right, y, paint)
            paint.color = ink
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("R${i + 1}", left - 10f, y + 5f, paint)
        }

        fun xForScore(score: Int): Float = left + (right - left) * score.coerceIn(0, xMax) / xMax.toFloat()
        fun drawSeries(values: List<Int>, color: Int) {
            if (values.isEmpty()) return
            paint.color = color
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            val path = Path()
            values.forEachIndexed { i, score ->
                val x = xForScore(score); val y = yForRack(i)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.FILL
            values.forEachIndexed { i, score -> canvas.drawCircle(xForScore(score), yForRack(i), 7f, paint) }
        }
        drawSeries(cumulativeA, aColor)
        drawSeries(cumulativeB, bColor)

        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 16f
        paint.color = ink
        canvas.drawText("Score (ball points)", (left + right) / 2f, height - 20f, paint)

        canvas.save()
        canvas.rotate(-90f, 18f, (top + bottom) / 2f)
        canvas.drawText("Rack number", 18f, (top + bottom) / 2f, paint)
        canvas.restore()

        paint.textAlign = Paint.Align.LEFT
        paint.textSize = 15f
        paint.color = aColor
        canvas.drawText(playerA, left, height - 2f, paint)
        paint.color = bColor
        canvas.drawText(playerB, left + 150f, height - 2f, paint)
    }
}

data class RackRecord(
    var rackNumber: Int,
    var breaker: Int,
    var ballStates: IntArray,
    var ballOwners: IntArray,
    var innings: Int,
    var defensiveA: Int,
    var defensiveB: Int,
    var timeoutsA: Int,
    var timeoutsB: Int,
    var nineOnSnapPlayer: Int = -1,
    var breakRunPlayer: Int = -1
)

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("practice_scorekeeper_v5", Context.MODE_PRIVATE) }

    private val navy = Color.rgb(8, 93, 163)
    private val blue = Color.rgb(15, 108, 184)
    private val lightBlue = Color.rgb(74, 152, 205)
    private val teal = Color.rgb(9, 121, 113)
    private val gold = Color.rgb(231, 174, 51)
    private val card = Color.rgb(244, 247, 249)
    private val ink = Color.rgb(25, 35, 45)
    private val muted = Color.rgb(92, 105, 116)
    private val actionGray = Color.rgb(99, 99, 103)

    private var a = PracticePlayer("Player 1", 4, 31)
    private var b = PracticePlayer("Player 2", 4, 31)
    private var currentPlayer = 0
    private var innings = 0
    private var rack = 1
    private var breaker = 0
    private var rackTurnovers = 0
    private var rackInnings = 0
    private var rackDefenseA = 0
    private var rackDefenseB = 0
    private var rackTimeoutA = 0
    private var rackTimeoutB = 0
    private var nineOnSnapA = 0
    private var nineOnSnapB = 0
    private var breakRunsA = 0
    private var breakRunsB = 0
    private val rackPointsA = mutableListOf(0)
    private val rackPointsB = mutableListOf(0)
    private val rackRecords = mutableListOf<RackRecord>()
    private val ballStates = IntArray(10)
    private val ballOwners = IntArray(10) { -1 }
    private val ballLocked = BooleanArray(10)
    private val undoStack = ArrayDeque<MatchSnapshot>()
    private var activeMatchId: String? = null
    private var winnerDialogOpen = false

    private lateinit var scoreAText: TextView
    private lateinit var scoreBText: TextView
    private lateinit var inningsText: TextView
    private lateinit var shooterText: TextView
    private lateinit var detailText: TextView
    private lateinit var defenseButton: Button
    private lateinit var timeoutButton: Button
    private lateinit var ballsARow: GridLayout
    private lateinit var ballsBRow: GridLayout
    private lateinit var deadBallsRow: LinearLayout
    private lateinit var playerPanelA: LinearLayout
    private lateinit var playerPanelB: LinearLayout
    private val ballViews = mutableMapOf<Int, BallView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float = 16f, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(dp(6), dp(7), dp(6), dp(7))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            if (color == Color.WHITE || Color.blue(color) > 180) setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), Color.argb(170, 0, 90, 180))
        }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        setBackgroundColor(if (primary) blue else actionGray)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { action() }
    }

    private fun page(title: String): LinearLayout {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.TRANSPARENT); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(34), dp(16), dp(118)) }
        val titleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); background = darkCard(Color.rgb(0, 166, 255), 18)
        }
        titleBar.addView(RackBallIconView(this, 9), LinearLayout.LayoutParams(dp(44), dp(44)))
        titleBar.addView(text(title.uppercase(Locale.US), 22f, Color.rgb(58, 183, 255), true).apply { gravity = Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        root.addView(titleBar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        scroll.addView(root)
        cinematicContent(scroll)
        return root
    }

    private fun normalizeName(name: String): String = name.trim().replace(Regex("\\s+"), " ").lowercase(Locale.US)

    private fun headToHead(n1: String, n2: String): Triple<Int, Int, Int> {
        val k1 = normalizeName(n1); val k2 = normalizeName(n2)
        var w1 = 0; var w2 = 0; var total = 0
        val arr = JSONArray(prefs.getString("history", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val p1 = normalizeName(o.optString("p1")); val p2 = normalizeName(o.optString("p2"))
            if (!((p1 == k1 && p2 == k2) || (p1 == k2 && p2 == k1))) continue
            val winner = normalizeName(o.optString("winner"))
            if (winner == k1) w1++ else if (winner == k2) w2++
            if (winner == k1 || winner == k2) total++
        }
        return Triple(w1, w2, total)
    }

    private fun activeMatches(): JSONArray = try { JSONArray(prefs.getString("active_matches_v58", "[]")) } catch (_: Exception) { JSONArray() }

    private fun roundedBg(color: Int, stroke: Int = Color.TRANSPARENT, radius: Int = 18): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(lighten(color, 1.34f), color, darken(color, .54f))).apply {
        shape = GradientDrawable.RECTANGLE; cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(2), stroke)
    }

    private fun lighten(c:Int, f:Float)=Color.rgb((Color.red(c)*f).toInt().coerceAtMost(255),(Color.green(c)*f).toInt().coerceAtMost(255),(Color.blue(c)*f).toInt().coerceAtMost(255))
    private fun darken(c:Int, f:Float)=Color.rgb((Color.red(c)*f).toInt(),(Color.green(c)*f).toInt(),(Color.blue(c)*f).toInt())

    private fun cinematicContent(scroll: ScrollView) {
        scroll.setBackgroundColor(Color.TRANSPARENT)
        val frame = FrameLayout(this)
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.pool_hall_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        frame.addView(bg, FrameLayout.LayoutParams(-1, -1))
        frame.addView(View(this).apply { setBackgroundColor(Color.argb(10, 0, 7, 15)) }, FrameLayout.LayoutParams(-1, -1))
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    private fun homeTile(title: String, subtitle: String, color: Int, action: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(13), dp(18), dp(13)); background = roundedBg(color, Color.argb(130, 70, 170, 255), 16)
        addView(text(title, 18f, Color.WHITE, true)); addView(text(subtitle, 12f, Color.rgb(205, 220, 235)))
        setOnClickListener { action() }; isClickable = true
    }

    private fun darkCard(stroke: Int = Color.rgb(0, 178, 255), radius: Int = 18): GradientDrawable =
        roundedBg(Color.argb(228, 4, 22, 40), stroke, radius)

    private fun accentButton(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        background = roundedBg(color, if (Color.green(color) > 120) Color.rgb(0, 255, 155) else Color.rgb(0, 175, 255), 15)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        minHeight = dp(58)
        setOnClickListener { action() }
    }

    private fun sectionTitle(label: String): TextView = text(label, 14f, Color.rgb(175, 200, 222), true).apply {
        setPadding(0, dp(4), 0, dp(6))
    }

    private fun setupField(parent: LinearLayout, label: String, value: String, numeric: Boolean = false): EditText {
        parent.addView(sectionTitle(label))
        val field = EditText(this).apply {
            setText(value)
            textSize = 17f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(120, 150, 175))
            background = roundedBg(Color.rgb(7, 26, 43), Color.rgb(67, 112, 150), 12)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            minHeight = dp(54)
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        parent.addView(field, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return field
    }

    private fun addBottomNav(root: LinearLayout, active: String = "HOME") {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = roundedBg(Color.rgb(4, 19, 31), Color.rgb(22, 75, 112), 0)
        }
        listOf("HOME" to "⌂", "PLAYERS" to "♙", "STATS" to "▥", "MORE" to "•••").forEach { (label, icon) ->
            val c = if (label == active) Color.rgb(20, 145, 255) else Color.WHITE
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                addView(text(icon, 20f, c, true).apply { gravity = Gravity.CENTER })
                addView(text(label, 10f, c, true).apply { gravity = Gravity.CENTER })
            }
            nav.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
    }

    private fun showHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(1, 13, 24)); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(34), dp(18), dp(118))
        }
        scroll.addView(root); cinematicContent(scroll)

        val utility = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        utility.addView(text("⚙\nSettings", 11f, Color.rgb(220, 232, 243), true).apply { gravity = Gravity.CENTER; setOnClickListener { Toast.makeText(this@MainActivity, "Settings coming soon", Toast.LENGTH_SHORT).show() } }, LinearLayout.LayoutParams(dp(70), -2))
        utility.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        utility.addView(text("?\nHelp", 11f, Color.rgb(220, 232, 243), true).apply { gravity = Gravity.CENTER; setOnClickListener { Toast.makeText(this@MainActivity, "9 Ball League Practice", Toast.LENGTH_SHORT).show() } }, LinearLayout.LayoutParams(dp(70), -2))
        root.addView(utility, LinearLayout.LayoutParams(-1, -2))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(10), dp(2), dp(10), dp(12))
        }
        hero.addView(RackBallIconView(this, 9), LinearLayout.LayoutParams(dp(98), dp(98)))
        hero.addView(text("9 BALL LEAGUE", 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        hero.addView(text("PRACTICE", 28f, Color.rgb(20, 145, 255), true).apply { gravity = Gravity.CENTER; letterSpacing = 0.06f })
        hero.addView(text("TRACK   •   IMPROVE   •   PLAY BETTER", 11f, Color.rgb(164, 191, 216), true).apply { gravity = Gravity.CENTER; letterSpacing = 0.08f })
        root.addView(hero, LinearLayout.LayoutParams(-1, -2))

        val feature = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14)); background = roundedBg(Color.rgb(5, 34, 56), Color.rgb(22, 111, 174), 20)
        }
        feature.addView(RackBallIconView(this, 9), LinearLayout.LayoutParams(dp(76), dp(76)))
        val featureCopy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        featureCopy.addView(text("PRACTICE • IMPROVE", 13f, Color.rgb(89, 181, 255), true))
        featureCopy.addView(text("Track every rack.\nSee every point.", 18f, Color.WHITE, true).apply { maxLines = 2 })
        feature.addView(featureCopy, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(feature, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(12) })

        root.addView(accentButton("▶   START MATCH", Color.rgb(0, 170, 82)) { showSetup() }.apply { textSize = 18f }, LinearLayout.LayoutParams(-1, dp(74)).apply { bottomMargin = dp(12) })

        val activeCount = activeMatches().length()
        if (activeCount > 0) {
            root.addView(accentButton("↻   RESUME ACTIVE MATCHES ($activeCount)", Color.rgb(9, 83, 154)) { showActiveMatches() }, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(12) })
        }

        fun premiumTile(icon: String, title: String, subtitle: String, color: Int, action: () -> Unit): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(12), dp(9), dp(12))
            background = roundedBg(color, Color.argb(235, 60, 175, 255), 18)

            val top = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            top.addView(
                text(icon, 23f, Color.WHITE, true).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(dp(34), dp(38))
            )
            top.addView(
                text(title, 12.5f, Color.WHITE, true).apply {
                    maxLines = 1
                    isSingleLine = true
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(2), 0, 0, 0)
                },
                LinearLayout.LayoutParams(0, dp(38), 1f)
            )
            addView(top, LinearLayout.LayoutParams(-1, dp(40)))

            addView(
                text(subtitle, 10.5f, Color.rgb(225, 234, 243)).apply {
                    maxLines = 2
                    gravity = Gravity.CENTER
                    textAlignment = View.TEXT_ALIGNMENT_CENTER
                },
                LinearLayout.LayoutParams(-1, dp(44))
            )

            minimumHeight = dp(126)
            setOnClickListener { action() }
            isClickable = true
            isFocusable = true
        }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(premiumTile("♙", "PLAYERS", "Names, SL & targets", Color.rgb(8, 75, 142)) { showSetup() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        r1.addView(premiumTile("▥", "STATISTICS", "Track your progress", Color.rgb(76, 41, 127)) { showHistory() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        root.addView(r1, LinearLayout.LayoutParams(-1, dp(128)).apply { bottomMargin = dp(12) })
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(premiumTile("☷", "MATCH HISTORY", "Results, graphs & stats", Color.rgb(145, 103, 0)) { showHistory() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        r2.addView(premiumTile("⚙", "MATCH SETTINGS", "Set up a new match", Color.rgb(153, 35, 48)) { showSetup() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        root.addView(r2, LinearLayout.LayoutParams(-1, dp(128)).apply { bottomMargin = dp(12) })

        val practice = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16)); background = darkCard(Color.rgb(43, 93, 132), 18)
            addView(text("◎", 30f, Color.WHITE, true), LinearLayout.LayoutParams(dp(48), -2))
            val c = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            c.addView(text("PRACTICE SCOREKEEPER", 17f, Color.WHITE, true))
            c.addView(text("Ball-by-ball scoring • rack editing • saved history", 11f, Color.rgb(188, 210, 229)).apply { maxLines = 2 })
            addView(c, LinearLayout.LayoutParams(0, -2, 1f)); setOnClickListener { showSetup() }
        }
        root.addView(practice, LinearLayout.LayoutParams(-1, -2))
        root.addView(text("“Better Players. More Racks.”", 13f, Color.rgb(137, 171, 201)).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(text("INDEPENDENT PRACTICE TOOL  •  v5.8.6", 10f, Color.rgb(87, 119, 148)).apply { gravity = Gravity.CENTER })
        addBottomNav(root, "HOME")
    }


    private fun labeledField(root: LinearLayout, label: String, default: String, numeric: Boolean = false): EditText {
        root.addView(text(label, 14f, muted, true))
        return EditText(this).apply {
            setText(default); textSize = 18f; setTextColor(ink); setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12))
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            root.addView(this, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(10) })
        }
    }

    private fun showSetup() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(1, 13, 24)); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(118)) }
        scroll.addView(root); cinematicContent(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = text("‹  Back", 16f, Color.WHITE, true).apply { setOnClickListener { showHome() }; isClickable = true }
        header.addView(back, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(RackBallIconView(this, 9), LinearLayout.LayoutParams(dp(52), dp(52)))
        header.addView(text("NEW PRACTICE\nMATCH", 20f, Color.rgb(20, 145, 255), true).apply { gravity = Gravity.END; maxLines = 2 }, LinearLayout.LayoutParams(0, -2, 1.7f))
        root.addView(header)
        root.addView(text("SET PLAYERS   •   SET RULES   •   PLAY", 11f, Color.rgb(148, 181, 209), true).apply { gravity = Gravity.CENTER; letterSpacing = .05f }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        fun card(title: String, playerIndex: Int): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
            val base = if (playerIndex == 0) Color.rgb(5, 66, 133) else Color.rgb(119, 8, 31)
            val edge = if (playerIndex == 0) Color.rgb(0, 182, 255) else Color.rgb(255, 48, 84)
            background = roundedBg(base, edge, 18)
            addView(text(title, 19f, Color.WHITE, true))
        }
        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        val c1 = card("Player 1", 0); val c2 = card("Player 2", 1)
        val p1 = setupField(c1, "Name", prefs.getString("last_p1", "Player 1") ?: "Player 1")
        val p1Skill = setupField(c1, "Skill Level", prefs.getInt("last_sl1", 4).toString(), true)
        val p1Target = setupField(c1, "Target Ball Points", prefs.getInt("last_target1", 31).toString(), true)
        val p2 = setupField(c2, "Name", prefs.getString("last_p2", "Player 2") ?: "Player 2")
        val p2Skill = setupField(c2, "Skill Level", prefs.getInt("last_sl2", 4).toString(), true)
        val p2Target = setupField(c2, "Target Ball Points", prefs.getInt("last_target2", 31).toString(), true)
        cards.addView(c1, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        cards.addView(c2, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        root.addView(cards)
        val vs = text("VS", 14f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = roundedBg(Color.rgb(4, 45, 79), Color.rgb(0, 151, 255), 24) }
        root.addView(vs, LinearLayout.LayoutParams(dp(48), dp(48)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = -dp(24); bottomMargin = dp(6) })

        val infoRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val breakerCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(12)); background = darkCard() }
        breakerCard.addView(text("◉  First Breaker", 14f, Color.WHITE, true))
        val firstBreaker = Spinner(this).apply {
            adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Player 1", "Player 2")) {
                override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = (super.getView(position, convertView, parent) as TextView).apply { setTextColor(Color.WHITE); textSize = 16f; setPadding(dp(12), 0, dp(12), 0) }
                override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = (super.getDropDownView(position, convertView, parent) as TextView).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(7, 26, 43)); textSize = 16f; setPadding(dp(14), dp(12), dp(14), dp(12)) }
            }
            background = roundedBg(Color.rgb(7, 26, 43), Color.rgb(0, 174, 255), 12)
        }
        breakerCard.addView(firstBreaker, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6) })
        infoRow.addView(breakerCard, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })

        val prevCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(12)); background = darkCard() }
        prevCard.addView(text("↻  Previous Matches", 14f, Color.WHITE, true))
        val h2h = text("", 11f, Color.rgb(164, 200, 230), true).apply { gravity = Gravity.CENTER; maxLines = 4 }
        prevCard.addView(h2h, LinearLayout.LayoutParams(-1, dp(62)))
        infoRow.addView(prevCard, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        root.addView(infoRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        fun updateH2H() {
            val n1 = p1.text.toString().trim(); val n2 = p2.text.toString().trim()
            if (n1.isBlank() || n2.isBlank() || normalizeName(n1) == normalizeName(n2)) { h2h.text = "Enter two different players"; return }
            val (w1, w2, total) = headToHead(n1, n2)
            h2h.text = if (total == 0) "No previous matches\nbetween these players" else "$n1 $w1  –  $w2 $n2\n$total matches"
        }
        val watcher = object : android.text.TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}; override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updateH2H() }; override fun afterTextChanged(s: android.text.Editable?) {} }
        p1.addTextChangedListener(watcher); p2.addTextChangedListener(watcher); updateH2H()

        val settings = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(12)); background = darkCard() }
        settings.addView(text("⚙  Match Settings", 16f, Color.WHITE, true))
        val mini = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun settingTile(icon: String, title: String, body: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(7), dp(8), dp(7), dp(8)); background = roundedBg(Color.rgb(8, 28, 45), Color.rgb(55, 99, 134), 12)
            addView(text(icon, 19f, Color.WHITE, true).apply { gravity = Gravity.CENTER }); addView(text(title, 11f, Color.WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 2 }); addView(text(body, 9f, Color.rgb(175, 200, 220)).apply { gravity = Gravity.CENTER; maxLines = 3 })
        }
        mini.addView(settingTile("♛", "Format", "Race to target\nball points"), LinearLayout.LayoutParams(0, dp(138), 1f).apply { marginEnd = dp(4) })
        mini.addView(settingTile("⑧", "Ball In Hand", "Standard after\nlegal break"), LinearLayout.LayoutParams(0, dp(138), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        mini.addView(settingTile("◈", "League Tools", "Defenses, timeouts\n& rack history"), LinearLayout.LayoutParams(0, dp(138), 1f).apply { marginStart = dp(4) })
        settings.addView(mini, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(settings, LinearLayout.LayoutParams(-1, -2))

        root.addView(accentButton("▶   START MATCH", Color.rgb(0, 185, 82)) {
            val n1 = p1.text.toString().trim().ifBlank { "Player 1" }; val n2 = p2.text.toString().trim().ifBlank { "Player 2" }
            val sl1 = (p1Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9); val sl2 = (p2Skill.text.toString().toIntOrNull() ?: 4).coerceIn(1, 9)
            val t1 = (p1Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1); val t2 = (p2Target.text.toString().toIntOrNull() ?: 31).coerceAtLeast(1)
            prefs.edit().putString("last_p1", n1).putString("last_p2", n2).putInt("last_sl1", sl1).putInt("last_sl2", sl2).putInt("last_target1", t1).putInt("last_target2", t2).apply()
            startMatch(n1, sl1, t1, n2, sl2, t2, firstBreaker.selectedItemPosition)
        }.apply { textSize = 18f }, LinearLayout.LayoutParams(-1, dp(70)).apply { topMargin = dp(14); bottomMargin = dp(12) })
        root.addView(text("Better Players. More Racks.", 12f, Color.rgb(124, 163, 197)).apply { gravity = Gravity.CENTER })
        addBottomNav(root, "HOME")
    }


    private fun startMatch(n1: String, sl1: Int, t1: Int, n2: String, sl2: Int, t2: Int, firstBreaker: Int) {
        a = PracticePlayer(n1, sl1, t1); b = PracticePlayer(n2, sl2, t2)
        currentPlayer = firstBreaker; breaker = firstBreaker; innings = 0; rack = 1; rackTurnovers = 0; rackInnings = 0
        rackDefenseA = 0; rackDefenseB = 0; rackTimeoutA = 0; rackTimeoutB = 0
        nineOnSnapA = 0; nineOnSnapB = 0; breakRunsA = 0; breakRunsB = 0
        rackPointsA.clear(); rackPointsA.add(0); rackPointsB.clear(); rackPointsB.add(0); rackRecords.clear()
        ballStates.fill(BALL_AVAILABLE); ballOwners.fill(-1); ballLocked.fill(false); undoStack.clear()
        activeMatchId = UUID.randomUUID().toString(); saveActiveMatch(); showScoreScreen()
    }

    private fun player(index: Int): PracticePlayer = if (index == 0) a else b
    private fun maxTimeouts(p: PracticePlayer): Int = if (p.skill <= 3) 2 else 1

    private fun showScoreScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(1, 13, 24)); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(30), dp(12), dp(118)) }
        scroll.addView(root); cinematicContent(scroll)

        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(RackBallIconView(this, 9), LinearLayout.LayoutParams(dp(52), dp(52)))
        val bc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bc.addView(text("9 BALL LEAGUE", 19f, Color.WHITE, true)); bc.addView(text("PRACTICE", 14f, Color.rgb(20, 145, 255), true).apply { letterSpacing = .05f })
        brand.addView(bc, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        brand.addView(text("⚙", 22f, Color.rgb(180, 205, 226), true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(42), -2))
        root.addView(brand, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val scoreRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        fun scoreCard(): Pair<LinearLayout, Pair<TextView, GridLayout>> {
            val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(6)); background = darkCard(); minimumHeight = dp(122) }
            val score = text("", 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 4 }
            val grid = GridLayout(this).apply { columnCount = 5; rowCount = 2; alignmentMode = GridLayout.ALIGN_BOUNDS }
            panel.addView(score, LinearLayout.LayoutParams(-1, -2)); panel.addView(grid, LinearLayout.LayoutParams(-1, dp(58)))
            return panel to (score to grid)
        }
        val (pa, xa) = scoreCard(); val (pb, xb) = scoreCard(); playerPanelA = pa; playerPanelB = pb; scoreAText = xa.first; scoreBText = xb.first; ballsARow = xa.second; ballsBRow = xb.second
        scoreRow.addView(pa, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }); scoreRow.addView(pb, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) }); root.addView(scoreRow)

        val rackBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = roundedBg(Color.argb(225, 4, 26, 47), Color.rgb(0, 170, 255), 18)
        }

        val hist = accentButton("☷  RACK HISTORY\nEDIT", Color.rgb(8, 72, 118)) { showRackHistory() }.apply {
            textSize = 10.5f
            maxLines = 2
            gravity = Gravity.CENTER
            setLineSpacing(0f, 0.92f)
        }
        val centerRack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        inningsText = text("Rack ${rack}  •  ${innings} innings", 12.5f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            maxLines = 2
        }
        centerRack.addView(inningsText, LinearLayout.LayoutParams(-1, -2))
        val stats = accentButton("↻\nRACK\nSTATS", Color.rgb(6, 42, 69)) { showRackStats() }.apply {
            textSize = 8.8f
            maxLines = 3
            isSingleLine = false
            gravity = Gravity.CENTER
            setLineSpacing(0f, 0.86f)
            setPadding(dp(2), dp(1), dp(2), dp(1))
        }

        rackBar.addView(hist, LinearLayout.LayoutParams(0, dp(64), 1.15f).apply { marginEnd = dp(6) })
        rackBar.addView(centerRack, LinearLayout.LayoutParams(0, dp(64), .78f))
        rackBar.addView(stats, LinearLayout.LayoutParams(0, dp(64), .68f).apply { marginStart = dp(6) })
        root.addView(rackBar, LinearLayout.LayoutParams(-1, dp(80)).apply { topMargin = dp(8) })
        val shooterCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); background = darkCard(Color.rgb(39, 92, 133)) }
        val shootRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        shooterText = text("", 21f, Color.WHITE, true); shootRow.addView(shooterText, LinearLayout.LayoutParams(0, -2, 1f)); shootRow.addView(text("AT TABLE", 10f, Color.rgb(0, 220, 112), true).apply { gravity = Gravity.END })
        shooterCard.addView(shootRow); detailText = text("", 12f, Color.rgb(184, 206, 225)); shooterCard.addView(detailText)
        val deadHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        deadHeader.addView(sectionTitle("Dead Balls"), LinearLayout.LayoutParams(0, -2, 1f)); deadHeader.addView(text("Tap any ball below to score", 10f, Color.rgb(105, 142, 174)))
        shooterCard.addView(deadHeader); deadBallsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.START }; shooterCard.addView(deadBallsRow, LinearLayout.LayoutParams(-1, dp(34)))
        root.addView(shooterCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        ballViews.clear(); val ballArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); background = darkCard(Color.rgb(28, 72, 108)) }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }; val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (n in 1..9) { val bv = BallView(this, n, ::cycleBallState); ballViews[n] = bv; val lp=LinearLayout.LayoutParams(0, dp(60), 1f).apply { marginStart=dp(1); marginEnd=dp(1) }; if(n<=5) r1.addView(bv,lp) else r2.addView(bv,lp) }
        ballArea.addView(r1); ballArea.addView(r2); root.addView(ballArea, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        root.addView(accentButton("END TURN", Color.rgb(0, 190, 88)) { turnOver() }.apply { textSize = 18f }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(8) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        defenseButton = accentButton("", Color.rgb(8, 37, 60)) { markDefensiveShot() }; timeoutButton = accentButton("", Color.rgb(8, 37, 60)) { useTimeout() }
        actions.addView(defenseButton, LinearLayout.LayoutParams(0, dp(60), 1f).apply { marginEnd = dp(5) }); actions.addView(timeoutButton, LinearLayout.LayoutParams(0, dp(60), 1f).apply { marginStart = dp(5) }); root.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(accentButton("↶   GO BACK / UNDO", Color.rgb(38, 53, 68)) { undo() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        val lower = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lower.addView(accentButton("RACK / STATS", Color.rgb(7, 72, 119)) { showRackStats() }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(5) }); lower.addView(accentButton("SAVE & EXIT", Color.rgb(7, 72, 119)) { saveActiveMatch(); showHome() }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(5) }); root.addView(lower, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(accentButton("END PRACTICE SESSION", Color.rgb(112, 35, 45)) { confirmEndSession() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8); bottomMargin = dp(10) })
        addBottomNav(root, "SCORE"); refreshScoreScreen()
    }


    private fun saveSnapshot() {
        undoStack.addLast(MatchSnapshot(a.score, b.score, a.defensiveShots, b.defensiveShots, a.timeoutsLeft, b.timeoutsLeft, currentPlayer, innings, rack, breaker, rackTurnovers, ballStates.copyOf(), ballOwners.copyOf(), ballLocked.copyOf(), nineOnSnapA, nineOnSnapB, breakRunsA, breakRunsB, rackPointsA.toList(), rackPointsB.toList()))
        while (undoStack.size > 80) undoStack.removeFirst()
    }

    private fun undo() {
        val s = if (undoStack.isEmpty()) null else undoStack.removeLast()
        if (s == null) { Toast.makeText(this, "Nothing to undo.", Toast.LENGTH_SHORT).show(); return }
        a.score = s.scoreA; b.score = s.scoreB; a.defensiveShots = s.defenseA; b.defensiveShots = s.defenseB; a.timeoutsLeft = s.timeoutsA; b.timeoutsLeft = s.timeoutsB
        currentPlayer = s.currentPlayer; innings = s.innings; rack = s.rack; breaker = s.breaker; rackTurnovers = s.rackTurnovers
        for (i in ballStates.indices) { ballStates[i] = s.ballStates[i]; ballOwners[i] = s.ballOwners[i]; ballLocked[i] = s.ballLocked[i] }
        nineOnSnapA = s.nineOnSnapA; nineOnSnapB = s.nineOnSnapB; breakRunsA = s.breakRunsA; breakRunsB = s.breakRunsB
        rackPointsA.clear(); rackPointsA.addAll(s.rackPointsA); rackPointsB.clear(); rackPointsB.addAll(s.rackPointsB)
        winnerDialogOpen = false; saveActiveMatch(); refreshScoreScreen()
    }

    private fun cycleBallState(n: Int) {
        if (ballLocked[n]) return
        val reached = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
        if (reached >= 0 && ballStates[n] == BALL_AVAILABLE) { showWinnerDialog(reached); return }
        saveSnapshot()
        val wasAvailable = ballStates[n] == BALL_AVAILABLE
        when (ballStates[n]) {
            BALL_AVAILABLE -> {
                val pts = if (n == 9) 2 else 1; player(currentPlayer).score += pts
                if (currentPlayer == 0) rackPointsA[rack - 1] += pts else rackPointsB[rack - 1] += pts
                ballStates[n] = BALL_POCKETED; ballOwners[n] = currentPlayer
            }
            BALL_POCKETED -> {
                val owner = ballOwners[n]; val pts = if (n == 9) 2 else 1
                if (owner == 0 || owner == 1) { player(owner).score = (player(owner).score - pts).coerceAtLeast(0); if (owner == 0) rackPointsA[rack - 1] = (rackPointsA[rack - 1] - pts).coerceAtLeast(0) else rackPointsB[rack - 1] = (rackPointsB[rack - 1] - pts).coerceAtLeast(0) }
                ballStates[n] = BALL_DEAD; ballOwners[n] = -1
            }
            BALL_DEAD -> { ballStates[n] = BALL_AVAILABLE; ballOwners[n] = -1 }
        }
        saveActiveMatch(); refreshScoreScreen()

        // V5.6: tapping the 9 to pocket it immediately starts the rack-end flow.
        if (n == 9 && wasAvailable && ballStates[9] == BALL_POCKETED) {
            handleNineBallTapped(currentPlayer)
            return
        }

        val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
        if (winner >= 0) showWinnerDialog(winner)
    }

    private fun showWinnerDialog(index: Int, snap: Boolean = false, run: Boolean = false) {
        if (winnerDialogOpen) return
        winnerDialogOpen = true; val p = player(index)
        AlertDialog.Builder(this).setTitle("${p.name} wins the match!")
            .setMessage("${p.name} reached ${p.score}/${p.target} ball points.\n\nIf the last ball was entered by mistake, choose Edit Score and correct it before confirming the result.")
            .setCancelable(false)
            .setNegativeButton("EDIT SCORE") { _, _ -> winnerDialogOpen = false; refreshScoreScreen() }
            .setPositiveButton("CONFIRM WIN") { _, _ ->
                if (snap) { if (index == 0) nineOnSnapA++ else nineOnSnapB++ }
                if (run) { if (index == 0) breakRunsA++ else breakRunsB++ }
                winnerDialogOpen = false; finalizeWinner(index)
            }
            .show()
    }

    private fun turnOver() {
        if (a.score >= a.target || b.score >= b.target) { showWinnerDialog(if (a.score >= a.target) 0 else 1); return }
        saveSnapshot(); val shooter = currentPlayer; val ninePocketed = ballStates[9] == BALL_POCKETED; val nineDead = ballStates[9] == BALL_DEAD
        for (n in 1..9) if (ballStates[n] != BALL_AVAILABLE) ballLocked[n] = true
        if (ninePocketed || nineDead) { handleRackEnd(shooter, ninePocketed); return }
        rackTurnovers++
        if (currentPlayer == 1) { innings++; rackInnings++ }
        currentPlayer = 1 - currentPlayer; saveActiveMatch(); refreshScoreScreen()
    }

    private fun handleNineBallTapped(shooter: Int) {
        val earlyNine = (1..8).any { ballStates[it] == BALL_AVAILABLE }
        val possibleSnap = shooter == breaker && rackTurnovers == 0

        fun continueAfterClassification(snap: Boolean) {
            val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
            if (winner >= 0) {
                // Match-win flow takes priority over starting another rack. The special-rack stat
                // is recorded only if the user confirms the win, so Edit Score cannot double-count it.
                showWinnerDialog(winner, snap = snap)
                return
            }
            promptNextRack(shooter, snap)
        }

        if (earlyNine) {
            val builder = AlertDialog.Builder(this)
                .setTitle("9 Ball Pocketed")
                .setMessage(if (possibleSnap) "How should this 9 ball be recorded?" else "The 9 ball was made before the rack was complete. How should it be recorded?")
                .setNegativeButton("CANCEL / EDIT") { _, _ ->
                    saveActiveMatch()
                    refreshScoreScreen()
                }

            if (possibleSnap) {
                builder
                    .setPositiveButton("9-ON-THE-SNAP") { _, _ -> continueAfterClassification(true) }
                    .setNeutralButton("9 BALL MADE EARLY") { _, _ -> continueAfterClassification(false) }
            } else {
                builder.setPositiveButton("9 BALL MADE EARLY") { _, _ -> continueAfterClassification(false) }
            }
            builder.show()
        } else {
            val runDetected = shooter == breaker && rackTurnovers == 0 && (1..8).all { ballStates[it] != BALL_AVAILABLE }
            if (runDetected) {
                AlertDialog.Builder(this).setTitle("Break & Run detected")
                    .setMessage("It looks like ${player(shooter).name} broke and ran the rack. Count this as a Break & Run?")
                    .setNegativeButton("NO") { _, _ -> promptNextRack(shooter, false) }
                    .setPositiveButton("YES") { _, _ ->
                        val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
                        if (winner >= 0) showWinnerDialog(winner, run = true) else promptNextRack(shooter, false, true)
                    }.show()
            } else {
                val winner = if (a.score >= a.target) 0 else if (b.score >= b.target) 1 else -1
                if (winner >= 0) showWinnerDialog(winner) else promptNextRack(shooter, false)
            }
        }
    }

    private fun promptNextRack(shooter: Int, snap: Boolean, run: Boolean = false) {
        AlertDialog.Builder(this)
            .setTitle("Go to next rack?")
            .setMessage("The 9 ball has been pocketed. Start the next rack now?")
            .setNegativeButton("GO BACK") { _, _ -> saveActiveMatch(); refreshScoreScreen() }
            .setPositiveButton("YES") { _, _ ->
                if (snap) { if (shooter == 0) nineOnSnapA++ else nineOnSnapB++ }
                if (run) { if (shooter == 0) breakRunsA++ else breakRunsB++ }
                for (n in 1..9) if (ballStates[n] != BALL_AVAILABLE) ballLocked[n] = true
                commitCurrentRack(if (snap) shooter else -1, if (run) shooter else -1)
                startNextRack(shooter)
            }
            .show()
    }

    private fun handleRackEnd(shooter: Int, ninePocketed: Boolean) {
        if (ninePocketed) { handleNineBallTapped(shooter); return }
        // A dead 9 still ends the rack, but is not a 9-on-the-Snap or Break & Run.
        AlertDialog.Builder(this)
            .setTitle("Go to next rack?")
            .setMessage("The 9 ball is dead. Start the next rack now?")
            .setNegativeButton("GO BACK") { _, _ -> saveActiveMatch(); refreshScoreScreen() }
            .setPositiveButton("YES") { _, _ -> commitCurrentRack(); startNextRack(shooter) }
            .show()
    }

    private fun markDefensiveShot() {
        saveSnapshot(); player(currentPlayer).defensiveShots++; if (currentPlayer == 0) rackDefenseA++ else rackDefenseB++; saveActiveMatch(); refreshScoreScreen()
    }

    private fun useTimeout() {
        val p = player(currentPlayer); if (p.timeoutsLeft <= 0) { Toast.makeText(this, "${p.name} has no timeouts left.", Toast.LENGTH_SHORT).show(); return }
        saveSnapshot(); p.timeoutsLeft--; if (currentPlayer == 0) rackTimeoutA++ else rackTimeoutB++; saveActiveMatch(); refreshScoreScreen()
    }

    private fun currentRackRecord(): RackRecord = RackRecord(rack, breaker, ballStates.copyOf(), ballOwners.copyOf(), rackInnings, rackDefenseA, rackDefenseB, rackTimeoutA, rackTimeoutB)

    private fun commitCurrentRack(snapPlayer: Int = -1, breakRunPlayer: Int = -1) {
        val rec = currentRackRecord(); rec.nineOnSnapPlayer = snapPlayer; rec.breakRunPlayer = breakRunPlayer; rackRecords.add(rec)
    }

    private fun startNextRack(nextBreaker: Int) {
        rack++; rackPointsA.add(0); rackPointsB.add(0); breaker = nextBreaker; currentPlayer = nextBreaker; rackTurnovers = 0; rackInnings = 0
        rackDefenseA = 0; rackDefenseB = 0; rackTimeoutA = 0; rackTimeoutB = 0
        ballStates.fill(BALL_AVAILABLE); ballOwners.fill(-1); ballLocked.fill(false); saveActiveMatch(); refreshScoreScreen()
    }

    private fun refreshScoreScreen() {
        if (!::scoreAText.isInitialized) return
        scoreAText.text = "${a.name}\n${a.score} / ${a.target}\nBall Points   •   SL ${a.skill}"
        scoreBText.text = "${b.name}\n${b.score} / ${b.target}\nBall Points   •   SL ${b.skill}"
        inningsText.text = "Rack $rack  •  $innings innings"
        val shooter = player(currentPlayer); shooterText.text = shooter.name; detailText.text = "Skill Level ${shooter.skill}  •  Breaker: ${player(breaker).name}"
        defenseButton.text = "${shooter.defensiveShots} Defensive Shots"; timeoutButton.text = "${shooter.timeoutsLeft} time-out${if (shooter.timeoutsLeft == 1) "" else "s"} left"
        playerPanelA.background = roundedBg(if (currentPlayer == 0) Color.rgb(6, 75, 145) else Color.rgb(12, 31, 48), if (currentPlayer == 0) Color.rgb(0, 210, 105) else Color.rgb(49, 86, 118), 16)
        playerPanelB.background = roundedBg(if (currentPlayer == 1) Color.rgb(128, 8, 34) else Color.rgb(62, 12, 27), if (currentPlayer == 1) Color.rgb(255, 48, 84) else Color.rgb(120, 50, 70), 16)
        ballViews.forEach { (n, v) -> v.state = ballStates[n]; v.visibility = if (ballLocked[n]) View.GONE else View.VISIBLE; v.isEnabled = !ballLocked[n] }
        refreshRackBallDisplays()
    }

    private fun refreshRackBallDisplays() {
        if (!::ballsARow.isInitialized) return
        ballsARow.removeAllViews(); ballsBRow.removeAllViews(); deadBallsRow.removeAllViews()
        for (n in 1..9) {
            if (ballStates[n] == BALL_POCKETED && ballOwners[n] == 0) ballsARow.addView(RackBallIconView(this, n), GridLayout.LayoutParams().apply { width = dp(29); height = dp(29) })
            if (ballStates[n] == BALL_POCKETED && ballOwners[n] == 1) ballsBRow.addView(RackBallIconView(this, n), GridLayout.LayoutParams().apply { width = dp(29); height = dp(29) })
            if (ballStates[n] == BALL_DEAD) deadBallsRow.addView(RackBallIconView(this, n), LinearLayout.LayoutParams(dp(29), dp(29)))
        }
        if (ballsARow.childCount == 0) ballsARow.addView(text("—", 14f, muted)); if (ballsBRow.childCount == 0) ballsBRow.addView(text("—", 14f, muted)); if (deadBallsRow.childCount == 0) deadBallsRow.addView(text("None", 13f, muted))
    }

    private fun showRackStats() {
        AlertDialog.Builder(this).setTitle("Rack $rack / Match Stats")
            .setMessage("${a.name}: ${a.score}/${a.target}\nDefensive shots: ${a.defensiveShots}\n9-on-the-Snap: $nineOnSnapA\nBreak & Runs: $breakRunsA\n\n${b.name}: ${b.score}/${b.target}\nDefensive shots: ${b.defensiveShots}\n9-on-the-Snap: $nineOnSnapB\nBreak & Runs: $breakRunsB\n\nInnings: $innings")
            .setPositiveButton("CLOSE", null).setNeutralButton("RACK HISTORY") { _, _ -> showRackHistory() }.show()
    }

    private fun showRackHistory() {
        saveActiveMatch()
        val root = page("Rack History / Edit")
        root.addView(text("Tap any rack to edit who made each ball, dead balls, innings, timeouts and defensive shots.", 13f, Color.rgb(185, 215, 238), true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val records = rackRecords.toMutableList(); records.add(currentRackRecord())
        for (idx in records.indices.reversed()) {
            val r = records[idx]; val isCurrent = idx == records.lastIndex
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); isClickable = true
                background = roundedBg(if (isCurrent) Color.rgb(5, 64, 115) else Color.rgb(7, 28, 47), if (isCurrent) Color.rgb(0, 211, 255) else Color.rgb(34, 130, 190), 18)
            }
            val title = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            title.addView(text("Rack ${r.rackNumber}", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            title.addView(text(if (isCurrent) "LIVE  ›" else "COMPLETE  ›", 11f, if (isCurrent) Color.rgb(0, 235, 255) else Color.rgb(79, 230, 130), true))
            row.addView(title)
            val aBalls = (1..9).filter { r.ballStates[it] == BALL_POCKETED && r.ballOwners[it] == 0 }; val bBalls = (1..9).filter { r.ballStates[it] == BALL_POCKETED && r.ballOwners[it] == 1 }; val dead = (1..9).filter { r.ballStates[it] == BALL_DEAD }
            row.addView(text("${a.name}: ${aBalls.joinToString(", ").ifBlank { "—" }}\n${b.name}: ${bBalls.joinToString(", ").ifBlank { "—" }}${if (dead.isNotEmpty()) "\nDead: ${dead.joinToString(", ")}" else ""}", 14f, Color.rgb(215, 232, 247)))
            row.setOnClickListener { showEditRack(idx, isCurrent) }
            root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        root.addView(accentButton("←   BACK TO MATCH", Color.rgb(0, 92, 190)) { showScoreScreen() }.apply { textSize = 17f }, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(6) })
        addBottomNav(root, "HOME")
    }

    private fun showEditRack(index: Int, isCurrent: Boolean) {
        val source = if (isCurrent) currentRackRecord() else rackRecords[index]
        val editStates = source.ballStates.copyOf(); val editOwners = source.ballOwners.copyOf()
        val root = page("Edit Rack ${source.rackNumber}")
        root.addView(text("Tap a ball to cycle: ${a.name} → ${b.name} → Dead → Available", 14f, muted, true))
        val grid = GridLayout(this).apply { columnCount = 3; setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val statusLabels = mutableMapOf<Int, TextView>()
        fun status(n: Int): String = when { editStates[n] == BALL_POCKETED && editOwners[n] == 0 -> a.name; editStates[n] == BALL_POCKETED && editOwners[n] == 1 -> b.name; editStates[n] == BALL_DEAD -> "Dead"; else -> "Available" }
        for (n in 1..9) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(5), dp(3), dp(5)); setBackgroundColor(Color.WHITE) }
            val icon = RackBallIconView(this, n); val label = text(status(n), 12f, muted, true).apply { gravity = Gravity.CENTER }; statusLabels[n] = label
            cell.addView(icon, LinearLayout.LayoutParams(dp(58), dp(58))); cell.addView(label)
            cell.setOnClickListener {
                when { editStates[n] == BALL_AVAILABLE -> { editStates[n] = BALL_POCKETED; editOwners[n] = 0 }; editStates[n] == BALL_POCKETED && editOwners[n] == 0 -> editOwners[n] = 1; editStates[n] == BALL_POCKETED -> { editStates[n] = BALL_DEAD; editOwners[n] = -1 }; else -> { editStates[n] = BALL_AVAILABLE; editOwners[n] = -1 } }
                label.text = status(n)
            }
            grid.addView(cell, GridLayout.LayoutParams().apply { width = 0; height = dp(104); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
        }
        root.addView(grid)
        fun numberEditor(label: String, initial: Int): Pair<LinearLayout, TextView> {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(4), dp(8), dp(4)) }
            row.addView(text(label, 15f, ink, true), LinearLayout.LayoutParams(0, -2, 1f)); val value = text(initial.toString(), 17f, ink, true).apply { gravity = Gravity.CENTER }
            val minus = button("−") {}; val plus = button("+") {}
            minus.setOnClickListener { value.text = ((value.text.toString().toIntOrNull() ?: 0) - 1).coerceAtLeast(0).toString() }; plus.setOnClickListener { value.text = ((value.text.toString().toIntOrNull() ?: 0) + 1).toString() }
            row.addView(minus, LinearLayout.LayoutParams(dp(54), dp(48))); row.addView(value, LinearLayout.LayoutParams(dp(60), dp(48))); row.addView(plus, LinearLayout.LayoutParams(dp(54), dp(48))); return row to value
        }
        val (innRow, innVal) = numberEditor("Innings", source.innings); val (defARow, defAVal) = numberEditor("${a.name} defensive shots", source.defensiveA); val (defBRow, defBVal) = numberEditor("${b.name} defensive shots", source.defensiveB); val (toARow, toAVal) = numberEditor("${a.name} timeouts used", source.timeoutsA); val (toBRow, toBVal) = numberEditor("${b.name} timeouts used", source.timeoutsB)
        listOf(innRow, defARow, defBRow, toARow, toBRow).forEach { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }) }
        root.addView(button("SAVE RACK CHANGES", true) {
            source.ballStates = editStates; source.ballOwners = editOwners; source.innings = innVal.text.toString().toIntOrNull() ?: source.innings; source.defensiveA = defAVal.text.toString().toIntOrNull() ?: source.defensiveA; source.defensiveB = defBVal.text.toString().toIntOrNull() ?: source.defensiveB; source.timeoutsA = toAVal.text.toString().toIntOrNull() ?: source.timeoutsA; source.timeoutsB = toBVal.text.toString().toIntOrNull() ?: source.timeoutsB
            if (isCurrent) { for (i in 0..9) { ballStates[i] = source.ballStates[i]; ballOwners[i] = source.ballOwners[i] }; rackInnings = source.innings; rackDefenseA = source.defensiveA; rackDefenseB = source.defensiveB; rackTimeoutA = source.timeoutsA; rackTimeoutB = source.timeoutsB } else rackRecords[index] = source
            recalculateFromRackData(); saveActiveMatch(); showRackHistory()
        }, LinearLayout.LayoutParams(-1, dp(60)).apply { topMargin = dp(12) })
        root.addView(button("CANCEL") { showRackHistory() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(7) })
    }

    private fun pointsFor(r: RackRecord, owner: Int): Int = (1..9).sumOf { n -> if (r.ballStates[n] == BALL_POCKETED && r.ballOwners[n] == owner) if (n == 9) 2 else 1 else 0 }

    private fun recalculateFromRackData() {
        val all = rackRecords.toMutableList(); all.add(currentRackRecord())
        a.score = all.sumOf { pointsFor(it, 0) }; b.score = all.sumOf { pointsFor(it, 1) }
        a.defensiveShots = all.sumOf { it.defensiveA }; b.defensiveShots = all.sumOf { it.defensiveB }
        val usedA = all.sumOf { it.timeoutsA }; val usedB = all.sumOf { it.timeoutsB }; a.timeoutsLeft = (maxTimeouts(a) - usedA).coerceAtLeast(0); b.timeoutsLeft = (maxTimeouts(b) - usedB).coerceAtLeast(0)
        innings = all.sumOf { it.innings }; nineOnSnapA = rackRecords.count { it.nineOnSnapPlayer == 0 }; nineOnSnapB = rackRecords.count { it.nineOnSnapPlayer == 1 }; breakRunsA = rackRecords.count { it.breakRunPlayer == 0 }; breakRunsB = rackRecords.count { it.breakRunPlayer == 1 }
        rackPointsA.clear(); rackPointsB.clear(); all.forEach { rackPointsA.add(pointsFor(it, 0)); rackPointsB.add(pointsFor(it, 1)) }
        if (a.score < a.target && b.score < b.target) winnerDialogOpen = false
    }

    private fun rackToJson(r: RackRecord): JSONObject = JSONObject().apply {
        put("rack", r.rackNumber); put("breaker", r.breaker); put("states", JSONArray(r.ballStates.toList())); put("owners", JSONArray(r.ballOwners.toList())); put("innings", r.innings); put("defA", r.defensiveA); put("defB", r.defensiveB); put("toA", r.timeoutsA); put("toB", r.timeoutsB); put("snap", r.nineOnSnapPlayer); put("br", r.breakRunPlayer)
    }

    private fun jsonArrayToIntArray(arr: JSONArray?, size: Int, default: Int = 0): IntArray = IntArray(size) { i -> arr?.optInt(i, default) ?: default }

    private fun jsonToRack(o: JSONObject): RackRecord = RackRecord(o.optInt("rack", 1), o.optInt("breaker", 0), jsonArrayToIntArray(o.optJSONArray("states"), 10), jsonArrayToIntArray(o.optJSONArray("owners"), 10, -1), o.optInt("innings"), o.optInt("defA"), o.optInt("defB"), o.optInt("toA"), o.optInt("toB"), o.optInt("snap", -1), o.optInt("br", -1))

    private fun activeMatchJson(): JSONObject = JSONObject().apply {
        put("id", activeMatchId ?: UUID.randomUUID().toString()); put("updated", System.currentTimeMillis()); put("p1", a.name); put("p2", b.name); put("skill1", a.skill); put("skill2", b.skill); put("target1", a.target); put("target2", b.target); put("current", currentPlayer); put("rack", rack); put("breaker", breaker); put("turnovers", rackTurnovers); put("rackInnings", rackInnings); put("rackDefA", rackDefenseA); put("rackDefB", rackDefenseB); put("rackToA", rackTimeoutA); put("rackToB", rackTimeoutB); put("states", JSONArray(ballStates.toList())); put("owners", JSONArray(ballOwners.toList())); put("locked", JSONArray(ballLocked.map { if (it) 1 else 0 })); put("records", JSONArray().apply { rackRecords.forEach { put(rackToJson(it)) } })
    }

    private fun saveActiveMatch() {
        val id = activeMatchId ?: return; val arr = activeMatches(); val next = JSONArray(); var replaced = false
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; if (o.optString("id") == id) { next.put(activeMatchJson()); replaced = true } else next.put(o) }
        if (!replaced) next.put(activeMatchJson()); prefs.edit().putString("active_matches_v58", next.toString()).apply()
    }

    private fun removeActiveMatch(id: String?) {
        if (id == null) return; val arr = activeMatches(); val next = JSONArray(); for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; if (o.optString("id") != id) next.put(o) }; prefs.edit().putString("active_matches_v58", next.toString()).apply()
    }

    private fun loadActiveMatch(o: JSONObject) {
        activeMatchId = o.optString("id"); a = PracticePlayer(o.optString("p1", "Player 1"), o.optInt("skill1", 4), o.optInt("target1", 31)); b = PracticePlayer(o.optString("p2", "Player 2"), o.optInt("skill2", 4), o.optInt("target2", 31))
        currentPlayer = o.optInt("current"); rack = o.optInt("rack", 1); breaker = o.optInt("breaker"); rackTurnovers = o.optInt("turnovers"); rackInnings = o.optInt("rackInnings"); rackDefenseA = o.optInt("rackDefA"); rackDefenseB = o.optInt("rackDefB"); rackTimeoutA = o.optInt("rackToA"); rackTimeoutB = o.optInt("rackToB")
        val st = jsonArrayToIntArray(o.optJSONArray("states"), 10); val ow = jsonArrayToIntArray(o.optJSONArray("owners"), 10, -1); val lk = jsonArrayToIntArray(o.optJSONArray("locked"), 10)
        for (i in 0..9) { ballStates[i] = st[i]; ballOwners[i] = ow[i]; ballLocked[i] = lk[i] == 1 }
        rackRecords.clear(); val rec = o.optJSONArray("records"); if (rec != null) for (i in 0 until rec.length()) rackRecords.add(jsonToRack(rec.getJSONObject(i)))
        recalculateFromRackData(); undoStack.clear(); winnerDialogOpen = false; showScoreScreen()
    }

    private fun showActiveMatches() {
        val root = page("Active Matches"); val arr = activeMatches()
        if (arr.length() == 0) root.addView(text("No unfinished matches saved.", 17f, muted)) else {
            root.addView(text("Tap a match to resume it. Long-press to discard it.", 14f, muted, true))
            val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.sortedByDescending { it.optLong("updated") }
            items.forEach { o ->
                val entry = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)); isClickable = true; isLongClickable = true }
                val tmpA = o.optString("p1"); val tmpB = o.optString("p2"); entry.addView(text("$tmpA vs $tmpB", 17f, ink, true)); entry.addView(text("Rack ${o.optInt("rack", 1)}  •  Tap to continue", 14f, muted))
                entry.setOnClickListener { loadActiveMatch(o) }; entry.setOnLongClickListener { AlertDialog.Builder(this).setTitle("Discard unfinished match?").setMessage("$tmpA vs $tmpB").setNegativeButton("CANCEL", null).setPositiveButton("DISCARD") { _, _ -> removeActiveMatch(o.optString("id")); showActiveMatches() }.show(); true }
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        root.addView(button("NEW MATCH", true) { showSetup() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) }); root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
    }

    private fun standardApaTarget(skill: Int): Int = when (skill.coerceIn(1, 9)) { 1 -> 14; 2 -> 19; 3 -> 25; 4 -> 31; 5 -> 38; 6 -> 46; 7 -> 55; 8 -> 65; else -> 75 }

    private fun calculateApaMatchResult(winnerName: String): ApaMatchResult? {
        if (a.target != standardApaTarget(a.skill) || b.target != standardApaTarget(b.skill)) return null
        val winnerIsA = winnerName == a.name; val loser = if (winnerIsA) b else a; val loserBall = loser.score
        val maxBySkill = arrayOf(intArrayOf(2,3,4,6,7,8,10,11,13), intArrayOf(3,5,7,8,10,12,14,16,18), intArrayOf(4,6,9,11,14,16,19,21,24), intArrayOf(5,8,11,14,18,21,24,27,30), intArrayOf(6,10,14,18,22,26,29,33,37), intArrayOf(8,12,17,22,27,31,36,40,45), intArrayOf(10,15,21,26,32,37,43,49,54), intArrayOf(13,19,26,32,39,45,52,58,64), intArrayOf(17,24,31,38,46,53,60,67,74))
        val thresholds = maxBySkill[loser.skill - 1]; var loserPts = 0; for (i in thresholds.indices) if (loserBall <= thresholds[i]) { loserPts = i; break } else loserPts = 8
        val winnerPts = 20 - loserPts; return ApaMatchResult(if (winnerIsA) a.name else b.name, loser.name, winnerPts, loserPts, loser.skill, loserBall)
    }

    private fun confirmEndSession() {
        AlertDialog.Builder(this).setTitle("End practice session?").setMessage("You can keep this match in Active Matches or end it and save the current result to history.")
            .setNegativeButton("KEEP ACTIVE") { _, _ -> saveActiveMatch(); showHome() }.setPositiveButton("END & SAVE") { _, _ -> saveHistory(null); removeActiveMatch(activeMatchId); showHome() }.show()
    }

    private fun finalizeWinner(index: Int) {
        val winner = player(index); saveHistory(winner.name); removeActiveMatch(activeMatchId); showMatchComplete(winner)
    }

    private fun showMatchComplete(winner: PracticePlayer) {
        val apa = calculateApaMatchResult(winner.name); val h2h = headToHead(a.name, b.name)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.TRANSPARENT); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(56)); gravity = Gravity.CENTER_HORIZONTAL }
        scroll.addView(root); cinematicContent(scroll)
        root.addView(RackBallIconView(this, 9), LinearLayout.LayoutParams(dp(104), dp(104)))
        root.addView(text("9 BALL LEAGUE", 25f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        root.addView(text("PRACTICE", 25f, Color.rgb(0, 179, 255), true).apply { gravity = Gravity.CENTER; letterSpacing = .06f })
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = roundedBg(Color.rgb(4, 28, 48), Color.rgb(0, 183, 255), 22) }
        card.addView(text("PRACTICE MATCH COMPLETE", 21f, Color.rgb(63, 194, 255), true).apply { gravity = Gravity.CENTER })
        card.addView(text("🏆  ${winner.name} wins!", 25f, Color.WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })
        val scores = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun resultPanel(p: PracticePlayer, br: Int, snap: Int, left: Boolean): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(10), dp(8), dp(10))
            background = roundedBg(if (left) Color.rgb(0, 68, 142) else Color.rgb(125, 7, 33), if (left) Color.rgb(0, 191, 255) else Color.rgb(255, 47, 80), 16)
            addView(text(p.name, 17f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
            addView(text("${p.score} / ${p.target}", 25f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
            addView(text("Break & Runs: $br\n9-on-the-Snap: $snap", 12f, Color.rgb(224, 236, 246)).apply { gravity = Gravity.CENTER })
        }
        scores.addView(resultPanel(a, breakRunsA, nineOnSnapA, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        scores.addView(resultPanel(b, breakRunsB, nineOnSnapB, false), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        card.addView(scores)
        val hCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(10), dp(9), dp(10), dp(9)); background = darkCard(Color.rgb(0, 150, 220), 14) }
        hCard.addView(text("All-time head-to-head", 12f, Color.rgb(160, 211, 245)).apply { gravity = Gravity.CENTER })
        hCard.addView(text("${a.name}  ${h2h.first} – ${h2h.second}  ${b.name}", 17f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        card.addView(hCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        card.addView(text("Score progression by rack", 14f, Color.WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        card.addView(RackPerformanceView(this, a.name, b.name, rackPointsA.toList(), rackPointsB.toList()), LinearLayout.LayoutParams(-1, dp(240)))
        if (apa != null) card.addView(text("Match Points: ${apa.winnerName} ${apa.winnerPoints} - ${apa.loserPoints} ${apa.loserName}", 14f, Color.rgb(40, 220, 255), true).apply { gravity = Gravity.CENTER; background = darkCard(Color.rgb(0, 170, 210), 12) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        card.addView(accentButton("✓   DONE", Color.rgb(0, 176, 76)) { showHome() }.apply { textSize = 19f }, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(10) })
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        addBottomNav(root, "HOME")
    }

    private fun saveHistory(winner: String?) {
        val arr = JSONArray(prefs.getString("history", "[]")); val recs = JSONArray().apply { rackRecords.forEach { put(rackToJson(it)) }; put(rackToJson(currentRackRecord())) }
        arr.put(JSONObject().apply {
            put("date", SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US).format(Date())); put("p1", a.name); put("p2", b.name); put("score1", a.score); put("score2", b.score); put("target1", a.target); put("target2", b.target); put("skill1", a.skill); put("skill2", b.skill); put("innings", innings); put("racks", rack); put("def1", a.defensiveShots); put("def2", b.defensiveShots); put("timeoutsUsed1", maxTimeouts(a) - a.timeoutsLeft); put("timeoutsUsed2", maxTimeouts(b) - b.timeoutsLeft); put("snap1", nineOnSnapA); put("snap2", nineOnSnapB); put("br1", breakRunsA); put("br2", breakRunsB); put("rackPoints1", JSONArray(rackPointsA)); put("rackPoints2", JSONArray(rackPointsB)); put("rackRecords", recs); put("winner", winner ?: "Session ended")
            val apa = winner?.let { calculateApaMatchResult(it) }; if (apa != null) { put("apaWinner", apa.winnerName); put("apaLoser", apa.loserName); put("apaWinnerPoints", apa.winnerPoints); put("apaLoserPoints", apa.loserPoints); put("apaLoserSkill", apa.loserSkill); put("apaLoserBallPoints", apa.loserBallPoints) }
        })
        while (arr.length() > 100) { val trimmed = JSONArray(); for (i in 1 until arr.length()) trimmed.put(arr.get(i)); prefs.edit().putString("history", trimmed.toString()).apply(); return }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    private fun jsonIntList(o: JSONObject, key: String): List<Int> { val arr = o.optJSONArray(key) ?: return emptyList(); return (0 until arr.length()).map { arr.optInt(it, 0) } }

    private fun showHistoryMatch(o: JSONObject) {
        val p1 = o.optString("p1", "Player 1"); val p2 = o.optString("p2", "Player 2"); val rack1 = jsonIntList(o, "rackPoints1"); val rack2 = jsonIntList(o, "rackPoints2"); val root = page("Match Graph & Stats")
        root.addView(text("$p1 vs $p2", 21f, ink, true)); root.addView(text(o.optString("date"), 14f, muted)); val h = headToHead(p1, p2); root.addView(text("All-time head-to-head: $p1 ${h.first} – ${h.second} $p2  •  ${h.third} matches", 14f, blue, true))
        if (rack1.isNotEmpty() || rack2.isNotEmpty()) root.addView(RackPerformanceView(this, p1, p2, rack1, rack2), LinearLayout.LayoutParams(-1, dp(280)).apply { topMargin = dp(10); bottomMargin = dp(10) }) else root.addView(text("Rack-by-rack graph data was not saved for this older match.", 14f, muted))
        val stats = "${p1}: ${o.optInt("score1")}/${o.optInt("target1")} • SL ${o.optInt("skill1")} • Defensive ${o.optInt("def1")} • Timeouts ${o.optInt("timeoutsUsed1")} • 9-on-Snap ${o.optInt("snap1")} • Break & Runs ${o.optInt("br1")}\n\n${p2}: ${o.optInt("score2")}/${o.optInt("target2")} • SL ${o.optInt("skill2")} • Defensive ${o.optInt("def2")} • Timeouts ${o.optInt("timeoutsUsed2")} • 9-on-Snap ${o.optInt("snap2")} • Break & Runs ${o.optInt("br2")}"
        root.addView(text(stats, 14f, ink).apply { setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12)) })
        if (o.has("apaWinnerPoints")) root.addView(text("Match Points: ${o.optString("apaWinner")} ${o.optInt("apaWinnerPoints")} - ${o.optInt("apaLoserPoints")} ${o.optString("apaLoser")}", 14f, blue, true))
        root.addView(button("BACK TO MATCH HISTORY", true) { showHistory() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(8) })
    }

    private fun showHistory() {
        val root = page("Practice History"); val arr = JSONArray(prefs.getString("history", "[]"))
        if (arr.length() == 0) root.addView(text("No practice sessions saved yet.", 17f, muted)) else {
            root.addView(text("Tap a match for Graph & Stats. Long-press a match to delete it.", 14f, muted, true))
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i); val entry = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)); isClickable = true; isLongClickable = true }
                entry.addView(text("${o.optString("p1")} ${o.optInt("score1")}/${o.optInt("target1")}   •   ${o.optString("p2")} ${o.optInt("score2")}/${o.optInt("target2")}", 16f, ink, true)); entry.addView(text("${o.optString("date")}  •  ${o.optInt("innings")} innings  •  ${o.optInt("racks")} racks", 13f, muted)); entry.addView(text("9-on-Snap ${o.optInt("snap1")}/${o.optInt("snap2")}  •  Break & Runs ${o.optInt("br1")}/${o.optInt("br2")}", 13f, muted))
                entry.setOnClickListener { showHistoryMatch(o) }; entry.setOnLongClickListener { AlertDialog.Builder(this).setTitle("Delete this match?").setMessage("${o.optString("p1")} vs ${o.optString("p2")}").setNegativeButton("CANCEL", null).setPositiveButton("DELETE") { _, _ -> val next = JSONArray(); for (j in 0 until arr.length()) if (j != i) next.put(arr.get(j)); prefs.edit().putString("history", next.toString()).apply(); showHistory() }.show(); true }
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        root.addView(button("CLEAR HISTORY") { AlertDialog.Builder(this).setTitle("Clear practice history?").setNegativeButton("CANCEL", null).setPositiveButton("CLEAR") { _, _ -> prefs.edit().remove("history").apply(); showHistory() }.show() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) }); root.addView(button("BACK") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
    }
}
