9 Ball League Practice V5.8.7
versionCode 73

Background-only hotfix from V5.8.6:
- Removed the artificial center divider from pool_hall_bg.jpg.
- Background now uses one continuous full-screen image.
- No scoring, layout, navigation, control, or app-logic changes.
