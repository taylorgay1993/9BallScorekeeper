package com.nineball.scorekeeper

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Player(var name:String,var skill:Int=4,var target:Int=25,var wins:Int=0,var losses:Int=0,var team:String="")
data class Team(var name:String,var wins:Int=0,var losses:Int=0,var points:Int=0)
data class Rack(var a:Int,var b:Int)

class MainActivity:AppCompatActivity(){
    private val prefs by lazy{getSharedPreferences("league",Context.MODE_PRIVATE)}
    private val players=mutableListOf<Player>()
    private val teams=mutableListOf<Team>()
    private val racks=mutableListOf<Rack>()
    private var currentA:Player?=null; private var currentB:Player?=null
    private var totalA=0; private var totalB=0
    private var currentTeamA=""; private var currentTeamB=""
    private var week=1
    private val gold=0xFFD7A62A.toInt(); private val bg=0xFF101010.toInt(); private val panel=0xFF1B1B1B.toInt()

    override fun onCreate(b:Bundle?){super.onCreate(b);loadAll();home()}

    private fun root(title:String):LinearLayout{
        val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(22,18,22,22)}
        val t=TextView(this).apply{text=title;textSize=24f;setTextColor(gold);setTypeface(null,1);gravity=Gravity.CENTER_VERTICAL}
        r.addView(t,LinearLayout.LayoutParams(-1,65));setContentView(r);return r
    }
    private fun btn(s:String,go:()->Unit)=Button(this).apply{text=s;textSize=17f;isAllCaps=false;setTextColor(0xFFFFFFFF.toInt());setBackgroundColor(panel);setOnClickListener{go()}}
    private fun txt(s:String,size:Float=16f)=TextView(this).apply{text=s;textSize=size;setTextColor(0xFFFFFFFF.toInt());setPadding(4,8,4,8)}

    private fun home(){
        val r=root("9 BALL SCOREKEEPER")
        r.addView(txt("LEAGUE NIGHT  •  Week $week",18f))
        r.addView(btn("START LEAGUE MATCH"){chooseTeamMatch()})
        r.addView(btn("WEEKLY SCHEDULE"){scheduleScreen()})
        r.addView(btn("STANDINGS"){standingsScreen()})
        r.addView(btn("TEAMS & ROSTERS"){teamsScreen()})
        r.addView(btn("PLAYERS"){playersScreen()})
        r.addView(btn("MATCH HISTORY"){historyScreen()})
        r.addView(btn("LEAGUE SETTINGS"){settingsScreen()})
        r.addView(txt("\nOffline • data stays on this phone\nCustom targets • rack-by-rack scoring",14f))
    }

    private fun playersScreen(){
        val r=root("PLAYERS")
        r.addView(btn("+ ADD PLAYER"){playerDialog(null)})
        players.forEach{p->
            val line=LinearLayout(this);line.gravity=Gravity.CENTER_VERTICAL
            line.addView(txt("${p.name}  • SL ${p.skill}  • Target ${p.target}\n${p.team.ifBlank{"Free Agent"}}  • ${p.wins}-${p.losses}",15f),LinearLayout.LayoutParams(0,76,1f))
            line.addView(btn("EDIT"){playerDialog(p)},LinearLayout.LayoutParams(105,65));r.addView(line)
        }
        r.addView(btn("BACK"){home()})
    }

    private fun playerDialog(p:Player?){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(25,25,25,25)}
        val n=EditText(this).apply{hint="Player name";setText(p?.name?:"")}
        val sl=EditText(this).apply{hint="Skill level";inputType=2;setText((p?.skill?:4).toString())}
        val tg=EditText(this).apply{hint="Target balls";inputType=2;setText((p?.target?:25).toString())}
        val tm=EditText(this).apply{hint="Team name (optional)";setText(p?.team?:"")}
        box.addView(n);box.addView(sl);box.addView(tg);box.addView(tm)
        AlertDialog.Builder(this).setTitle(if(p==null)"Add Player" else "Edit Player").setView(box)
            .setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
                val name=n.text.toString().trim();if(name.isBlank())return@setPositiveButton
                if(p==null)players.add(Player(name,sl.text.toString().toIntOrNull()?:4,tg.text.toString().toIntOrNull()?:25,0,0,tm.text.toString().trim()))
                else{p.name=name;p.skill=sl.text.toString().toIntOrNull()?:p.skill;p.target=tg.text.toString().toIntOrNull()?:p.target;p.team=tm.text.toString().trim()}
                saveAll();playersScreen()
            }.show()
    }

    private fun teamsScreen(){
        val r=root("TEAMS & ROSTERS")
        r.addView(btn("+ ADD TEAM"){teamDialog(null)})
        teams.forEach{t->
            r.addView(txt("${t.name}   ${t.wins}-${t.losses}   ${t.points} pts",17f))
            val roster=players.filter{it.team==t.name}.joinToString(", "){it.name}
            r.addView(txt(if(roster.isBlank())"  No players assigned" else"  $roster",14f))
            r.addView(btn("EDIT TEAM"){teamDialog(t)})
        }
        r.addView(btn("ASSIGN PLAYER TO TEAM"){assignDialog()})
        r.addView(btn("BACK"){home()})
    }

    private fun teamDialog(t:Team?){
        val e=EditText(this).apply{hint="Team name";setText(t?.name?:"")}
        AlertDialog.Builder(this).setTitle(if(t==null)"Add Team" else"Edit Team").setView(e)
            .setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
                val n=e.text.toString().trim();if(n.isBlank())return@setPositiveButton
                if(t==null)teams.add(Team(n)) else {players.filter{it.team==t.name}.forEach{it.team=n};t.name=n}
                saveAll();teamsScreen()
            }.show()
    }

    private fun assignDialog(){
        if(players.isEmpty()||teams.isEmpty()){Toast.makeText(this,"Add players and teams first.",Toast.LENGTH_SHORT).show();return}
        val names=players.map{it.name};val ts=listOf("Free Agent")+teams.map{it.name}
        val ps=Spinner(this);ps.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names)
        val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,ts)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20)};box.addView(ps);box.addView(sp)
        AlertDialog.Builder(this).setTitle("Assign Player").setView(box).setNegativeButton("Cancel",null)
            .setPositiveButton("Save"){_,_->players[ps.selectedItemPosition].team=if(sp.selectedItemPosition==0)"" else teams[sp.selectedItemPosition-1].name;saveAll();teamsScreen()}.show()
    }

    private fun chooseTeamMatch(){
        if(teams.size<2){Toast.makeText(this,"Create at least two teams first.",Toast.LENGTH_SHORT).show();teamsScreen();return}
        val r=root("WEEK $week — TEAM MATCH")
        val a=Spinner(this);val b=Spinner(this);val names=teams.map{it.name}
        a.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names);b.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names)
        r.addView(txt("Home team"));r.addView(a);r.addView(txt("Away team"));r.addView(b)
        r.addView(btn("BUILD MATCHUP"){if(a.selectedItemPosition==b.selectedItemPosition)Toast.makeText(this,"Choose different teams.",Toast.LENGTH_SHORT).show() else matchupScreen(names[a.selectedItemPosition],names[b.selectedItemPosition])})
        r.addView(btn("BACK"){home()})
    }

    private fun matchupScreen(ta:String,tb:String){
        val r=root("$ta  vs  $tb")
        val pa=players.filter{it.team==ta};val pb=players.filter{it.team==tb}
        if(pa.isEmpty()||pb.isEmpty())r.addView(txt("Both teams need players assigned."))
        else{
            r.addView(txt("Select players for this individual match."))
            val sa=Spinner(this);val sb=Spinner(this)
            sa.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,pa.map{it.name})
            sb.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,pb.map{it.name})
            r.addView(sa);r.addView(sb)
            r.addView(btn("START INDIVIDUAL MATCH"){
                startMatch(pa[sa.selectedItemPosition],pb[sb.selectedItemPosition],ta,tb)
            })
        }
        r.addView(btn("BACK"){chooseTeamMatch()})
    }

    private fun startMatch(a:Player,b:Player,ta:String,tb:String){
        currentA=a;currentB=b;currentTeamA=ta;currentTeamB=tb;totalA=0;totalB=0;racks.clear();scoreScreen()
    }

    private fun scoreScreen(){
        val a=currentA!!;val b=currentB!!;val r=root("${a.name}  vs  ${b.name}")
        val score=txt("",27f);score.gravity=Gravity.CENTER
        val info=txt("",15f);info.gravity=Gravity.CENTER
        fun refresh(){score.text="${a.name}: $totalA      ${b.name}: $totalB";info.text="Targets ${a.target} / ${b.target}   •   Remaining ${maxOf(0,a.target-totalA)} / ${maxOf(0,b.target-totalB)}\nRacks: ${racks.size}"}
        refresh();r.addView(score);r.addView(info)
        val row=LinearLayout(this)
        val ea=EditText(this).apply{hint="${a.name} balls";inputType=2};val eb=EditText(this).apply{hint="${b.name} balls";inputType=2}
        row.addView(ea,LinearLayout.LayoutParams(0,70,1f));row.addView(eb,LinearLayout.LayoutParams(0,70,1f));r.addView(row)
        r.addView(btn("ADD RACK"){
            val x=ea.text.toString().toIntOrNull();val y=eb.text.toString().toIntOrNull()
            if(x==null||y==null||x<0||y<0){Toast.makeText(this,"Enter both scores.",Toast.LENGTH_SHORT).show();return@btn}
            racks.add(Rack(x,y));totalA+=x;totalB+=y;ea.text.clear();eb.text.clear();refresh()
            if(totalA>=a.target||totalB>=b.target)completeMatch(if(totalA>=a.target)a else b)
        })
        r.addView(btn("UNDO LAST RACK"){if(racks.isNotEmpty()){val z=racks.removeAt(racks.lastIndex);totalA-=z.a;totalB-=z.b;refresh()}})
        r.addView(btn("END / FORFEIT"){completeMatch(if(totalA>=totalB)a else b)})
        r.addView(btn("CANCEL"){home()})
    }

    private fun completeMatch(w:Player){
        val l=if(w===currentA)currentB!! else currentA!!
        w.wins++;l.losses++
        val winnerTeam=if(w===currentA)currentTeamA else currentTeamB
        val loserTeam=if(w===currentA)currentTeamB else currentTeamA
        teams.find{it.name==winnerTeam}?.apply{wins++;points+=2}
        teams.find{it.name==loserTeam}?.apply{losses++}
        val h=JSONArray(prefs.getString("history","[]"))
        h.put(JSONObject().apply{put("date",SimpleDateFormat("MMM d, yyyy h:mm a",Locale.US).format(Date()));put("week",week)
            put("p1",currentA!!.name);put("p2",currentB!!.name);put("score","$totalA - $totalB");put("winner",w.name);put("team1",currentTeamA);put("team2",currentTeamB)})
        prefs.edit().putString("history",h.toString()).apply();saveAll()
        AlertDialog.Builder(this).setTitle("MATCH COMPLETE").setMessage("${w.name} wins!\n$totalA - $totalB")
            .setPositiveButton("LEAGUE NIGHT"){_,_->home()}.show()
    }

    private fun standingsScreen(){
        val r=root("STANDINGS — WEEK $week")
        if(teams.isEmpty())r.addView(txt("No teams yet."))
        teams.sortedWith(compareByDescending<Team>{it.points}.thenByDescending{it.wins}).forEachIndexed{i,t->
            r.addView(txt("${i+1}.  ${t.name}\n    ${t.points} pts   •   ${t.wins}-${t.losses}",18f))
        }
        r.addView(btn("BACK"){home()})
    }

    private fun scheduleScreen(){
        val r=root("WEEKLY SCHEDULE")
        r.addView(txt("Current league week: $week",19f))
        if(teams.size<2)r.addView(txt("Create two or more teams to build matchups."))
        else for(i in 0 until teams.size step 2)if(i+1<teams.size)r.addView(txt("Week $week  •  ${teams[i].name}  vs  ${teams[i+1].name}",17f))
        r.addView(btn("ADVANCE TO NEXT WEEK"){week++;prefs.edit().putInt("week",week).apply();home()})
        r.addView(btn("BACK"){home()})
    }

    private fun historyScreen(){
        val r=root("MATCH HISTORY");val h=JSONArray(prefs.getString("history","[]"))
        if(h.length()==0)r.addView(txt("No completed matches."))
        for(i in h.length()-1 downTo 0){val o=h.getJSONObject(i);r.addView(txt("Week ${o.optInt("week",1)} • ${o.getString("date")}\n${o.getString("team1")}: ${o.getString("p1")}  vs  ${o.getString("team2")}: ${o.getString("p2")}\nScore ${o.getString("score")} • Winner: ${o.getString("winner")}",15f))}
        r.addView(btn("BACK"){home()})
    }

    private fun settingsScreen(){
        val r=root("LEAGUE SETTINGS")
        r.addView(txt("Week number: $week",18f))
        r.addView(btn("SET WEEK NUMBER"){
            val e=EditText(this).apply{inputType=2;setText(week.toString())}
            AlertDialog.Builder(this).setTitle("Set Current Week").setView(e).setNegativeButton("Cancel",null)
                .setPositiveButton("Save"){_,_->week=e.text.toString().toIntOrNull()?.coerceAtLeast(1)?:week;prefs.edit().putInt("week",week).apply();settingsScreen()}.show()
        })
        r.addView(btn("RESET ALL LEAGUE DATA"){
            AlertDialog.Builder(this).setTitle("Delete Everything?").setMessage("Players, teams and history will be erased.")
                .setNegativeButton("Cancel",null).setPositiveButton("DELETE"){_,_->prefs.edit().clear().apply();players.clear();teams.clear();week=1;home()}.show()
        })
        r.addView(btn("BACK"){home()})
    }

    private fun saveAll(){
        val pa=JSONArray();players.forEach{p->pa.put(JSONObject().apply{put("name",p.name);put("skill",p.skill);put("target",p.target);put("wins",p.wins);put("losses",p.losses);put("team",p.team)})}
        val ta=JSONArray();teams.forEach{t->ta.put(JSONObject().apply{put("name",t.name);put("wins",t.wins);put("losses",t.losses);put("points",t.points)})}
        prefs.edit().putString("players",pa.toString()).putString("teams",ta.toString()).putInt("week",week).apply()
    }
    private fun loadAll(){
        week=prefs.getInt("week",1);players.clear();teams.clear()
        val pa=JSONArray(prefs.getString("players","[]"));for(i in 0 until pa.length()){val o=pa.getJSONObject(i);players.add(Player(o.getString("name"),o.optInt("skill",4),o.optInt("target",25),o.optInt("wins",0),o.optInt("losses",0),o.optString("team","")))}
        val ta=JSONArray(prefs.getString("teams","[]"));for(i in 0 until ta.length()){val o=ta.getJSONObject(i);teams.add(Team(o.getString("name"),o.optInt("wins"),o.optInt("losses"),o.optInt("points")))}
    }
}