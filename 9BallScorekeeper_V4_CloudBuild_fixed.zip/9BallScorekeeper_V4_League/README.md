# 9 Ball Scorekeeper V4.1 — Full League Night

This build expands the scorekeeper into a local/offline league-night manager.

Included:
- Players, skill levels, targets, W/L records
- Teams and rosters
- League setup
- Weekly schedule / match nights
- Team standings: matches won/lost, individual match wins/losses, points
- Weekly team-vs-team matchup
- Individual player matchups
- Rack-by-rack ball scoring
- Automatic target/winner detection
- Undo rack
- Match history
- Current league dashboard
- Offline local persistence
- Android 16 / API 36 target for current Google Play submission requirements

This is an independent app and does not reproduce APA logos, artwork, trademarks, or proprietary interface assets.
It is a configurable 9-ball league scorekeeper rather than an official APA application.
